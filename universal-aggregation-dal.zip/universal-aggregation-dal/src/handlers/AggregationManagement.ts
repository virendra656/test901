
import * as dotenv from 'dotenv';
import * as _ from 'lodash';
import { to, parseQueryResponse, validateSchema, getFileName } from '../util/helper';
import { Codes, CONSTANTS } from '../util/SiteConfig';
import { getConnection } from '../util/DBManager';
import * as jwt from 'jsonwebtoken';

import { SchemaTemplates } from '../util/SchemaTemplates';
const AWS = require('aws-sdk');


export class AggregationManagement {

    constructor() {
        dotenv.config();
    }



    async GetMonitorData(params: any): Promise<any> {
        let err, result: any = [];
        let finalResponse: any = {
            message: '',
            statusCode: Codes.OK,
            data: []
        };
        try {

            const queryObj = {
                TableName: CONSTANTS.Client_Dev,
                Limit: 100
            };
            const dynamoDb = new AWS.DynamoDB.DocumentClient();

            result = await to(dynamoDb.scan(queryObj).promise());

            console.log("%j", result);

            result = parseQueryResponse(result);

            if (err) throw err;

            if (result && result.Items) {
                finalResponse.data = result.Items;
            }

            return Promise.resolve(finalResponse);

        } catch (e) {
            return Promise.reject(e);
        } finally {

        }
    }
    async GetProductsByBoxId(params: any): Promise<any> {
        let err, result: any = [];
        let connection: any; // obtain db connection
        let finalResponse: any = {
            message: '',
            statusCode: Codes.OK,
            data: []
        };
        try {

            const queryObj = {
                TableName: CONSTANTS.Box_Details,
                Key: {
                    Box_ID: params.BoxID,
                    Client_ID: process.env['Client_ID']
                },
            };
            const dynamoDb = new AWS.DynamoDB.DocumentClient();

            result = await to(dynamoDb.get(queryObj).promise());

            console.log("%j", result);

            result = parseQueryResponse(result);

            if (err) throw err;

            if (result && result.Item) {
                let response = result.Item;

                let items: any = [];
                let pack = {
                    BoxID: response.Box_ID,
                    Client_ID: process.env['Client_ID']
                }
                const ItemCount = response.Packs ? response.Packs.length : 0;
                response.Packs.forEach((element, index) => {
                    element.SNo = index + 1;
                    element.ItemCount = ItemCount;
                    items.push(_.extend(element, pack));
                });
                finalResponse.data = items;
            }

            return Promise.resolve(finalResponse);

        } catch (e) {
            return Promise.reject(e);
        } finally {

        }
    }

    async SaveProducts(params: any, token: any): Promise<any> {
        let err, result: any = [];
        let data: any = params.data;
        console.log("%j", data)
        let pack: any = null;
        let finalResponse: any = {
            message: '',
            statusCode: Codes.OK,
            data: []
        };
        try {
            if (data && data.length) {
                pack = {
                    Box_ID: data[0].BoxID,
                    Client_ID: process.env['Client_ID'],
                    Packs: []
                }
                data.forEach(element => {
                    pack.Packs.push({
                        ProductID: element.ProductID || 'N/A',
                        BarCodeType: element.BarCodeType || 'GTIN',
                        ProductName: element.ProductName || 'Locally Unverified',
                        SerialNumber: element.SerialNumber,
                        GTIN: element.GTIN,
                        BatchNumber: element.BatchNumber,
                        ExpiryDate: element.ExpiryDate,
                        Timestamp: new Date().toISOString()
                    });
                });

            }

            const queryObj = {
                TableName: CONSTANTS.Box_Details,
                Item: pack,
            };
            const dynamoDb = new AWS.DynamoDB.DocumentClient();
            let User_ID = "N/A";
            result = await to(dynamoDb.put(queryObj).promise());
            console.log("%j", result);

            if (err) throw err;

            if (token && token['cognito:username']) {
                User_ID = token['cognito:username']
            }
            let [err2, datadum] = await to(this.SaveMonitorTransaction({
                BoxID: data[0].BoxID,
                User_ID: User_ID
            }, dynamoDb));

            if (err2) throw err2;

            if (result && result.Item) {
                finalResponse.data = result.Item;
            }

            return Promise.resolve(finalResponse);

        } catch (e) {
            return Promise.reject(e);
        } finally {

        }
    }
    //
    async SavePalletTransaction(params: any, token: any): Promise<any> {
        let err, result: any = [];
        let data: any = params.data;
        let pack: any = null;
        let finalResponse: any = {
            message: 'Pallet saved successfully',
            statusCode: Codes.OK,
            data: []
        };
        try {
            if (data && data.PalletID) {
                pack = {
                    Pallet_ID: data.PalletID,
                    Box_IDs: data.BoxIDs,
                    Client_ID: process.env['Client_ID']
                }

            }

            const queryObj = {
                TableName: CONSTANTS.Pallet_Details,
                Item: pack,
            };
            const dynamoDb = new AWS.DynamoDB.DocumentClient();

            result = await to(dynamoDb.put(queryObj).promise());
            console.log("%j", result);


            if (err) throw err;

            data.User_ID = 'N/A'

            if (token && token['cognito:username']) {
                data.User_ID = token['cognito:username']
            }

            let [err2, datadum] = await to(this.SaveMonitorTransaction(data, dynamoDb));

            if (err2) throw err2;

            if (result && result.Item) {
                finalResponse.data = result.Item;
            }

            return Promise.resolve(finalResponse);

        } catch (e) {
            return Promise.reject(e);
        } finally {

        }
    }


    //
    async SaveMonitorTransaction(params: any, dynamoDb: any): Promise<any> {
        let err, result: any = [];
        let data: any = params;
        let pack: any = null;
        let finalResponse: any = {
            message: 'Client saved successfully',
            statusCode: Codes.OK,
            data: []
        };
        console.log("%j", data)
        try {

            if (data && (data.PalletID || data.BoxID)) {
                pack = {
                    ID: (data.PalletID || data.BoxID),
                    Timestamp: new Date().toISOString(),
                    User_ID: data.User_ID || process.env['Client_ID'],
                    Warehouse_Location: process.env['Warehouse_Location'] || 'N/A'
                }
            }

            const queryObj = {
                TableName: CONSTANTS.Client_Dev,
                Item: pack
            };

            console.log("%j", queryObj)

            result = await to(dynamoDb.put(queryObj).promise());
            console.log("%j", result);


            if (err) throw err;

            if (result && result.Item) {
                finalResponse.data = result.Item;
            }

            return Promise.resolve(finalResponse);

        } catch (e) {
            return Promise.reject(e);
        } finally {

        }
    }


    async GetProductsByPalletId(params: any): Promise<any> {
        let err, result: any = [];
        let finalResponse: any = {
            message: '',
            statusCode: Codes.OK,
            data: []
        };
        try {

            let queryObj = {
                TableName: CONSTANTS.Pallet_Details,
                Key: {
                    Pallet_ID: params.PalletID,
                    Client_ID: process.env['Client_ID']
                },
            };
            const dynamoDb = new AWS.DynamoDB.DocumentClient();

            result = await to(dynamoDb.get(queryObj).promise());


            result = parseQueryResponse(result);

            if (err) throw err;

            if (result && result.Item) {

                const Box_IDs = result.Item.Box_IDs;
                let stmt = ``;
                let stmtVals = {};
                Box_IDs.forEach((element, index) => {
                    stmt += ':val' + index;
                    stmtVals[':val' + index] = element;
                    if (Box_IDs[index + 1]) {
                        stmt += ', ';
                    }

                });
                let queryObj = {
                    TableName: CONSTANTS.Box_Details,
                    "FilterExpression": `Box_ID in (${stmt})`,
                    "ExpressionAttributeValues": stmtVals
                };
                console.log("%j", queryObj);

                result = await to(dynamoDb.scan(queryObj).promise());


                result = parseQueryResponse(result);


                if (err) throw err;

                if (result && result.Items) {
                    let boxes = result.Items;

                    let items: any = [];
                    boxes.forEach(response => {
                        let pack: any = {
                            BoxID: response.Box_ID,
                            Items: [],
                            PalletID: params.PalletID,
                            Client_ID: process.env['Client_ID']
                        }
                        const ItemCount = response.Packs ? response.Packs.length : 0;
                        response.Packs.forEach((element, index) => {
                            element.SNo = index + 1;
                            element.ItemCount = ItemCount;
                            element.PalletID = params.PalletID;
                            element.BoxID = response.Box_ID;
                            pack.Items.push(element);
                        });

                        items.push(pack);
                    });

                    finalResponse.data = items;
                }
            }

            return Promise.resolve(finalResponse);

        } catch (e) {
            return Promise.reject(e);
        } finally {

        }
    }








}

