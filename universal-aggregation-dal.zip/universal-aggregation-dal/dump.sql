-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: yalgo.clgbrfxmpf0k.eu-west-2.rds.amazonaws.com    Database: yalgo_dev
-- ------------------------------------------------------
-- Server version	5.6.40-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `business_categories`
--

DROP TABLE IF EXISTS `business_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `business_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_name` varchar(255) NOT NULL,
  `category_description` varchar(1000) DEFAULT NULL,
  `category_icon` varchar(255) DEFAULT NULL,
  `category_hex_code` varchar(10) DEFAULT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `status` tinyint(4) DEFAULT '1',
  `created` datetime DEFAULT CURRENT_TIMESTAMP,
  `modified` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `category_name_UNIQUE` (`category_name`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `business_categories`
--

LOCK TABLES `business_categories` WRITE;
/*!40000 ALTER TABLE `business_categories` DISABLE KEYS */;
INSERT INTO `business_categories` VALUES (1,'Coffee Shops','Coffee Shops','media/business/category_images/category_icon_1555313042859.png','#ff9900','coffee-shops',1,'2019-03-07 11:51:53','2019-03-07 11:51:53'),(10,'test1','test1','media/business/category_images/category_icon_1554187282643.png','#6a6a7c','test1',1,'2019-04-02 06:40:01','2019-04-02 06:40:01'),(11,'Jaspers','Jaspers','media/business/category_images/category_icon_1554187712059.png','#eb4e4e','jaspers',1,'2019-04-02 06:48:31','2019-04-02 06:48:31'),(12,'teste','teste','media/business/category_images/category_icon_1554194487164.png','#874b4b','teste',0,'2019-04-02 08:41:27','2019-04-02 08:41:27'),(13,'Testing Testing','hello it is testing','media/business/category_images/category_icon_1554292912220.png','#3f3333','testing-testing',0,'2019-04-03 12:01:52','2019-04-03 12:01:52'),(14,'sfds','sdfsdd','media/business/category_images/category_icon_1554359502684.png','#320c0c','sfds',1,'2019-04-04 06:31:43','2019-04-04 06:31:43'),(15,'sdfsd','sdfdfg','','#b74949','sdfsd',1,'2019-04-04 10:29:07','2019-04-04 10:29:07'),(16,'hello new','test dfgdf','','#8e0a0a','hello-new',1,'2019-04-04 11:00:57','2019-04-04 11:00:57'),(17,'checksd','sdghrdfg','','#8e5e5e','checksd',0,'2019-04-04 11:03:17','2019-04-04 11:03:17'),(18,'helog','etecf','','#534848','helog',0,'2019-04-04 11:14:35','2019-04-04 11:14:35'),(19,'Testing3 cat','Kayassfd gfdss','media/business/category_images/category_icon_1554468986868.png','#181414','testing3-cat',0,'2019-04-05 12:56:27','2019-04-05 12:56:27'),(20,'hello testing 1','kya kr rhe ho','media/business/category_images/category_icon_1555305535276.png','#d08484','hello-testing-1',1,'2019-04-08 05:58:39','2019-04-08 05:58:39'),(21,'Tsting 4','hellog teing sgsdfd','',NULL,'tsting-4',0,'2019-04-08 05:59:24','2019-04-08 05:59:24'),(22,'sdf','sdf','',NULL,'sdf',1,'2019-04-08 06:04:35','2019-04-08 06:04:35'),(23,'Coffee Shops 23','hello','media/business/category_images/category_icon_1554803692869.png','#863232','coffee-shops-23',0,'2019-04-09 09:54:53','2019-04-09 09:54:53'),(24,'gsd','sdfsd','media/business/category_images/category_icon_1554880541334.png','#301919','gsd',1,'2019-04-10 07:15:41','2019-04-10 07:15:41');
/*!40000 ALTER TABLE `business_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `business_location_addresses`
--

DROP TABLE IF EXISTS `business_location_addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `business_location_addresses` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `business_location_id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `latitude` decimal(10,8) DEFAULT NULL,
  `longitude` decimal(10,8) DEFAULT NULL,
  `rating` int(11) DEFAULT '0',
  `status` tinyint(4) DEFAULT '1',
  `created` datetime DEFAULT CURRENT_TIMESTAMP,
  `modified` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `business_location_addresses`
--

LOCK TABLES `business_location_addresses` WRITE;
/*!40000 ALTER TABLE `business_location_addresses` DISABLE KEYS */;
INSERT INTO `business_location_addresses` VALUES (29,37,221,'Dotsquares Monilek',26.88615330,75.83342130,5,1,'2019-04-01 07:24:40','2019-04-01 07:24:40'),(30,37,221,'GT',26.85540000,75.80690000,0,1,'2019-04-01 07:24:40','2019-04-01 07:24:40'),(31,41,229,'Jhalana Doongri, Jaipur, Rajasthan 302004, India',26.87704710,75.81598110,0,1,'2019-04-02 08:53:56','2019-04-02 08:53:56'),(32,43,236,'4-RA-5, Near Monilek Hospital, Monilek Marg, Goner, Sector 4, Jawahar Nagar, Jaipur, Rajasthan 302004, India',26.88614690,75.83338470,0,1,'2019-04-03 09:25:47','2019-04-03 09:25:47'),(33,43,236,'Jaipur,, Jhalana Institutional Area, Jhalana Doongri, Jaipur, Rajasthan 302004, India',26.87156320,75.81765550,5,1,'2019-04-03 09:25:47','2019-04-03 09:25:47'),(34,45,238,'Jaipur, Rajasthan, India',26.91243360,75.78727090,0,1,'2019-04-04 07:18:12','2019-04-04 07:18:12'),(35,45,238,'Gurugram, Haryana, India',28.45949650,77.02663830,0,1,'2019-04-04 07:18:12','2019-04-04 07:18:12'),(36,47,242,'B 26, Govind Marg, Gurunanakpura, Raja Park, Jaipur, Rajasthan 302004, India',26.89819900,75.82290300,0,1,'2019-04-04 10:09:44','2019-04-04 10:09:44'),(37,47,242,'Showroom No 5, GF, GT Central Mall, D-Block, Crystal Court, Malviya Nagar, Jaipur, Rajasthan 302017, India',26.85630000,75.80590000,0,1,'2019-04-04 10:09:44','2019-04-04 10:09:44'),(38,48,244,'B 26, Govind Marg, Gurunanakpura, Raja Park, Jaipur, Rajasthan 302004, India',26.89819900,75.82290300,0,1,'2019-04-04 10:26:14','2019-04-04 10:26:14'),(39,50,248,'Leeds LS12 6DS, UK',53.78038440,-1.58448760,0,1,'2019-04-10 16:33:29','2019-04-10 16:33:29'),(40,51,251,'Jawahar Circle, Malviya Nagar, Jaipur, Rajasthan 302017, India',26.83985090,75.80093130,0,1,'2019-04-16 08:55:06','2019-04-16 08:55:06'),(41,52,252,'Tester',1.23000000,1.23000000,0,1,'2019-04-16 13:00:45','2019-04-16 13:00:45'),(42,52,252,'Tester2',1.24000000,1.24000000,0,1,'2019-04-16 13:00:45','2019-04-16 13:00:45'),(43,53,253,'Ashram Marg, Nemi Nagar, Vaishali Nagar, Jaipur, Rajasthan 302021, India',26.90785360,75.74149680,0,1,'2019-04-17 10:32:59','2019-04-17 10:32:59'),(44,53,253,'Jawahar Nagar, Jaipur, Rajasthan 302007, India',26.88928140,75.83604220,0,1,'2019-04-17 10:32:59','2019-04-17 10:32:59'),(45,53,253,'Jawahar Circle, Malviya Nagar, Jaipur, Rajasthan 302017, India',26.83985090,75.80093130,0,1,'2019-04-17 10:32:59','2019-04-17 10:32:59');
/*!40000 ALTER TABLE `business_location_addresses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `business_location_users`
--

DROP TABLE IF EXISTS `business_location_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `business_location_users` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `business_location_id` bigint(20) NOT NULL,
  `job_title` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT '0',
  `created` datetime DEFAULT CURRENT_TIMESTAMP,
  `modified` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `fk_business_location_id` (`business_location_id`),
  KEY `fk_business_user_id` (`user_id`),
  CONSTRAINT `fk_business_location_id` FOREIGN KEY (`business_location_id`) REFERENCES `business_locations` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `fk_business_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `business_location_users`
--

LOCK TABLES `business_location_users` WRITE;
/*!40000 ALTER TABLE `business_location_users` DISABLE KEYS */;
INSERT INTO `business_location_users` VALUES (34,221,37,'Player','0','2019-03-19 13:26:19','2019-03-19 13:26:19'),(35,223,38,'Player','0','2019-03-22 06:19:13','2019-03-22 06:19:13'),(36,227,39,'Manager','0','2019-03-25 11:28:26','2019-03-25 11:28:26'),(37,228,40,'Service Manager','0','2019-03-26 05:48:24','2019-03-26 05:48:24'),(38,229,41,'Manager','0','2019-03-27 07:08:34','2019-03-27 07:08:34'),(39,235,42,'Player','0','2019-04-02 09:04:48','2019-04-02 09:04:48'),(40,236,43,'Manager','0','2019-04-03 08:33:40','2019-04-03 08:33:40'),(41,237,44,'Manager','0','2019-04-03 09:51:15','2019-04-03 09:51:15'),(42,238,45,'quality analyst','0','2019-04-04 07:05:32','2019-04-04 07:05:32'),(43,242,47,'f','0','2019-04-04 09:51:20','2019-04-04 09:51:20'),(44,244,48,'sakshi','0','2019-04-04 10:16:05','2019-04-04 10:16:05'),(45,245,49,'Manager','0','2019-04-08 08:38:17','2019-04-08 08:38:17'),(46,248,50,'director','0','2019-04-10 16:19:52','2019-04-10 16:19:52'),(47,251,51,'manager','0','2019-04-16 08:51:02','2019-04-16 08:51:02'),(48,252,52,'Player','0','2019-04-16 12:41:36','2019-04-16 12:41:36'),(49,253,53,'manager','0','2019-04-17 09:59:21','2019-04-17 09:59:21');
/*!40000 ALTER TABLE `business_location_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `business_locations`
--

DROP TABLE IF EXISTS `business_locations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `business_locations` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `business_name` varchar(255) NOT NULL,
  `business_email_address` varchar(255) DEFAULT NULL,
  `telephone_number` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `county` varchar(255) DEFAULT NULL,
  `country` varchar(255) DEFAULT NULL,
  `latitude` float DEFAULT NULL,
  `longitude` float DEFAULT NULL,
  `business_category_id` int(11) DEFAULT NULL,
  `logo` varchar(255) DEFAULT NULL,
  `business_image` varchar(255) DEFAULT NULL,
  `weekday_open_time` time DEFAULT NULL,
  `weekday_close_time` time DEFAULT NULL,
  `saturday_open_time` time DEFAULT NULL,
  `saturday_close_time` time DEFAULT NULL,
  `sunday_open_time` time DEFAULT NULL,
  `sunday_close_time` time DEFAULT NULL,
  `business_info` text,
  `business_address` varchar(255) DEFAULT NULL,
  `contact_number` varchar(255) DEFAULT NULL,
  `web_link` varchar(255) DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `is_approved` tinyint(4) DEFAULT '0',
  `status` tinyint(4) DEFAULT '1',
  `created` datetime DEFAULT CURRENT_TIMESTAMP,
  `modified` datetime DEFAULT CURRENT_TIMESTAMP,
  `setup_complete` tinyint(4) DEFAULT '0',
  `rating` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_cat` (`business_category_id`),
  CONSTRAINT `fk_cat` FOREIGN KEY (`business_category_id`) REFERENCES `business_categories` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `business_locations`
--

LOCK TABLES `business_locations` WRITE;
/*!40000 ALTER TABLE `business_locations` DISABLE KEYS */;
INSERT INTO `business_locations` VALUES (37,'Cersei Lannister',NULL,'123456','North',NULL,NULL,NULL,NULL,14,'media/business/logo/business_logo_1555509102296.png','media/business/images/business_image_1555509102307.png','01:51:51','02:51:51','01:51:51','01:51:51','01:51:51','01:51:51','tester','add1','54556566',NULL,221,1,1,'2019-03-19 13:26:19','2019-03-19 13:26:19',1,1),(38,'Playwood','11','123456','North',NULL,NULL,NULL,NULL,1,'media/business/logo/business_logo_1555323671666.png','media/business/images/business_image_1555323671669.png','00:00:00','00:00:00','00:00:00','00:00:00','00:00:00','00:00:00','sdfsdfs',NULL,'54556566',NULL,223,0,1,'2019-03-22 06:19:13','2019-03-22 06:19:13',1,0),(39,'Coffe Shop',NULL,'9782357343','Jaipur',NULL,NULL,NULL,NULL,11,'media/business/logo/business_logo_1555509168001.png','media/business/images/business_image_1555509168006.png','00:00:00','00:00:00','00:00:00','00:00:00','00:00:00','00:00:00','wsrrew',NULL,'54556566',NULL,227,0,0,'2019-03-25 11:28:26','2019-03-25 11:28:26',1,0),(40,'Coffee Point',NULL,'9782357343','Ganganagar',NULL,NULL,NULL,NULL,14,'media/business/logo/business_logo_1555509250621.png','media/business/images/business_image_1555509250629.png','00:00:00','00:00:00','00:00:00','00:00:00','00:00:00','00:00:00','sfdsdsdf',NULL,'54556566',NULL,228,0,1,'2019-03-26 05:48:24','2019-03-26 05:48:24',1,0),(41,'Murli shop',NULL,'7845124578','Jaipur',NULL,NULL,NULL,NULL,1,'media/business/logo/business_logo_1555322629841.business','media/business/images/business_image_1555322630012.png','07:19:19','21:19:19','08:12:12','22:44:44','00:00:00','00:00:00','Test description',NULL,'54556566',NULL,229,0,1,'2019-03-27 07:08:34','2019-03-27 07:08:34',1,0),(42,'Playwood',NULL,'123456','North',NULL,NULL,NULL,NULL,1,'media/business/logo/business_logo_1555326502390.png','media/business/images/business_image_1555326502397.png','00:00:00','00:00:00','00:00:00','00:00:00','00:00:00','00:00:00','fdgdffd',NULL,'54556566',NULL,235,0,1,'2019-04-02 09:04:48','2019-04-02 09:04:48',1,0),(43,'coffe shop',NULL,'9782357343','ganganagar',NULL,NULL,NULL,NULL,13,'media/business/logo/236_logo.png','media/business/images/business_image_1555509204601.png','07:00:00','18:00:00','06:00:00','17:00:00','08:00:00','00:00:00',' Sdfhiuosdh fush day hsdoufh Ouagadougou fuosdhfouhsdoufh soudhf oushdfouhsdoufh osudh iuoshd fiusdhf',NULL,'54556566',NULL,236,1,1,'2019-04-03 08:33:40','2019-04-03 08:33:40',1,0),(44,'Coffee Shop',NULL,'6544654646','jaipur',NULL,NULL,NULL,NULL,12,'media/business/logo/business_logo_1555319463248.png','media/business/images/business_image_1555319463255.png','00:00:00','00:00:00','00:00:00','00:00:00','00:00:00','00:00:00','dsf',NULL,'54556566',NULL,237,0,1,'2019-04-03 09:51:15','2019-04-03 09:51:15',1,0),(45,'CCD',NULL,'5454','jaipur',NULL,NULL,NULL,NULL,11,'media/business/logo/business_logo_1555328669729.png','media/business/images/business_image_1555328669738.png','12:05:05','21:00:00','08:00:00','21:55:55','00:00:00','00:00:00','Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.',NULL,'54556566',NULL,238,0,1,'2019-04-04 07:05:32','2019-04-04 07:05:32',1,0),(46,'shshshshjd',NULL,'1234','jaipur',NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'54556566',NULL,240,0,1,'2019-04-04 09:50:19','2019-04-04 09:50:19',0,0),(47,'Pizza Hut',NULL,'1234','jaipur',NULL,NULL,NULL,NULL,20,'media/business/logo/business_logo_1555323051278.business','media/business/images/business_image_1555323051289.png','07:50:50','20:00:00','08:00:00','12:00:00','07:00:00','20:00:00','Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.',NULL,'54556566',NULL,242,0,1,'2019-04-04 09:51:20','2019-04-04 09:51:20',1,0),(48,'trdt',NULL,'48454','jaipur',NULL,NULL,NULL,NULL,23,'media/business/logo/business_logo_1555323193671.business','media/business/images/business_image_1555323193674.business','06:00:00','16:45:45','11:00:00','18:00:00','00:00:00','00:00:00','Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.',NULL,'54556566',NULL,244,0,1,'2019-04-04 10:16:05','2019-04-04 10:16:05',1,0),(49,'Burger Shop',NULL,'9782357343','Jaipur',NULL,NULL,NULL,NULL,24,'media/business/logo/business_logo_1555331380998.business','media/business/images/business_image_1555331381004.undefined','00:00:00','00:00:00','02:00:00','03:00:00','23:15:15','00:00:00','dfsdf',NULL,'54556566',NULL,245,0,1,'2019-04-08 08:38:17','2019-04-08 08:38:17',1,0),(50,'Bernie Diner',NULL,'07834531683','leeds',NULL,NULL,NULL,NULL,23,'media/business/logo/business_logo_1555391619742.png','media/business/images/248_image.png','15:45:45','16:35:35','04:00:00','23:00:00','06:00:00','21:00:00','ghegdd',NULL,'5458565582',NULL,248,0,1,'2019-04-10 16:19:52','2019-04-10 16:19:52',1,0),(51,'Food n drinks retro',NULL,'1234567890','Jaipur ',NULL,NULL,NULL,NULL,1,'media/business/logo/251_logo.png','media/business/images/251_image.png','02:00:00','03:00:00','02:00:00','02:00:00','02:00:00','04:00:00','Test retro description',NULL,'1234678903',NULL,251,1,1,'2019-04-16 08:51:02','2019-04-16 08:51:02',1,0),(52,'Samantha 103 Lannister',NULL,'123456','North',NULL,NULL,NULL,NULL,1,'media/business/logo/Tulips_1553666300798.jpg','media/business/images/Chrysanthemum_1553666300852.jpg','01:51:51','21:51:51','03:51:51','08:51:51','01:51:51','02:01:01','tester',NULL,'123456871',NULL,252,0,1,'2019-04-16 12:41:36','2019-04-16 12:41:36',1,0),(53,'qwerryy','meetamehta@mailinator.com','123','jaipur',NULL,NULL,NULL,NULL,1,'media/business/logo/253_logo.png','media/business/images/253_image.png','07:59:00','11:00:00','07:00:00','11:59:00','07:00:00','11:59:00','Fxuufzxgipi pgbpi b pip vi pvjp uvohv. Cou coupuc ou fpug pvj. Phiipg ivp ivgpicv pjgpciig p bjpcijvl pchip viphcivk pichb ipo bb ochipguxoxfuyozfuzoffzuo vjppv juoc yfofsuptxgupcigpk bjp oh zydofzupgpxib k pj vojogzyouxfcih bik blougxozfusuotdigochbk bj pvj pxofufipochb kv pjgozfoxyfigpxbk k vlpuxgpuxgchibi. Vlj',NULL,'1234567890',NULL,253,0,1,'2019-04-17 09:59:21','2019-04-17 09:59:21',1,0);
/*!40000 ALTER TABLE `business_locations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `business_loyalty_programms`
--

DROP TABLE IF EXISTS `business_loyalty_programms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `business_loyalty_programms` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `programm_name` varchar(255) DEFAULT NULL,
  `target_points` int(11) DEFAULT '0',
  `business_location_id` bigint(20) DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT CURRENT_TIMESTAMP,
  `status` tinyint(4) DEFAULT '1',
  `is_active` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `business_loyalty_programms`
--

LOCK TABLES `business_loyalty_programms` WRITE;
/*!40000 ALTER TABLE `business_loyalty_programms` DISABLE KEYS */;
INSERT INTO `business_loyalty_programms` VALUES (1,'Hot Drinks',10,37,221,NULL,'2019-04-06 09:35:45',1,0),(2,'Slice Of Cake',7,43,236,NULL,'2019-04-06 09:35:45',1,1),(3,'Grill Sandwich',6,37,221,NULL,'2019-04-06 09:35:45',1,1),(8,'Jasper',69,NULL,221,'29','2019-04-15 08:43:26',1,0),(9,'Jasper',69,37,221,'29','2019-04-15 08:45:07',1,0),(10,'Jasper3',70,37,221,'56','2019-04-15 08:50:40',1,1);
/*!40000 ALTER TABLE `business_loyalty_programms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `business_offer_geo_data`
--

DROP TABLE IF EXISTS `business_offer_geo_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `business_offer_geo_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) DEFAULT NULL,
  `business_offer_id` bigint(20) DEFAULT NULL,
  `business_location_id` bigint(20) DEFAULT NULL,
  `business_location_address_id` bigint(20) DEFAULT NULL,
  `radius` int(11) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `status` tinyint(4) DEFAULT '0',
  `created` datetime DEFAULT CURRENT_TIMESTAMP,
  `modified` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=118 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `business_offer_geo_data`
--

LOCK TABLES `business_offer_geo_data` WRITE;
/*!40000 ALTER TABLE `business_offer_geo_data` DISABLE KEYS */;
INSERT INTO `business_offer_geo_data` VALUES (76,221,69,37,29,10,'',0,'2019-04-11 05:34:30','2019-04-11 05:34:30'),(77,221,69,37,30,10,'',0,'2019-04-11 05:34:30','2019-04-11 05:34:30'),(78,221,70,37,29,10,'',0,'2019-04-11 05:35:05','2019-04-11 05:35:05'),(80,236,72,43,32,200,'4-RA-5, Near Monilek Hospital, Monilek Marg, Goner, Sector 4, Jawahar Nagar, Jaipur, Rajasthan 302004, India',0,'2019-04-12 07:06:52','2019-04-12 07:06:52'),(81,236,73,43,33,500,'Jaipur,, Jhalana Institutional Area, Jhalana Doongri, Jaipur, Rajasthan 302004, India',0,'2019-04-12 07:12:28','2019-04-12 07:12:28'),(82,236,74,43,33,500,'Jaipur,, Jhalana Institutional Area, Jhalana Doongri, Jaipur, Rajasthan 302004, India',0,'2019-04-12 10:40:42','2019-04-12 10:40:42'),(83,236,71,43,33,5000,'Jaipur,, Jhalana Institutional Area, Jhalana Doongri, Jaipur, Rajasthan 302004, India',0,'2019-04-12 10:50:58','2019-04-12 10:50:58'),(84,236,75,43,33,500,'Jaipur,, Jhalana Institutional Area, Jhalana Doongri, Jaipur, Rajasthan 302004, India',0,'2019-04-16 06:32:51','2019-04-16 06:32:51'),(85,251,76,51,40,10000,'Jawahar Circle, Malviya Nagar, Jaipur, Rajasthan 302017, India',0,'2019-04-16 09:04:13','2019-04-16 09:04:13'),(86,251,77,51,40,5,'Jawahar Circle, Malviya Nagar, Jaipur, Rajasthan 302017, India',0,'2019-04-16 09:07:26','2019-04-16 09:07:26'),(87,251,78,51,40,5,'Jawahar Circle, Malviya Nagar, Jaipur, Rajasthan 302017, India',0,'2019-04-16 09:13:01','2019-04-16 09:13:01'),(88,236,79,43,33,5,'Jaipur,, Jhalana Institutional Area, Jhalana Doongri, Jaipur, Rajasthan 302004, India',0,'2019-04-16 11:24:04','2019-04-16 11:24:04'),(89,236,80,43,32,5,'4-RA-5, Near Monilek Hospital, Monilek Marg, Goner, Sector 4, Jawahar Nagar, Jaipur, Rajasthan 302004, India',0,'2019-04-16 11:31:58','2019-04-16 11:31:58'),(90,236,80,43,32,8,'4-RA-5, Near Monilek Hospital, Monilek Marg, Goner, Sector 4, Jawahar Nagar, Jaipur, Rajasthan 302004, India',0,'2019-04-16 11:31:58','2019-04-16 11:31:58'),(91,236,81,43,33,7,'Jaipur,, Jhalana Institutional Area, Jhalana Doongri, Jaipur, Rajasthan 302004, India',0,'2019-04-16 11:46:00','2019-04-16 11:46:00'),(92,236,82,43,32,5,'4-RA-5, Near Monilek Hospital, Monilek Marg, Goner, Sector 4, Jawahar Nagar, Jaipur, Rajasthan 302004, India',0,'2019-04-16 11:55:00','2019-04-16 11:55:00'),(93,236,83,43,33,5,'Jaipur,, Jhalana Institutional Area, Jhalana Doongri, Jaipur, Rajasthan 302004, India',0,'2019-04-16 12:33:27','2019-04-16 12:33:27'),(94,236,84,43,32,5,'4-RA-5, Near Monilek Hospital, Monilek Marg, Goner, Sector 4, Jawahar Nagar, Jaipur, Rajasthan 302004, India',0,'2019-04-16 12:59:50','2019-04-16 12:59:50'),(96,252,85,52,41,10,'',0,'2019-04-16 13:07:35','2019-04-16 13:07:35'),(97,236,86,43,33,200,'Jaipur,, Jhalana Institutional Area, Jhalana Doongri, Jaipur, Rajasthan 302004, India',0,'2019-04-16 13:17:46','2019-04-16 13:17:46'),(98,251,87,51,40,5,'Jawahar Circle, Malviya Nagar, Jaipur, Rajasthan 302017, India',0,'2019-04-17 07:18:43','2019-04-17 07:18:43'),(99,251,87,51,40,5,'Jawahar Circle, Malviya Nagar, Jaipur, Rajasthan 302017, India',0,'2019-04-17 07:18:43','2019-04-17 07:18:43'),(100,251,87,51,40,5,'Jawahar Circle, Malviya Nagar, Jaipur, Rajasthan 302017, India',0,'2019-04-17 07:18:43','2019-04-17 07:18:43'),(101,251,87,51,40,5,'Jawahar Circle, Malviya Nagar, Jaipur, Rajasthan 302017, India',0,'2019-04-17 07:18:43','2019-04-17 07:18:43'),(102,251,88,51,40,100,'Jawahar Circle, Malviya Nagar, Jaipur, Rajasthan 302017, India',0,'2019-04-17 09:42:50','2019-04-17 09:42:50'),(103,251,89,51,40,5,'Jawahar Circle, Malviya Nagar, Jaipur, Rajasthan 302017, India',0,'2019-04-17 09:44:02','2019-04-17 09:44:02'),(104,251,90,51,40,5,'Jawahar Circle, Malviya Nagar, Jaipur, Rajasthan 302017, India',0,'2019-04-17 09:50:13','2019-04-17 09:50:13'),(105,253,91,53,43,5,'Ashram Marg, Nemi Nagar, Vaishali Nagar, Jaipur, Rajasthan 302021, India',0,'2019-04-17 10:54:47','2019-04-17 10:54:47'),(106,253,91,53,44,5,'Jawahar Nagar, Jaipur, Rajasthan 302007, India',0,'2019-04-17 10:54:47','2019-04-17 10:54:47'),(107,253,92,53,43,5,'Ashram Marg, Nemi Nagar, Vaishali Nagar, Jaipur, Rajasthan 302021, India',0,'2019-04-17 10:59:51','2019-04-17 10:59:51'),(108,253,92,53,45,5,'Jawahar Circle, Malviya Nagar, Jaipur, Rajasthan 302017, India',0,'2019-04-17 10:59:51','2019-04-17 10:59:51'),(109,253,93,53,44,5,'Jawahar Nagar, Jaipur, Rajasthan 302007, India',0,'2019-04-17 11:01:40','2019-04-17 11:01:40'),(110,253,94,53,43,5,'Ashram Marg, Nemi Nagar, Vaishali Nagar, Jaipur, Rajasthan 302021, India',0,'2019-04-17 11:03:08','2019-04-17 11:03:08'),(111,253,94,53,45,5,'Jawahar Circle, Malviya Nagar, Jaipur, Rajasthan 302017, India',0,'2019-04-17 11:03:08','2019-04-17 11:03:08'),(112,253,95,53,43,50,'Ashram Marg, Nemi Nagar, Vaishali Nagar, Jaipur, Rajasthan 302021, India',0,'2019-04-17 11:04:51','2019-04-17 11:04:51'),(113,253,95,53,43,5,'Ashram Marg, Nemi Nagar, Vaishali Nagar, Jaipur, Rajasthan 302021, India',0,'2019-04-17 11:04:51','2019-04-17 11:04:51'),(114,236,96,43,32,15,'4-RA-5, Near Monilek Hospital, Monilek Marg, Goner, Sector 4, Jawahar Nagar, Jaipur, Rajasthan 302004, India',0,'2019-04-17 11:15:29','2019-04-17 11:15:29'),(115,236,96,43,33,78,'Jaipur,, Jhalana Institutional Area, Jhalana Doongri, Jaipur, Rajasthan 302004, India',0,'2019-04-17 11:15:29','2019-04-17 11:15:29'),(116,236,97,43,32,100,'4-RA-5, Near Monilek Hospital, Monilek Marg, Goner, Sector 4, Jawahar Nagar, Jaipur, Rajasthan 302004, India',0,'2019-04-17 12:56:15','2019-04-17 12:56:15'),(117,236,97,43,33,5,'Jaipur,, Jhalana Institutional Area, Jhalana Doongri, Jaipur, Rajasthan 302004, India',0,'2019-04-17 12:56:15','2019-04-17 12:56:15');
/*!40000 ALTER TABLE `business_offer_geo_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `business_offer_images`
--

DROP TABLE IF EXISTS `business_offer_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `business_offer_images` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `image` varchar(255) DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `business_offer_id` bigint(20) DEFAULT NULL,
  `status` tinyint(4) DEFAULT '1',
  `created` datetime DEFAULT CURRENT_TIMESTAMP,
  `modified` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=86 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `business_offer_images`
--

LOCK TABLES `business_offer_images` WRITE;
/*!40000 ALTER TABLE `business_offer_images` DISABLE KEYS */;
INSERT INTO `business_offer_images` VALUES (55,'media/business/offers/o1.jpeg',221,69,1,'2019-04-11 05:34:30','2019-04-11 05:34:30'),(56,'media/business/offers/o1.jpeg',221,70,1,'2019-04-11 05:35:05','2019-04-11 05:35:05'),(58,'media/business/offers/IMG_0007.JPG',236,72,1,'2019-04-12 07:06:52','2019-04-12 07:06:52'),(59,'media/business/offers/IMG_0009.JPG',236,73,1,'2019-04-12 07:12:28','2019-04-12 07:12:28'),(60,'media/business/offers/IMG_0011.JPG',236,74,1,'2019-04-12 10:40:42','2019-04-12 10:40:42'),(61,'media/business/offers/IMG_0007.JPG',236,71,1,'2019-04-12 10:50:58','2019-04-12 10:50:58'),(62,'media/business/offers/IMG_0010.JPG',236,75,1,'2019-04-16 06:32:51','2019-04-16 06:32:51'),(63,'media/business/offers/IMG_3134.JPG',251,76,1,'2019-04-16 09:04:13','2019-04-16 09:04:13'),(64,'media/business/offers/IMG_3435.PNG',251,77,1,'2019-04-16 09:07:26','2019-04-16 09:07:26'),(65,'media/business/offers/IMG_3434.PNG',251,78,1,'2019-04-16 09:13:01','2019-04-16 09:13:01'),(66,'media/business/offers/IMG_0008.PNG',236,79,1,'2019-04-16 11:24:04','2019-04-16 11:24:04'),(67,'media/business/offers/IMG_0006.HEIC',236,80,1,'2019-04-16 11:31:58','2019-04-16 11:31:58'),(68,'media/business/offers/IMG_0011.JPG',236,81,1,'2019-04-16 11:46:00','2019-04-16 11:46:00'),(69,'media/business/offers/IMG_0011.JPG',236,82,1,'2019-04-16 11:55:00','2019-04-16 11:55:00'),(70,'media/business/offers/IMG_0011.JPG',236,83,1,'2019-04-16 12:33:27','2019-04-16 12:33:27'),(71,'media/business/offers/IMG_0010.JPG',236,84,1,'2019-04-16 12:59:50','2019-04-16 12:59:50'),(73,'media/business/offers/o1.jpeg',252,85,1,'2019-04-16 13:07:35','2019-04-16 13:07:35'),(74,'media/business/offers/IMG_8112.JPG',236,86,1,'2019-04-16 13:17:46','2019-04-16 13:17:46'),(75,'media/business/offers/',251,87,1,'2019-04-17 07:18:43','2019-04-17 07:18:43'),(76,'media/business/offers/IMG_1687.JPG',251,88,1,'2019-04-17 09:42:50','2019-04-17 09:42:50'),(77,'media/business/offers/IMG_1764.PNG',251,89,1,'2019-04-17 09:44:02','2019-04-17 09:44:02'),(78,'media/business/offers/IMG_1831.PNG',251,90,1,'2019-04-17 09:50:13','2019-04-17 09:50:13'),(79,'media/business/offers/IMG_1806.JPG',253,91,1,'2019-04-17 10:54:47','2019-04-17 10:54:47'),(80,'media/business/offers/',253,92,1,'2019-04-17 10:59:51','2019-04-17 10:59:51'),(81,'media/business/offers/IMG_1847.PNG',253,93,1,'2019-04-17 11:01:40','2019-04-17 11:01:40'),(82,'media/business/offers/IMG_1827.PNG',253,94,1,'2019-04-17 11:03:08','2019-04-17 11:03:08'),(83,'media/business/offers/IMG_1848.PNG',253,95,1,'2019-04-17 11:04:51','2019-04-17 11:04:51'),(84,'media/business/offers/IMG_0011.JPG',236,96,1,'2019-04-17 11:15:29','2019-04-17 11:15:29'),(85,'media/business/offers/IMG_0011.JPG',236,97,1,'2019-04-17 12:56:15','2019-04-17 12:56:15');
/*!40000 ALTER TABLE `business_offer_images` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `business_offer_views`
--

DROP TABLE IF EXISTS `business_offer_views`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `business_offer_views` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `business_offer_id` bigint(20) DEFAULT NULL,
  `business_location_id` bigint(20) DEFAULT NULL,
  `business_location_address_id` bigint(20) DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `status` tinyint(4) DEFAULT '1',
  `created` datetime DEFAULT CURRENT_TIMESTAMP,
  `modified` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=167 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `business_offer_views`
--

LOCK TABLES `business_offer_views` WRITE;
/*!40000 ALTER TABLE `business_offer_views` DISABLE KEYS */;
INSERT INTO `business_offer_views` VALUES (2,69,37,29,221,1,'2019-04-11 10:21:04','2019-04-11 10:21:04'),(3,69,37,29,221,1,'2019-04-11 10:21:22','2019-04-11 10:21:22'),(4,69,37,29,221,1,'2019-04-11 10:21:51','2019-04-11 10:21:51'),(5,69,37,29,221,1,'2019-04-11 10:22:00','2019-04-11 10:22:00'),(6,71,43,33,225,1,'2019-04-11 11:48:30','2019-04-11 11:48:30'),(7,69,37,29,225,1,'2019-04-11 12:12:47','2019-04-11 12:12:47'),(8,70,37,29,225,1,'2019-04-11 12:15:06','2019-04-11 12:15:06'),(9,70,37,29,225,1,'2019-04-11 12:18:24','2019-04-11 12:18:24'),(10,70,37,29,225,1,'2019-04-11 12:20:16','2019-04-11 12:20:16'),(11,70,37,29,225,1,'2019-04-11 12:20:49','2019-04-11 12:20:49'),(12,69,37,29,225,1,'2019-04-11 12:22:22','2019-04-11 12:22:22'),(13,70,37,29,225,1,'2019-04-11 12:24:28','2019-04-11 12:24:28'),(14,70,37,29,225,1,'2019-04-11 12:34:23','2019-04-11 12:34:23'),(15,70,37,29,225,1,'2019-04-11 12:36:16','2019-04-11 12:36:16'),(16,70,37,29,225,1,'2019-04-11 12:48:52','2019-04-11 12:48:52'),(17,70,37,29,225,1,'2019-04-11 13:44:48','2019-04-11 13:44:48'),(18,70,37,29,225,1,'2019-04-11 13:45:49','2019-04-11 13:45:49'),(19,70,37,29,225,1,'2019-04-11 14:12:56','2019-04-11 14:12:56'),(20,69,37,29,221,1,'2019-04-12 04:50:13','2019-04-12 04:50:13'),(21,70,37,29,225,1,'2019-04-12 06:55:36','2019-04-12 06:55:36'),(22,69,37,29,225,1,'2019-04-12 10:47:49','2019-04-12 10:47:49'),(23,69,37,29,225,1,'2019-04-12 10:47:54','2019-04-12 10:47:54'),(24,69,37,29,225,1,'2019-04-12 10:47:57','2019-04-12 10:47:57'),(25,69,37,29,225,1,'2019-04-12 10:48:00','2019-04-12 10:48:00'),(26,69,37,29,225,1,'2019-04-12 10:48:03','2019-04-12 10:48:03'),(27,69,37,29,225,1,'2019-04-12 11:11:43','2019-04-12 11:11:43'),(28,70,37,29,225,1,'2019-04-12 11:16:34','2019-04-12 11:16:34'),(29,69,37,29,225,1,'2019-04-12 11:18:46','2019-04-12 11:18:46'),(30,70,37,29,225,1,'2019-04-12 11:21:16','2019-04-12 11:21:16'),(31,70,37,29,225,1,'2019-04-12 11:24:57','2019-04-12 11:24:57'),(32,70,37,29,225,1,'2019-04-12 11:31:16','2019-04-12 11:31:16'),(33,70,37,29,225,1,'2019-04-12 11:33:37','2019-04-12 11:33:37'),(34,70,37,29,225,1,'2019-04-12 11:45:36','2019-04-12 11:45:36'),(35,69,37,30,225,1,'2019-04-12 11:46:05','2019-04-12 11:46:05'),(36,70,37,29,225,1,'2019-04-12 13:34:29','2019-04-12 13:34:29'),(37,70,37,29,225,1,'2019-04-12 13:35:01','2019-04-12 13:35:01'),(38,70,37,29,225,1,'2019-04-12 13:38:47','2019-04-12 13:38:47'),(39,69,37,29,225,1,'2019-04-12 13:40:19','2019-04-12 13:40:19'),(40,70,37,29,225,1,'2019-04-12 13:42:59','2019-04-12 13:42:59'),(41,70,37,29,225,1,'2019-04-12 13:46:53','2019-04-12 13:46:53'),(42,70,37,29,225,1,'2019-04-12 13:52:48','2019-04-12 13:52:48'),(43,70,37,29,225,1,'2019-04-12 13:58:28','2019-04-12 13:58:28'),(44,70,37,29,225,1,'2019-04-12 14:00:10','2019-04-12 14:00:10'),(45,70,37,29,225,1,'2019-04-12 14:05:13','2019-04-12 14:05:13'),(46,70,37,29,225,1,'2019-04-12 14:10:52','2019-04-12 14:10:52'),(47,69,37,29,225,1,'2019-04-12 14:23:33','2019-04-12 14:23:33'),(48,69,37,29,225,1,'2019-04-12 14:23:55','2019-04-12 14:23:55'),(49,70,37,29,234,1,'2019-04-15 05:26:00','2019-04-15 05:26:00'),(50,69,37,29,234,1,'2019-04-15 05:26:35','2019-04-15 05:26:35'),(51,70,37,29,225,1,'2019-04-15 05:30:22','2019-04-15 05:30:22'),(52,69,37,29,225,1,'2019-04-15 05:33:30','2019-04-15 05:33:30'),(53,69,37,29,225,1,'2019-04-15 05:42:18','2019-04-15 05:42:18'),(54,70,37,29,225,1,'2019-04-15 05:46:05','2019-04-15 05:46:05'),(55,70,37,29,225,1,'2019-04-15 05:50:27','2019-04-15 05:50:27'),(56,69,37,29,225,1,'2019-04-15 05:51:59','2019-04-15 05:51:59'),(57,69,37,29,225,1,'2019-04-15 05:52:51','2019-04-15 05:52:51'),(58,69,37,29,225,1,'2019-04-15 06:03:13','2019-04-15 06:03:13'),(59,69,37,29,225,1,'2019-04-15 06:04:04','2019-04-15 06:04:04'),(60,70,37,29,225,1,'2019-04-15 06:14:35','2019-04-15 06:14:35'),(61,70,37,29,225,1,'2019-04-15 06:14:58','2019-04-15 06:14:58'),(62,69,37,29,225,1,'2019-04-15 06:19:03','2019-04-15 06:19:03'),(63,69,37,29,225,1,'2019-04-15 06:23:05','2019-04-15 06:23:05'),(64,70,37,29,225,1,'2019-04-15 06:34:16','2019-04-15 06:34:16'),(65,70,37,29,225,1,'2019-04-15 06:34:57','2019-04-15 06:34:57'),(66,70,37,29,225,1,'2019-04-15 06:35:46','2019-04-15 06:35:46'),(67,70,37,29,225,1,'2019-04-15 06:38:32','2019-04-15 06:38:32'),(68,69,37,29,225,1,'2019-04-15 06:56:54','2019-04-15 06:56:54'),(69,70,37,29,225,1,'2019-04-15 06:57:56','2019-04-15 06:57:56'),(70,70,37,29,225,1,'2019-04-15 06:58:53','2019-04-15 06:58:53'),(71,70,37,29,225,1,'2019-04-15 06:59:53','2019-04-15 06:59:53'),(72,69,37,29,225,1,'2019-04-15 07:00:48','2019-04-15 07:00:48'),(73,70,37,29,225,1,'2019-04-15 07:01:49','2019-04-15 07:01:49'),(74,72,43,32,225,1,'2019-04-15 07:05:47','2019-04-15 07:05:47'),(75,72,43,32,234,1,'2019-04-15 07:11:48','2019-04-15 07:11:48'),(76,72,43,32,234,1,'2019-04-15 07:14:06','2019-04-15 07:14:06'),(77,70,37,29,225,1,'2019-04-15 07:20:45','2019-04-15 07:20:45'),(78,72,43,32,225,1,'2019-04-15 07:23:07','2019-04-15 07:23:07'),(79,72,43,32,225,1,'2019-04-15 07:23:57','2019-04-15 07:23:57'),(80,72,43,32,225,1,'2019-04-15 07:24:59','2019-04-15 07:24:59'),(81,74,43,33,225,1,'2019-04-15 07:25:24','2019-04-15 07:25:24'),(82,72,43,32,225,1,'2019-04-15 07:26:20','2019-04-15 07:26:20'),(83,72,43,32,225,1,'2019-04-15 07:26:34','2019-04-15 07:26:34'),(84,70,37,29,225,1,'2019-04-15 07:26:40','2019-04-15 07:26:40'),(85,72,43,32,225,1,'2019-04-15 07:27:59','2019-04-15 07:27:59'),(86,69,37,29,225,1,'2019-04-15 07:28:03','2019-04-15 07:28:03'),(87,72,43,32,225,1,'2019-04-15 07:30:20','2019-04-15 07:30:20'),(88,70,37,29,225,1,'2019-04-15 07:30:23','2019-04-15 07:30:23'),(89,70,37,29,253,1,'2019-04-16 11:01:51','2019-04-16 11:01:51'),(90,72,43,32,225,1,'2019-04-16 11:03:02','2019-04-16 11:03:02'),(91,70,37,29,225,1,'2019-04-16 11:03:13','2019-04-16 11:03:13'),(92,70,37,29,225,1,'2019-04-16 11:11:19','2019-04-16 11:11:19'),(93,72,43,32,225,1,'2019-04-16 11:13:56','2019-04-16 11:13:56'),(94,70,37,29,225,1,'2019-04-16 11:21:16','2019-04-16 11:21:16'),(95,70,37,29,225,1,'2019-04-16 11:23:21','2019-04-16 11:23:21'),(96,70,37,29,225,1,'2019-04-17 05:01:24','2019-04-17 05:01:24'),(97,70,37,29,225,1,'2019-04-17 05:36:07','2019-04-17 05:36:07'),(98,70,37,29,225,1,'2019-04-17 05:37:43','2019-04-17 05:37:43'),(99,82,43,32,225,1,'2019-04-17 05:47:43','2019-04-17 05:47:43'),(100,70,37,29,225,1,'2019-04-17 05:50:01','2019-04-17 05:50:01'),(101,70,37,29,225,1,'2019-04-17 05:51:44','2019-04-17 05:51:44'),(102,70,37,29,225,1,'2019-04-17 05:53:47','2019-04-17 05:53:47'),(103,69,37,29,225,1,'2019-04-17 06:01:42','2019-04-17 06:01:42'),(104,70,37,29,225,1,'2019-04-17 06:05:20','2019-04-17 06:05:20'),(105,70,37,29,225,1,'2019-04-17 06:09:17','2019-04-17 06:09:17'),(106,70,37,29,225,1,'2019-04-17 06:09:24','2019-04-17 06:09:24'),(107,69,37,29,225,1,'2019-04-17 06:09:59','2019-04-17 06:09:59'),(108,70,37,29,225,1,'2019-04-17 06:12:47','2019-04-17 06:12:47'),(109,70,37,29,225,1,'2019-04-17 06:13:03','2019-04-17 06:13:03'),(110,69,37,29,225,1,'2019-04-17 06:14:53','2019-04-17 06:14:53'),(111,70,37,29,225,1,'2019-04-17 06:17:59','2019-04-17 06:17:59'),(112,70,37,29,225,1,'2019-04-17 06:20:22','2019-04-17 06:20:22'),(113,69,37,29,225,1,'2019-04-17 06:46:58','2019-04-17 06:46:58'),(114,70,37,29,225,1,'2019-04-17 07:08:45','2019-04-17 07:08:45'),(115,70,37,29,225,1,'2019-04-17 07:13:11','2019-04-17 07:13:11'),(116,70,37,29,225,1,'2019-04-17 07:18:52','2019-04-17 07:18:52'),(117,70,37,29,225,1,'2019-04-17 07:20:34','2019-04-17 07:20:34'),(118,70,37,29,225,1,'2019-04-17 08:34:27','2019-04-17 08:34:27'),(119,70,37,29,225,1,'2019-04-17 08:37:14','2019-04-17 08:37:14'),(120,70,37,29,225,1,'2019-04-17 09:12:51','2019-04-17 09:12:51'),(121,72,43,32,225,1,'2019-04-17 10:10:03','2019-04-17 10:10:03'),(122,70,37,29,225,1,'2019-04-17 10:22:26','2019-04-17 10:22:26'),(123,72,43,32,225,1,'2019-04-17 10:22:42','2019-04-17 10:22:42'),(124,70,37,29,225,1,'2019-04-17 10:25:30','2019-04-17 10:25:30'),(125,72,43,32,225,1,'2019-04-17 10:25:36','2019-04-17 10:25:36'),(126,70,37,29,225,1,'2019-04-17 10:30:34','2019-04-17 10:30:34'),(127,72,43,32,225,1,'2019-04-17 10:30:39','2019-04-17 10:30:39'),(128,72,43,32,225,1,'2019-04-17 10:30:45','2019-04-17 10:30:45'),(129,72,43,32,225,1,'2019-04-17 10:30:49','2019-04-17 10:30:49'),(130,72,43,32,225,1,'2019-04-17 10:30:54','2019-04-17 10:30:54'),(131,72,43,32,225,1,'2019-04-17 10:30:58','2019-04-17 10:30:58'),(132,72,43,32,225,1,'2019-04-17 10:31:01','2019-04-17 10:31:01'),(133,72,43,32,225,1,'2019-04-17 10:31:03','2019-04-17 10:31:03'),(134,72,43,32,225,1,'2019-04-17 10:31:07','2019-04-17 10:31:07'),(135,82,43,32,225,1,'2019-04-17 10:33:14','2019-04-17 10:33:14'),(136,82,43,32,225,1,'2019-04-17 10:36:08','2019-04-17 10:36:08'),(137,69,37,29,225,1,'2019-04-17 10:46:18','2019-04-17 10:46:18'),(138,72,43,32,225,1,'2019-04-17 11:11:36','2019-04-17 11:11:36'),(139,72,43,32,225,1,'2019-04-17 11:21:35','2019-04-17 11:21:35'),(140,82,43,32,225,1,'2019-04-17 11:22:37','2019-04-17 11:22:37'),(141,96,43,32,225,1,'2019-04-17 11:37:26','2019-04-17 11:37:26'),(142,96,43,32,225,1,'2019-04-17 11:40:06','2019-04-17 11:40:06'),(143,72,43,32,225,1,'2019-04-17 11:44:48','2019-04-17 11:44:48'),(144,96,43,32,225,1,'2019-04-17 11:45:30','2019-04-17 11:45:30'),(145,72,43,32,225,1,'2019-04-17 11:48:02','2019-04-17 11:48:02'),(146,72,43,32,225,1,'2019-04-17 11:51:40','2019-04-17 11:51:40'),(147,72,43,32,225,1,'2019-04-17 12:33:00','2019-04-17 12:33:00'),(148,72,43,32,225,1,'2019-04-17 12:36:58','2019-04-17 12:36:58'),(149,72,43,32,225,1,'2019-04-17 12:40:18','2019-04-17 12:40:18'),(150,69,37,29,225,1,'2019-04-17 12:40:22','2019-04-17 12:40:22'),(151,72,43,32,225,1,'2019-04-17 12:40:33','2019-04-17 12:40:33'),(152,82,43,32,225,1,'2019-04-17 12:43:40','2019-04-17 12:43:40'),(153,69,37,29,225,1,'2019-04-17 12:44:08','2019-04-17 12:44:08'),(154,82,43,32,225,1,'2019-04-17 12:46:20','2019-04-17 12:46:20'),(155,72,43,32,225,1,'2019-04-17 12:47:45','2019-04-17 12:47:45'),(156,96,43,32,225,1,'2019-04-17 12:53:16','2019-04-17 12:53:16'),(157,96,43,32,225,1,'2019-04-17 12:54:10','2019-04-17 12:54:10'),(158,72,43,32,225,1,'2019-04-17 12:54:12','2019-04-17 12:54:12'),(159,70,37,29,225,1,'2019-04-17 12:54:15','2019-04-17 12:54:15'),(160,72,43,32,225,1,'2019-04-17 12:54:24','2019-04-17 12:54:24'),(161,96,43,32,225,1,'2019-04-17 13:01:07','2019-04-17 13:01:07'),(162,96,43,32,225,1,'2019-04-17 13:26:35','2019-04-17 13:26:35'),(163,82,43,32,225,1,'2019-04-17 13:29:58','2019-04-17 13:29:58'),(164,72,43,32,225,1,'2019-04-17 13:31:12','2019-04-17 13:31:12'),(165,72,43,32,225,1,'2019-04-17 13:34:28','2019-04-17 13:34:28'),(166,96,43,32,225,1,'2019-04-17 13:35:30','2019-04-17 13:35:30');
/*!40000 ALTER TABLE `business_offer_views` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `business_offers`
--

DROP TABLE IF EXISTS `business_offers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `business_offers` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `start_date` datetime DEFAULT NULL,
  `end_date` datetime DEFAULT NULL,
  `redeem_start_time` time DEFAULT NULL,
  `redeem_close_time` time DEFAULT NULL,
  `scan_per_user_limit` int(11) DEFAULT NULL,
  `is_published` tinyint(1) DEFAULT '0',
  `notify_yalgo_users` tinyint(4) DEFAULT '0',
  `notify_yalgo_customers` tinyint(4) DEFAULT '0',
  `user_id` bigint(20) DEFAULT NULL,
  `term_conditions` text,
  `vocde` varchar(255) DEFAULT NULL,
  `status` tinyint(4) DEFAULT '1',
  `created` datetime DEFAULT CURRENT_TIMESTAMP,
  `modified` datetime DEFAULT CURRENT_TIMESTAMP,
  `qr_code` varchar(2000) DEFAULT NULL,
  `business_location_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_business_offers_user_id` (`user_id`),
  CONSTRAINT `fk_business_offers_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=98 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `business_offers`
--

LOCK TABLES `business_offers` WRITE;
/*!40000 ALTER TABLE `business_offers` DISABLE KEYS */;
INSERT INTO `business_offers` VALUES (69,'50 % off on ice cream','50 % off on ice cream','2019-04-08 00:04:00','2019-11-12 00:11:00','02:00:00','03:00:00',10,1,1,1,221,'tester',NULL,1,'2019-04-11 05:33:51','2019-04-11 05:33:51','U2FsdGVkX1+pXf9pz9SsnRuP+OOfQ91NBMEFVRrjQD4=',37),(70,'Ham burgers are free','Ham burgers are free','2019-04-08 00:04:00','2019-11-12 00:11:00','02:00:00','03:00:00',5,1,1,1,221,'tester',NULL,1,'2019-04-11 05:35:05','2019-04-11 05:35:05','U2FsdGVkX1/FIEZmR1whGrmjcEUtd9+QvW4qhFOCiQA=',37),(71,'get 40% off on sweets','Get 40% off on all sweets at our store','2019-04-11 00:04:00','2019-04-20 00:04:00','17:20:00','18:20:00',5,1,1,1,236,' Dfgdfg dfgdsf9 gdsf9 g9dfsy g9ydfs9gy d9sfy g9dsfy g 9ydfs9gy df9 gy9dy g9dyf9y sdf9gy sd9fy g9dsyf g9sdfy g9y sdf9g ysd9fyg 9dsyf g9sdyfg9ydsfg9y dsfiugy idsfyg iudsfy guiding',NULL,1,'2019-04-11 06:35:08','2019-04-11 06:35:08','U2FsdGVkX184aBBRONTxpwM06LBrEf/EG4L8E4QInb0=',43),(72,'Get All IceCream for $2 before 4 pm','You can purchase any ice cream with Cost $2 before 4 pm . This offer is only valid for 1 month.','2019-04-12 00:04:00','2019-05-13 00:05:00','12:00:00','16:00:00',5,1,1,1,236,'Ds 0urf0us0 da9hu SDSU’s fiushadifuh isaduhf Irish’s fouhsdofuh isgdf osudh f I hsdoufh sdif fshud this dofij asudh suhd fouhsdofuh sdif hsdoufh ',NULL,1,'2019-04-12 07:06:52','2019-04-12 07:06:52','U2FsdGVkX19CE7HIpsSjUfC4YZeasCSFtlBUD8kGqR4=',43),(73,'Get offer on all burgers','Get 1 burger free on purchasing 1 burger','2019-04-12 00:04:00','2019-04-13 00:04:00','12:42:00','13:42:00',6,1,1,1,236,'We’d we saw dqwd as dads asd asd asd asd asd asd asd asd',NULL,1,'2019-04-12 07:12:28','2019-04-12 07:12:28','U2FsdGVkX1+RgFCWtHOaE7eAQsuvmaoi8lcavVEB7xQ=',43),(74,'get 40% off on pani puri','Get 40% off on pani puri at our store','2019-04-11 00:04:00','2019-04-20 00:04:00','17:10:00','18:10:00',5,1,1,1,236,' Dfgdfg dfgdsf9 gdsf9 g9dfsy g9ydfs9gy d9sfy g9dsfy g 9ydfs9gy df9 gy9dy g9dyf9y sdf9gy sd9fy g9dsyf g9sdfy g9y sdf9g ysd9fyg 9dsyf g9sdyfg9ydsfg9y dsfiugy idsfyg iudsfy guiding',NULL,1,'2019-04-12 10:40:42','2019-04-12 10:40:42','U2FsdGVkX1+wfnCxawH8kUEM8NrYlCCMHGwaQFXOZIc=',43),(75,'get off on all mini pizzas at our store','Get offer this month to get 60% of on all mini pizzas at our store.','2019-04-16 00:04:00','2019-05-21 00:05:00','12:01:00','15:01:00',5,1,1,1,236,'  Erjgijdfgj dsfijg Josef good sfigj fish. Gijdsfgj[ids jfgijdsgf',NULL,1,'2019-04-16 06:32:51','2019-04-16 06:32:51','U2FsdGVkX19IZFE6uZFfKXV/MayWKZh2x7Wbs6OwgAU=',43),(76,'first drink free','If you are first customer the please show any of card or Yalgo app l and get a first drink free form our side.','2020-04-19 00:04:00','2019-04-19 00:04:00','03:58:00','03:58:00',1,1,1,1,251,'Greg’s dhdj dhhdhd chc ça chcbchc dhdhdh fhf Hdhdhd fff fhhdhdrhrbrr rhruyrrhr Dbd',NULL,1,'2019-04-16 09:04:13','2019-04-16 09:04:13','U2FsdGVkX19KQAUbWxYoM4075iUZAtbcejTKetMZH5M=',51),(77,'jvzkgzkgslh','MvjgJgsgksjp','2019-04-19 00:04:00','2019-04-20 00:04:00','19:06:00','19:08:00',1,1,1,1,251,'   ',NULL,1,'2019-04-16 09:07:26','2019-04-16 09:07:26','U2FsdGVkX1+41bu9srfSp05NijbYD9/D+fffdWSavKQ=',51),(78,'fusdufgsuo','Hzcxgjgjxgjf','2019-04-20 00:04:00','2019-04-30 00:04:00','19:12:00','23:12:00',1,1,1,1,251,'Qwer',NULL,1,'2019-04-16 09:13:01','2019-04-16 09:13:01','U2FsdGVkX19dCrAbYhr7Up/vN1aBpeXjNo6THfeTOpA=',51),(79,'fdghyrfh then','T yjrtjyrtjyrtjytrjy','2019-04-16 00:04:00','2019-04-18 00:04:00','16:53:00','17:53:00',4,1,1,1,236,'Duh dfgh fgj dfgh gah dfgh',NULL,1,'2019-04-16 11:24:04','2019-04-16 11:24:04','U2FsdGVkX1816Z3ELY2XBk8FviNNRkQKuaABenv1bDQ=',43),(80,'ooh hfs hooch ghijf go','Dfg df ghfih [idfojgh [ijfdgh','2019-04-16 00:04:00','2019-04-17 00:04:00','17:00:00','18:00:00',9,1,1,1,236,'Dfg ghj dfgh hi fj',NULL,1,'2019-04-16 11:31:58','2019-04-16 11:31:58','U2FsdGVkX1+UZIJWbmzY91WmqYUtMtLDRRwo9vr9ark=',43),(81,'we fest dfsg ','dfsg dfsg gdsf dfsg ','2019-04-16 00:04:00','2019-04-16 00:04:00','17:14:00','18:14:00',7,1,1,1,236,'Dfg dsfg dsf g',NULL,1,'2019-04-16 11:46:00','2019-04-16 11:46:00','U2FsdGVkX19aWDKPXjPqbd7KlKCX4VRu60E0xrVvoKA=',43),(82,'cvnhcvn can ','Dfgh Vichy cv hcg','2019-04-16 00:04:00','2019-06-16 00:06:00','17:23:00','18:23:00',3,1,1,1,236,'Dfg dsfg sdfg sdfg',NULL,1,'2019-04-16 11:55:00','2019-04-16 11:55:00','U2FsdGVkX1+yh6ZNXpP6fw5yvA0KH9cMDN+3G4rzGSQ=',43),(83,'df g dfsg dsfg dsfg ','d dsf dsfg dfsg dsfg dsfg dfg','2019-04-16 00:04:00','2019-04-22 00:04:00','18:03:00','19:03:00',12,1,1,1,236,'Age asdf sadf',NULL,1,'2019-04-16 12:33:27','2019-04-16 12:33:27','U2FsdGVkX19CZDpZlYmLsr1wUe1V+QjrAEHrbL2CKaE=',43),(84,'dfg dfs gdsf gdf','dsf g dsfg dsf gdsfg ','2019-04-16 00:04:00','2019-04-17 00:04:00','18:29:00','19:29:00',8,1,1,1,236,'Dfsg dsfg dsf gdsfg sdfg\nD Gaga ds\nDf \nDsf \nGdsf\n Gdsfg',NULL,1,'2019-04-16 12:59:50','2019-04-16 12:59:50','U2FsdGVkX1/BSYke05I5nHtqjknjeOI/1eg0VAi3tHg=',43),(85,'Howdy 1','Howdy 1','1991-12-11 00:12:00','1991-12-11 00:12:00','02:00:00','03:00:00',5,1,1,1,252,'tester',NULL,1,'2019-04-16 13:06:44','2019-04-16 13:06:44','U2FsdGVkX1+oVsabsjDu+oHqCW0jl+AQXDi6Z1GvAGw=',52),(86,'burger offer','get 30% off on burgers','2019-04-17 00:04:00','2019-04-18 00:04:00','18:46:00','19:46:00',25,1,1,1,236,'nznsjxjbnk\nyggn\n\ngg',NULL,1,'2019-04-16 13:17:46','2019-04-16 13:17:46','U2FsdGVkX1+1mqiDuM0hketAyYbTh0MPVF8otJcNV+A=',43),(87,'qwerty','Cghh','2019-04-17 00:04:00','2019-04-17 00:04:00','12:48:00','12:49:00',0,1,1,1,251,'Sdf',NULL,1,'2019-04-17 07:18:43','2019-04-17 07:18:43','U2FsdGVkX1+qFDt3bGeRz5Fu7y+fPr40K80n/YkIIHc=',51),(88,'qwertu','Fyc vi jobojvbio viuhivhivivjiviov','2020-04-17 00:04:00','2020-04-17 00:04:00','20:10:00','23:10:00',10,1,1,1,251,'Uv gxi g gi gob bo bo ho ob kb kb. Obob. Obob no. Onno on oj on pj oh. Ooh ohxodoueifsofu',NULL,1,'2019-04-17 09:42:50','2019-04-17 09:42:50','U2FsdGVkX1+bgiJuMKH7Nj0twBlgreJM8t85dh49Ywc=',51),(89,'ih ob ','Ohcoh','2019-04-17 00:04:00','2019-04-17 00:04:00','08:00:00','23:59:00',10,1,1,1,251,'Gxgxig ig ig.',NULL,1,'2019-04-17 09:44:02','2019-04-17 09:44:02','U2FsdGVkX18vL44xl0xI0wH0Vob9W3KuqTrCHv4TMx0=',51),(90,'vi. vj',' Hho ','2019-04-17 00:04:00','2019-04-17 00:04:00','15:19:00','15:20:00',6,1,1,1,251,'Bh',NULL,1,'2019-04-17 09:50:13','2019-04-17 09:50:13','U2FsdGVkX1/FOP8iyKa+PRSrjynmQljTjc7QCABcZUM=',51),(91,'kgxkgzkg','JvjgGk','2019-04-17 00:04:00','2019-04-17 00:04:00','16:24:00','16:28:00',6,1,1,1,253,'Dudugxgix',NULL,1,'2019-04-17 10:54:47','2019-04-17 10:54:47','U2FsdGVkX1+nf98RarGawz9ncAIXupkdCEPOfvjxcG8=',53),(92,'hehddhd','Dbhdxhd','2019-04-18 00:04:00','2019-04-18 00:04:00','16:29:00','23:29:00',10,1,1,1,253,'Bdjdjd hd dhdb',NULL,1,'2019-04-17 10:59:51','2019-04-17 10:59:51','U2FsdGVkX186CS6WughDr3grmnkV7PVZCMT/LO97eY8=',53),(93,'pizza iffer','Sbhsbdvd\nChdbdjd','2019-04-17 00:04:00','2019-04-17 00:04:00','16:31:00','17:31:00',5,1,1,1,253,'Sndn djdnf',NULL,1,'2019-04-17 11:01:40','2019-04-17 11:01:40','U2FsdGVkX19htf0Eo2pA+wnyQyuukokxoXLAD6c08AQ=',53),(94,'shjdjdhd','Dbjdhdndbdnnf','2019-04-17 00:04:00','2019-04-17 00:04:00','16:32:00','17:32:00',5,1,1,1,253,'Gctcycycy',NULL,1,'2019-04-17 11:03:08','2019-04-17 11:03:08','U2FsdGVkX1+rSeSyKtuafSedPDke8k6htmEEIif2/L0=',53),(95,' hvyvyvyv','G gvyvyvu','2019-04-19 00:04:00','2019-04-19 00:04:00','16:34:00','17:34:00',5,1,1,1,253,'Hcchch h. Ychcjv',NULL,1,'2019-04-17 11:04:51','2019-04-17 11:04:51','U2FsdGVkX19q5y9YmasJ7QfqvS9Sgo9g3oObasbRm4A=',53),(96,'df dsf dsfg d',' Dfg dsfg dsfg sdfg sdfg dsfg','2019-04-17 00:04:00','2019-05-17 00:05:00','16:45:00','17:45:00',6,1,1,1,236,'Ds dfsg',NULL,1,'2019-04-17 11:15:29','2019-04-17 11:15:29','U2FsdGVkX1+82om/qpU5TafSQls3+6BUXzBjEhnTFjo=',43),(97,'gf hfghfgh','Dfg dfg f','2019-04-17 00:04:00','2019-04-17 00:04:00','18:25:00','19:25:00',5,1,1,1,236,'Df gdsfg dfg dfg',NULL,1,'2019-04-17 12:56:15','2019-04-17 12:56:15','U2FsdGVkX1+gsvnjlcsFiY8ghl07sey2w39zt7ZJN3o=',43);
/*!40000 ALTER TABLE `business_offers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `business_rating_reviews`
--

DROP TABLE IF EXISTS `business_rating_reviews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `business_rating_reviews` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) DEFAULT NULL,
  `business_location_id` bigint(20) DEFAULT NULL,
  `business_location_address_id` bigint(20) DEFAULT NULL,
  `rating` tinyint(4) DEFAULT '0',
  `review` varchar(255) DEFAULT NULL,
  `status` tinyint(4) DEFAULT '1',
  `created` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `business_rating_reviews`
--

LOCK TABLES `business_rating_reviews` WRITE;
/*!40000 ALTER TABLE `business_rating_reviews` DISABLE KEYS */;
INSERT INTO `business_rating_reviews` VALUES (16,221,37,29,5,'Good',1,'2019-04-11 06:50:12'),(17,225,43,33,5,'',1,'2019-04-17 12:53:43'),(18,225,43,33,5,'',1,'2019-04-17 13:01:29'),(19,225,43,33,5,'',1,'2019-04-17 13:02:52'),(20,225,43,33,5,'',1,'2019-04-17 13:35:55');
/*!40000 ALTER TABLE `business_rating_reviews` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `business_recommendations`
--

DROP TABLE IF EXISTS `business_recommendations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `business_recommendations` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `business_name` varchar(255) NOT NULL,
  `business_address` varchar(255) DEFAULT NULL,
  `business_contact` varchar(255) DEFAULT NULL,
  `business_telephone_number` varchar(50) DEFAULT NULL,
  `business_association` tinyint(4) DEFAULT '0',
  `is_business_aware` tinyint(4) DEFAULT '0',
  `user_id` bigint(20) DEFAULT NULL,
  `status` tinyint(4) DEFAULT '0',
  `created` datetime DEFAULT CURRENT_TIMESTAMP,
  `modified` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `fk_business_recommendation_user_id` (`user_id`),
  CONSTRAINT `fk_business_recommendation_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `business_recommendations`
--

LOCK TABLES `business_recommendations` WRITE;
/*!40000 ALTER TABLE `business_recommendations` DISABLE KEYS */;
INSERT INTO `business_recommendations` VALUES (1,'Rcom Tech','6 Ra 5 jawahar nagar','John Smith','9876543210',1,0,215,1,'2019-04-11 09:48:01','2019-04-17 05:59:33'),(2,'Teat Hardware','4 Ra 5','Hansi Croni','896574521',0,0,216,1,'2019-04-11 09:49:03','2019-04-17 05:59:34'),(3,'Test construction','4 gs 5','Test Name','85632145',1,1,240,1,'2019-04-11 09:59:00','2019-04-17 05:59:34'),(4,'Chemicals group','4 gs 5','Crown Abraham','85632145',0,0,240,1,'2019-04-11 09:59:03','2019-04-17 05:59:34'),(5,'dev group of industries','4 gs 5','Test Abraham','85632145',0,1,240,1,'2019-04-11 09:59:06','2019-04-17 05:59:35'),(6,'Test 4','khokha','Raj Lincon','955668852',1,0,230,0,'2019-04-11 09:59:53','2019-04-17 05:59:35'),(7,'Test2','asdffdfg','Hansi Suthar','987456352',0,0,245,0,'2019-04-11 10:02:47','2019-04-17 05:59:35'),(8,'Test3','asdffdfg','P Suthar','658425866',1,1,245,1,'2019-04-11 10:02:51','2019-04-17 05:59:36'),(9,'Test5','asdffdfg','Anil K','789895555',1,0,245,0,'2019-04-11 10:02:55','2019-04-17 05:59:36'),(10,'Test6','asdffdfg','MS Motwani','458256685',1,1,245,1,'2019-04-11 10:02:57','2019-04-17 05:59:36'),(11,'Test7','asdffdfg','Rohit Saxena','856225666',0,0,245,1,'2019-04-11 10:03:01','2019-04-17 05:59:37'),(12,'Test8','asdffdfg','Tez Pratap','897566325',0,0,245,1,'2019-04-11 10:03:06','2019-04-17 05:59:37');
/*!40000 ALTER TABLE `business_recommendations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_templates`
--

DROP TABLE IF EXISTS `email_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `email_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subject` varchar(45) DEFAULT NULL,
  `content` text,
  `status` tinyint(4) DEFAULT '1',
  `created` datetime DEFAULT CURRENT_TIMESTAMP,
  `modified` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_templates`
--

LOCK TABLES `email_templates` WRITE;
/*!40000 ALTER TABLE `email_templates` DISABLE KEYS */;
INSERT INTO `email_templates` VALUES (1,'Signup','<p>Hello {name},</p><p>We have received your request for new account on yalgo platform. In order to complete the registration process, please click on the below link and get your own access. </p><p><a href=\"{link}\">Click Here </a></p><p>Regards,</p><p>Yalgo Team</p>',1,'2019-03-11 12:15:26','0000-00-00 00:00:00'),(2,'Forgot Password','<p>Hello {name},</p><p>We have received your request to reset the password for Yalgo account. Please press the below button to reset it -</p><p><a href=\"{link}\">Click Here </a></p><p>Regards,</p><p>Yalgo Team</p>',1,'2019-03-12 12:23:50','0000-00-00 00:00:00');
/*!40000 ALTER TABLE `email_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inquiries`
--

DROP TABLE IF EXISTS `inquiries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inquiries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `message` varchar(2000) DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `read_status` tinyint(4) DEFAULT '0',
  `is_replied` tinyint(4) DEFAULT '0',
  `status` tinyint(4) DEFAULT '0',
  `created` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `fk_inquiries_user_id` (`user_id`),
  CONSTRAINT `fk_inquiries_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inquiries`
--

LOCK TABLES `inquiries` WRITE;
/*!40000 ALTER TABLE `inquiries` DISABLE KEYS */;
INSERT INTO `inquiries` VALUES (3,'test','sddkihgds',216,0,0,1,'2019-04-10 10:18:48'),(6,'Salary','bahut kam badate hai',219,0,0,1,'2019-04-10 10:21:14'),(7,'happy','kab kush honge',219,0,0,1,'2019-04-10 10:21:53'),(8,'happy','kab kush honge',215,0,0,1,'2019-04-10 10:22:05'),(9,'sad','I am very sad person',216,0,0,1,'2019-04-10 10:22:34'),(11,'sad','I am very sad and happy person',219,0,0,1,'2019-04-10 10:23:36'),(12,'Check one test','check testing one',235,0,0,1,'2019-04-10 13:46:43');
/*!40000 ALTER TABLE `inquiries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `site_config`
--

DROP TABLE IF EXISTS `site_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `term_text` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `site_config`
--

LOCK TABLES `site_config` WRITE;
/*!40000 ALTER TABLE `site_config` DISABLE KEYS */;
INSERT INTO `site_config` VALUES (1,'<p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of &quot;de Finibus Bonorum et Malorum&quot; (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, &quot;Lorem ipsum dolor sit amet..&quot;, comes from a line in section 1.10.32.</p><p>The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. Sections 1.10.32 and 1.10.33 from &quot;de Finibus Bonorum et Malorum&quot; by Cicero are also reproduced in their exact original form, accompanied by English versions from the 1914 translation by H. Rackham.</p>');
/*!40000 ALTER TABLE `site_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `static_pages`
--

DROP TABLE IF EXISTS `static_pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `static_pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `page_title` varchar(255) NOT NULL,
  `page_description` text NOT NULL,
  `slug` varchar(255) NOT NULL,
  `status` tinyint(4) DEFAULT '1',
  `created` datetime DEFAULT CURRENT_TIMESTAMP,
  `modified` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `static_pages`
--

LOCK TABLES `static_pages` WRITE;
/*!40000 ALTER TABLE `static_pages` DISABLE KEYS */;
INSERT INTO `static_pages` VALUES (1,'hello test 12','hello testing 45','hello-test',0,'2019-04-09 08:50:24','2019-04-16 05:33:01'),(2,'page testing name','it is a testing','page-testing',0,'2019-04-09 09:04:09','2019-04-10 08:01:57'),(4,'PAGE 2','it is a testing','page',1,'2019-04-09 09:33:36','2019-04-09 09:33:36'),(5,'PAGE 2','it is a testing','page-5',1,'2019-04-09 09:34:27','2019-04-09 09:34:27'),(6,'PAGE 3','it is a testing','page-6',1,'2019-04-09 09:35:55','2019-04-09 09:35:55'),(7,'PAGE 8','hello for testing','page-7',1,'2019-04-09 09:36:17','2019-04-10 06:31:15'),(9,'hello test jvv','testing check','hello-test-jvv-9',1,'2019-04-09 12:48:10','2019-04-09 12:51:50'),(17,'chekcersf','sddsgdsg','chekcer-undefined-17',1,'2019-04-10 06:59:03','2019-04-10 07:20:51'),(18,'ffrf','hfdd','ffrf-undefined-18',1,'2019-04-10 07:01:13','2019-04-10 07:20:51'),(19,'hllog','fgdfesss','hllog-undefined-19',1,'2019-04-10 07:03:02','2019-04-10 07:20:52'),(20,'tesintgse','kaise ho testgsgd','tesintgse-undefined-20',1,'2019-04-10 07:06:23','2019-04-10 07:20:52'),(21,'sfsdh','fhdfdfdg','sfsdh-undefined-21',1,'2019-04-10 07:12:14','2019-04-10 07:20:52'),(22,'kuiyu','khggy','kuiyu-undefined-22',1,'2019-04-10 07:13:36','2019-04-10 07:20:53'),(23,'afrn','sf','afrn-undefined-23',1,'2019-04-10 07:13:51','2019-04-10 07:51:41'),(24,'about us page s','this is about us page','about-us-page-undefined-24',1,'2019-04-10 07:52:09','2019-04-11 06:48:37'),(25,'dfs','dgdffgdf','dfs-undefined-25',1,'2019-04-11 06:48:20','2019-04-11 06:48:20'),(26,'Testing 3','Hello How are you','testing-3-undefined-26',1,'2019-04-16 05:34:07','2019-04-16 05:34:07');
/*!40000 ALTER TABLE `static_pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `temp`
--

DROP TABLE IF EXISTS `temp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `temp` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ts` timestamp NULL DEFAULT NULL,
  `dt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `temp`
--

LOCK TABLES `temp` WRITE;
/*!40000 ALTER TABLE `temp` DISABLE KEYS */;
INSERT INTO `temp` VALUES (10,'0000-00-00 00:00:00','2019-04-17 07:13:44');
/*!40000 ALTER TABLE `temp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_favourite_offers`
--

DROP TABLE IF EXISTS `user_favourite_offers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_favourite_offers` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `business_offer_id` bigint(20) DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `business_location_id` bigint(20) DEFAULT NULL,
  `business_location_address_id` bigint(20) DEFAULT NULL,
  `status` tinyint(4) DEFAULT '1',
  `created` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `fk_user_favourite_offers_user_id` (`user_id`),
  KEY `fk_user_favourite_offers_business_offer_id` (`business_offer_id`),
  CONSTRAINT `fk_user_favourite_offers_business_offer_id` FOREIGN KEY (`business_offer_id`) REFERENCES `business_offers` (`id`),
  CONSTRAINT `fk_user_favourite_offers_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_favourite_offers`
--

LOCK TABLES `user_favourite_offers` WRITE;
/*!40000 ALTER TABLE `user_favourite_offers` DISABLE KEYS */;
INSERT INTO `user_favourite_offers` VALUES (19,69,221,37,29,1,'2019-04-11 06:18:06'),(21,69,234,37,29,1,'2019-04-15 05:26:46'),(26,72,225,43,32,1,'2019-04-16 11:03:06'),(30,69,225,37,29,1,'2019-04-17 06:01:46');
/*!40000 ALTER TABLE `user_favourite_offers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_offer_loyalty_point_history`
--

DROP TABLE IF EXISTS `user_offer_loyalty_point_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_offer_loyalty_point_history` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) DEFAULT NULL,
  `business_location_id` bigint(20) DEFAULT NULL,
  `business_location_address_id` bigint(20) DEFAULT NULL,
  `business_offer_id` bigint(20) DEFAULT NULL,
  `point` int(11) DEFAULT NULL,
  `status` tinyint(4) DEFAULT '1',
  `created` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_offer_loyalty_point_history`
--

LOCK TABLES `user_offer_loyalty_point_history` WRITE;
/*!40000 ALTER TABLE `user_offer_loyalty_point_history` DISABLE KEYS */;
INSERT INTO `user_offer_loyalty_point_history` VALUES (1,226,37,29,69,1,1,'2019-04-12 05:55:34'),(2,226,37,29,69,1,1,'2019-04-12 05:55:34'),(3,226,37,29,69,1,1,'2019-04-15 07:01:17'),(4,226,37,29,69,1,1,'2019-04-16 06:22:36'),(5,226,37,29,69,1,1,'2019-04-16 06:23:01'),(6,234,37,29,69,1,1,'2019-04-16 06:23:35'),(7,234,37,29,69,1,1,'2019-04-16 06:49:50'),(8,234,37,29,69,1,1,'2019-04-16 08:40:45'),(9,234,37,29,69,1,1,'2019-04-16 08:41:39'),(10,234,37,29,69,1,1,'2019-04-16 08:43:46'),(11,234,37,29,69,1,1,'2019-04-16 08:44:46'),(12,221,37,30,69,1,1,'2019-04-17 06:51:51'),(13,226,37,30,69,1,1,'2019-04-17 06:57:38'),(14,226,37,30,69,1,1,'2019-04-17 06:59:19'),(15,226,37,30,69,1,1,'2019-04-17 06:59:57'),(16,226,37,30,69,1,1,'2019-04-17 07:00:25'),(17,226,37,30,69,1,1,'2019-04-17 07:00:30'),(18,226,37,30,69,1,1,'2019-04-17 07:00:33'),(19,226,37,30,69,1,1,'2019-04-17 07:00:35'),(20,226,37,30,69,1,1,'2019-04-17 07:00:37'),(21,226,37,30,69,1,1,'2019-04-17 07:00:39'),(22,226,37,30,69,1,1,'2019-04-17 07:00:41'),(23,225,43,32,72,1,1,'2019-04-17 09:13:01'),(24,225,43,32,72,1,1,'2019-04-17 09:26:49'),(25,225,43,32,72,1,1,'2019-04-17 10:46:27'),(26,225,43,32,72,1,1,'2019-04-17 11:11:44'),(27,225,43,32,72,1,1,'2019-04-17 11:22:47'),(28,225,43,32,82,1,1,'2019-04-17 11:40:09'),(29,225,43,32,82,1,1,'2019-04-17 11:48:22'),(30,225,43,32,82,1,1,'2019-04-17 11:51:57'),(31,225,43,33,86,1,1,'2019-04-17 12:41:02'),(32,225,43,33,83,1,1,'2019-04-17 12:44:12'),(33,225,43,33,83,1,1,'2019-04-17 12:53:28'),(34,225,43,33,83,1,1,'2019-04-17 13:01:21'),(35,225,43,33,83,1,1,'2019-04-17 13:01:35'),(36,225,43,33,83,1,1,'2019-04-17 13:08:43'),(37,225,43,33,83,1,1,'2019-04-17 13:16:50'),(38,225,43,33,83,1,1,'2019-04-17 13:26:42'),(39,225,43,33,83,1,1,'2019-04-17 13:30:06'),(40,225,43,33,83,1,1,'2019-04-17 13:31:19'),(41,225,43,33,83,1,1,'2019-04-17 13:34:35'),(42,225,43,33,83,1,1,'2019-04-17 13:35:36');
/*!40000 ALTER TABLE `user_offer_loyalty_point_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_offer_loyalty_points`
--

DROP TABLE IF EXISTS `user_offer_loyalty_points`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_offer_loyalty_points` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) DEFAULT NULL,
  `business_location_id` bigint(20) DEFAULT NULL,
  `business_location_address_id` bigint(20) DEFAULT NULL,
  `business_offer_id` bigint(20) DEFAULT NULL,
  `points` int(11) DEFAULT '0',
  `status` varchar(45) DEFAULT '1',
  `created` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_offer_loyalty_points`
--

LOCK TABLES `user_offer_loyalty_points` WRITE;
/*!40000 ALTER TABLE `user_offer_loyalty_points` DISABLE KEYS */;
INSERT INTO `user_offer_loyalty_points` VALUES (14,226,37,29,69,6,'1','2019-04-12 05:55:34'),(15,234,37,29,69,6,'1','2019-04-16 06:23:35'),(16,221,37,30,69,10,'1','2019-04-17 06:51:51'),(17,226,37,30,69,10,'1','2019-04-17 06:57:38'),(18,225,43,32,72,5,'1','2019-04-17 09:13:01'),(19,225,43,32,82,3,'1','2019-04-17 11:40:09'),(20,225,43,33,86,1,'1','2019-04-17 12:41:02'),(21,225,43,33,83,11,'1','2019-04-17 12:44:12');
/*!40000 ALTER TABLE `user_offer_loyalty_points` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_profile`
--

DROP TABLE IF EXISTS `user_profile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_profile` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `profile_picture` varchar(255) DEFAULT NULL,
  `mobile_number` varchar(255) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `social_id` varchar(2000) DEFAULT NULL,
  `social_image` varchar(2000) DEFAULT NULL,
  `social_login_type` varchar(20) DEFAULT NULL,
  `verification_token` varchar(2000) DEFAULT NULL,
  `password_reset_token` varchar(2000) DEFAULT NULL,
  `device_type` varchar(255) DEFAULT NULL,
  `device_token` varchar(1000) DEFAULT NULL,
  `latitude` decimal(10,8) DEFAULT NULL,
  `longitude` decimal(10,8) DEFAULT NULL,
  `address` varchar(1000) DEFAULT NULL,
  `gender` varchar(15) DEFAULT NULL,
  `status` tinyint(4) DEFAULT '0',
  `created` datetime DEFAULT CURRENT_TIMESTAMP,
  `modified` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `fk_user_profile` (`user_id`),
  CONSTRAINT `fk_user_profile` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=244 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_profile`
--

LOCK TABLES `user_profile` WRITE;
/*!40000 ALTER TABLE `user_profile` DISABLE KEYS */;
INSERT INTO `user_profile` VALUES (206,'Sansa Stark','','1234567','2001-05-18',215,NULL,NULL,NULL,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJkYXRhIjp7ImlkIjpudWxsLCJlbWFpbCI6ImphbnNlbjYxMUBtYWlsaW5hdG9yLmNvbSIsInBhc3N3b3JkIjoiUGFzc3dvcmRAMTIzNCIsIm5hbWUiOiJTYW5zYSBTdGFyayIsImpvYl90aXRsZSI6IiIsImJ1c2luZXNzX25hbWUiOiIiLCJ0ZWxlcGhvbmVfbnVtYmVyIjoiIiwiY2l0eSI6IiIsImxhdGl0dWRlIjoiIiwibG9uZ2l0dWRlIjoiIiwiZGV2aWNlX3R5cGUiOiIiLCJkZXZpY2VfdG9rZW4iOiIiLCJidXNpbmVzc190eXBlIjoiIiwibGluayI6IiIsInZlcmlmaWNhdGlvbl90b2tlbiI6IiIsImVtYWlsX2NvbmZpcm1lZCI6MCwiZW1haWxfdmVyaWZpZWQiOjAsInZlcmlmaWNhdGlvblR5cGUiOiJlbWFpbC12ZXJpZmljYXRpb24iLCJ1c2VyX3R5cGVfaWQiOjN9LCJpYXQiOjE1NTI5OTcxNjMsImV4cCI6MTU1MzYwMTk2M30.KfcYawCzMi1npnLlXeZOvoPW9YU478QmzyrVs3jmisI',NULL,'','',NULL,NULL,'','M',1,'2019-03-19 12:06:02','2019-03-19 12:06:02'),(207,'Meeta Mehta','','','1990-12-09',216,'1561000560698910','https://graph.facebook.com/1561000560698910/picture?type=large','facebook','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJkYXRhIjp7ImlkIjpudWxsLCJlbWFpbCI6Im1lZXRhLm1laHRhQGRvdHNxdWFyZXMuY29tIiwicGFzc3dvcmQiOiJ5YWxnb19zdXBlcl9zZWNyZXRAMzQ1S0xQIiwibmFtZSI6Ik1lZXRhIE1laHRhIiwiam9iX3RpdGxlIjoiIiwiYnVzaW5lc3NfbmFtZSI6IiIsInRlbGVwaG9uZV9udW1iZXIiOiIiLCJjaXR5IjoiIiwibGF0aXR1ZGUiOm51bGwsImxvbmdpdHVkZSI6bnVsbCwiZGV2aWNlX3R5cGUiOiJhbmRyb2lkIiwiZGV2aWNlX3Rva2VuIjoiMTIzIiwiYnVzaW5lc3NfdHlwZSI6IiIsImxpbmsiOiIiLCJ2ZXJpZmljYXRpb25fdG9rZW4iOiIiLCJlbWFpbF9jb25maXJtZWQiOjEsImVtYWlsX3ZlcmlmaWVkIjoxLCJ2ZXJpZmljYXRpb25UeXBlIjoiZW1haWwtdmVyaWZpY2F0aW9uIiwidXNlcl90eXBlX2lkIjozfSwiaWF0IjoxNTUyOTk3MzM4LCJleHAiOjE1NTM2MDIxMzh9.VEwmXkHrcHIbog2nneakTKHoYbPrmMLtPh3ZSx0EkLA',NULL,'android','123',NULL,NULL,'','O',0,'2019-03-19 12:08:58','2019-03-19 12:08:58'),(208,'Meeta Mehta','','3213','1990-11-12',217,'2872533422758584','https://graph.facebook.com/2872533422758584/picture?type=large','facebook','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJkYXRhIjp7ImlkIjpudWxsLCJlbWFpbCI6Im1laHRhLm1lZXRhODVAZ21haWwuY29tIiwicGFzc3dvcmQiOiJ5YWxnb19zdXBlcl9zZWNyZXRAMzQ1S0xQIiwibmFtZSI6Ik1lZXRhIE1laHRhIiwiam9iX3RpdGxlIjoiIiwiYnVzaW5lc3NfbmFtZSI6IiIsInRlbGVwaG9uZV9udW1iZXIiOiIiLCJjaXR5IjoiIiwibGF0aXR1ZGUiOm51bGwsImxvbmdpdHVkZSI6bnVsbCwiZGV2aWNlX3R5cGUiOiJhbmRyb2lkIiwiZGV2aWNlX3Rva2VuIjoiMTIzIiwiYnVzaW5lc3NfdHlwZSI6IiIsImxpbmsiOiIiLCJ2ZXJpZmljYXRpb25fdG9rZW4iOiIiLCJlbWFpbF9jb25maXJtZWQiOjEsImVtYWlsX3ZlcmlmaWVkIjoxLCJ2ZXJpZmljYXRpb25UeXBlIjoiZW1haWwtdmVyaWZpY2F0aW9uIiwidXNlcl90eXBlX2lkIjozfSwiaWF0IjoxNTUyOTk3NDM4LCJleHAiOjE1NTM2MDIyMzh9.y0l_ZP1lxyTml_LpRl90WwKOgvb0GJVKjiAkJrC11sg',NULL,'android','123',NULL,NULL,'dasdsad','M',1,'2019-03-19 12:10:38','2019-03-19 12:10:38'),(209,'meeta',NULL,NULL,'1990-12-11',218,NULL,NULL,NULL,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJkYXRhIjp7ImlkIjpudWxsLCJlbWFpbCI6Im1lZXRhQG1haWxpbmF0b3IuY29tIiwicGFzc3dvcmQiOiJUZXN0QDE5ODUiLCJuYW1lIjoibWVldGEiLCJqb2JfdGl0bGUiOiIiLCJidXNpbmVzc19uYW1lIjoiIiwidGVsZXBob25lX251bWJlciI6IiIsImNpdHkiOiIiLCJsYXRpdHVkZSI6MCwibG9uZ2l0dWRlIjowLCJkZXZpY2VfdHlwZSI6ImFuZHJvaWQiLCJkZXZpY2VfdG9rZW4iOiIxMjMiLCJidXNpbmVzc190eXBlIjoiIiwibGluayI6IiIsInZlcmlmaWNhdGlvbl90b2tlbiI6IiIsImVtYWlsX2NvbmZpcm1lZCI6MCwiZW1haWxfdmVyaWZpZWQiOjAsInZlcmlmaWNhdGlvblR5cGUiOiJlbWFpbC12ZXJpZmljYXRpb24iLCJ1c2VyX3R5cGVfaWQiOjN9LCJpYXQiOjE1NTI5OTc1MDksImV4cCI6MTU1MzYwMjMwOX0.Tw4BBUfkl3Liz13LBvSB3qKzoUizQjK7ungbpbht1yc',NULL,'android','123',0.00000000,0.00000000,NULL,'M',0,'2019-03-19 12:11:49','2019-03-19 12:11:49'),(210,'Sansa Stark',NULL,NULL,'1990-12-11',219,NULL,NULL,NULL,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJkYXRhIjp7ImlkIjpudWxsLCJlbWFpbCI6ImphbnNlbjZAbWFpbGluYXRvci5jb20iLCJwYXNzd29yZCI6IlBhc3N3b3JkQDEyMzQiLCJuYW1lIjoiU2Fuc2EgU3RhcmsiLCJqb2JfdGl0bGUiOiIiLCJidXNpbmVzc19uYW1lIjoiIiwidGVsZXBob25lX251bWJlciI6IiIsImNpdHkiOiIiLCJsYXRpdHVkZSI6IiIsImxvbmdpdHVkZSI6IiIsImRldmljZV90eXBlIjoiIiwiZGV2aWNlX3Rva2VuIjoiIiwiYnVzaW5lc3NfdHlwZSI6IiIsImxpbmsiOiIiLCJ2ZXJpZmljYXRpb25fdG9rZW4iOiIiLCJlbWFpbF9jb25maXJtZWQiOjAsImVtYWlsX3ZlcmlmaWVkIjowLCJ2ZXJpZmljYXRpb25UeXBlIjoiZW1haWwtdmVyaWZpY2F0aW9uIiwidXNlcl90eXBlX2lkIjozfSwiaWF0IjoxNTUzMDAwNTU2LCJleHAiOjE1NTM2MDUzNTZ9.8Sgu30z4AeHeJPBLG3Gfs4Vs4nesqgwlBRSh8adfmb0','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJkYXRhIjp7ImVtYWlsIjoiamFuc2VuNkBtYWlsaW5hdG9yLmNvbSIsImVtYWlsX2NvbmZpcm1lZCI6MSwiYWNjb3VudF9kZWxldGVkIjowLCJzdGF0dXMiOjEsImFkbWluX2RlbGV0ZWQiOjAsInVzZXJfdHlwZV9pZCI6MywibmFtZSI6IlNhbnNhIFN0YXJrIiwidmVyaWZpY2F0aW9uVHlwZSI6ImZvcmdvdC1wYXNzd29yZCJ9LCJpYXQiOjE1NTMwMDE0MTcsImV4cCI6MTU1MzAwNTAxN30.diG_RD5V8GPodWq87n97uOyJ1T_OgpuJoQNFvOOPAGQ','','',0.00000000,0.00000000,NULL,'M',0,'2019-03-19 13:02:36','2019-03-19 13:02:36'),(211,'yalgo individual',NULL,NULL,'1990-12-11',220,NULL,NULL,NULL,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJkYXRhIjp7ImlkIjpudWxsLCJlbWFpbCI6InlhbGdvQG1haWxpbmF0b3IuY29tIiwicGFzc3dvcmQiOiJUZXN0QDEyMzQiLCJuYW1lIjoieWFsZ28gaW5kaXZpZHVhbCIsImpvYl90aXRsZSI6IiIsImJ1c2luZXNzX25hbWUiOiIiLCJ0ZWxlcGhvbmVfbnVtYmVyIjoiIiwiY2l0eSI6IiIsImxhdGl0dWRlIjowLCJsb25naXR1ZGUiOjAsImRldmljZV90eXBlIjoiYW5kcm9pZCIsImRldmljZV90b2tlbiI6IjEyMyIsImJ1c2luZXNzX3R5cGUiOiIiLCJsaW5rIjoiIiwidmVyaWZpY2F0aW9uX3Rva2VuIjoiIiwiZW1haWxfY29uZmlybWVkIjowLCJlbWFpbF92ZXJpZmllZCI6MCwidmVyaWZpY2F0aW9uVHlwZSI6ImVtYWlsLXZlcmlmaWNhdGlvbiIsInVzZXJfdHlwZV9pZCI6M30sImlhdCI6MTU1MzAwMTczMCwiZXhwIjoxNTUzNjA2NTMwfQ.PBkKxUMWGww6e5g5p0ZwLptTq1fGH3XgVYundVQDRsQ',NULL,'android','123',0.00000000,0.00000000,NULL,'M',0,'2019-03-19 13:22:10','2019-03-19 13:22:10'),(212,'Sansa Stark',NULL,NULL,'1990-12-11',221,NULL,NULL,NULL,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJkYXRhIjp7ImlkIjpudWxsLCJlbWFpbCI6InNhbWFudGhhMTAwQG1haWxpbmF0b3IuY29tIiwicGFzc3dvcmQiOiJQYXNzd29yZEAxMjMiLCJuYW1lIjoiU2Fuc2EgU3RhcmsiLCJqb2JfdGl0bGUiOiJQbGF5ZXIiLCJidXNpbmVzc19uYW1lIjoiUGxheXdvb2QiLCJ0ZWxlcGhvbmVfbnVtYmVyIjoiMTIzNDU2IiwiY2l0eSI6Ik5vcnRoIiwibGF0aXR1ZGUiOm51bGwsImxvbmdpdHVkZSI6bnVsbCwiZGV2aWNlX3R5cGUiOiIiLCJkZXZpY2VfdG9rZW4iOiIiLCJidXNpbmVzc190eXBlIjoiIiwibGluayI6IiIsInZlcmlmaWNhdGlvbl90b2tlbiI6IiIsImVtYWlsX2NvbmZpcm1lZCI6MCwiZW1haWxfdmVyaWZpZWQiOjAsInZlcmlmaWNhdGlvblR5cGUiOiJlbWFpbC12ZXJpZmljYXRpb24iLCJ1c2VyX3R5cGVfaWQiOjJ9LCJpYXQiOjE1NTMwMDE5NzksImV4cCI6MTU1MzYwNjc3OX0.l2p1v9Wt9qXpotGbv8C3fffHZ_HcIUMe_15nz_yen9w',NULL,'','',0.00000000,0.00000000,NULL,'M',0,'2019-03-19 13:26:19','2019-03-19 13:26:19'),(213,'nipun','','123','1990-11-12',222,NULL,NULL,NULL,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJkYXRhIjp7ImlkIjpudWxsLCJlbWFpbCI6Im5pcHVuQHlvcG1haWwuY29tIiwicGFzc3dvcmQiOiJOaXB1bkAxOTkyIiwibmFtZSI6Im5pcHVuIiwiam9iX3RpdGxlIjoiIiwiYnVzaW5lc3NfbmFtZSI6IiIsInRlbGVwaG9uZV9udW1iZXIiOiIiLCJjaXR5IjoiIiwibGF0aXR1ZGUiOiIwLjAiLCJsb25naXR1ZGUiOiIwLjAiLCJkZXZpY2VfdHlwZSI6ImlPUyIsImRldmljZV90b2tlbiI6IjEyMzQ1NiIsImJ1c2luZXNzX3R5cGUiOiIiLCJsaW5rIjoiIiwidmVyaWZpY2F0aW9uX3Rva2VuIjoiIiwiZW1haWxfY29uZmlybWVkIjowLCJlbWFpbF92ZXJpZmllZCI6MCwidmVyaWZpY2F0aW9uVHlwZSI6ImVtYWlsLXZlcmlmaWNhdGlvbiIsInVzZXJfdHlwZV9pZCI6M30sImlhdCI6MTU1MzA1ODE5MiwiZXhwIjoxNTUzNjYyOTkyfQ.YD4r0tIahLexTvyTMIyg3mTlgz4rHyxDQv5aMSvhxtY',NULL,'iOS','123456',NULL,NULL,'null','M',1,'2019-03-20 05:03:12','2019-03-20 05:03:12'),(214,'Sansa Stark',NULL,NULL,'1990-12-11',223,NULL,NULL,NULL,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJkYXRhIjp7ImlkIjpudWxsLCJlbWFpbCI6InNhbWFudGhhMTAxQG1haWxpbmF0b3IuY29tIiwicGFzc3dvcmQiOiJQYXNzd29yZEAxMjMiLCJuYW1lIjoiU2Fuc2EgU3RhcmsiLCJqb2JfdGl0bGUiOiJQbGF5ZXIiLCJidXNpbmVzc19uYW1lIjoiUGxheXdvb2QiLCJ0ZWxlcGhvbmVfbnVtYmVyIjoiMTIzNDU2IiwiY2l0eSI6Ik5vcnRoIiwibGF0aXR1ZGUiOm51bGwsImxvbmdpdHVkZSI6bnVsbCwiZGV2aWNlX3R5cGUiOiIiLCJkZXZpY2VfdG9rZW4iOiIiLCJidXNpbmVzc190eXBlIjoiIiwibGluayI6IiIsInZlcmlmaWNhdGlvbl90b2tlbiI6IiIsImVtYWlsX2NvbmZpcm1lZCI6MCwiZW1haWxfdmVyaWZpZWQiOjAsInZlcmlmaWNhdGlvblR5cGUiOiJlbWFpbC12ZXJpZmljYXRpb24iLCJ1c2VyX3R5cGVfaWQiOjJ9LCJpYXQiOjE1NTMyMzU1NTMsImV4cCI6MTU1Mzg0MDM1M30.itdrhwtq7n6zmMMsF3Ln09cDmQmuN2pGTxKxATnbXZM',NULL,'','',0.00000000,0.00000000,NULL,'M',0,'2019-03-22 06:19:13','2019-03-22 06:19:13'),(215,'David Cusworth',NULL,NULL,'1990-12-11',224,NULL,NULL,NULL,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJkYXRhIjp7ImlkIjpudWxsLCJlbWFpbCI6ImRhdmlkX2N1c3dvcnRoQG1haWxpbmF0b3IuY29tIiwicGFzc3dvcmQiOiJQYXNzd29yZEAxMjM0IiwibmFtZSI6IkRhdmlkIEN1c3dvcnRoIiwiam9iX3RpdGxlIjoiIiwiYnVzaW5lc3NfbmFtZSI6IiIsInRlbGVwaG9uZV9udW1iZXIiOiIiLCJjaXR5IjoiIiwibGF0aXR1ZGUiOiIiLCJsb25naXR1ZGUiOiIiLCJkZXZpY2VfdHlwZSI6IiIsImRldmljZV90b2tlbiI6IiIsImJ1c2luZXNzX3R5cGUiOiIiLCJsaW5rIjoiIiwidmVyaWZpY2F0aW9uX3Rva2VuIjoiIiwiZW1haWxfY29uZmlybWVkIjowLCJlbWFpbF92ZXJpZmllZCI6MCwidmVyaWZpY2F0aW9uVHlwZSI6ImVtYWlsLXZlcmlmaWNhdGlvbiIsInVzZXJfdHlwZV9pZCI6M30sImlhdCI6MTU1MzI0MjQ2NywiZXhwIjoxNTUzODQ3MjY3fQ.8DQpKOq_XPMyqVL5w2REJbQbUoQ4NGKwWQm5V-yFyUM',NULL,'','',0.00000000,0.00000000,NULL,'M',0,'2019-03-22 08:14:27','2019-03-22 08:14:27'),(216,'Customer edit','media/customer/avtar/1555400033904.jpg','','2003-04-13',225,NULL,NULL,NULL,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJkYXRhIjp7ImlkIjpudWxsLCJlbWFpbCI6InRlc3RAbWFpbGluYXRvci5jb20iLCJwYXNzd29yZCI6IlRlc3RAMTIzIiwibmFtZSI6InRlc3QiLCJqb2JfdGl0bGUiOiIiLCJidXNpbmVzc19uYW1lIjoiIiwidGVsZXBob25lX251bWJlciI6IiIsImNpdHkiOiIiLCJsYXRpdHVkZSI6MCwibG9uZ2l0dWRlIjowLCJkZXZpY2VfdHlwZSI6ImFuZHJvaWQiLCJkZXZpY2VfdG9rZW4iOiIxMjMiLCJidXNpbmVzc190eXBlIjoiIiwibGluayI6IiIsInZlcmlmaWNhdGlvbl90b2tlbiI6IiIsImVtYWlsX2NvbmZpcm1lZCI6MCwiZW1haWxfdmVyaWZpZWQiOjAsInZlcmlmaWNhdGlvblR5cGUiOiJlbWFpbC12ZXJpZmljYXRpb24iLCJ1c2VyX3R5cGVfaWQiOjN9LCJpYXQiOjE1NTM0ODk3NTAsImV4cCI6MTU1NDA5NDU1MH0.7lNUw9eNE2fUsvf-0FWeqMcZzjqpzYRoo7vMLrGApKs','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJkYXRhIjp7ImVtYWlsIjoidGVzdEBtYWlsaW5hdG9yLmNvbSIsImVtYWlsX2NvbmZpcm1lZCI6MSwiYWNjb3VudF9kZWxldGVkIjowLCJzdGF0dXMiOjEsImFkbWluX2RlbGV0ZWQiOjAsInVzZXJfdHlwZV9pZCI6MywibmFtZSI6InNic2dzdnNiIiwidmVyaWZpY2F0aW9uVHlwZSI6ImZvcmdvdC1wYXNzd29yZCJ9LCJpYXQiOjE1NTM2ODkzODYsImV4cCI6MTU1MzY5Mjk4Nn0.TeEbKnyWSiJnnYx3g9L70EqgQQKiRgpIds_YmIB9Hpo','android','123',NULL,NULL,'Dotsquares Jhalana Office','0',0,'2019-03-25 04:55:50','2019-03-25 04:55:50'),(217,'Jarivs','media/customer/avtar/1553687633842.jpg','844848484948','1998-03-11',226,NULL,NULL,NULL,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJkYXRhIjp7ImlkIjpudWxsLCJlbWFpbCI6ImphbnNlbjYwQG1haWxpbmF0b3IuY29tIiwicGFzc3dvcmQiOiJQYXNzd29yZEAxMjM0IiwibmFtZSI6IlNhbnNhIFN0YXJrIiwiam9iX3RpdGxlIjoiIiwiYnVzaW5lc3NfbmFtZSI6IiIsInRlbGVwaG9uZV9udW1iZXIiOiIiLCJjaXR5IjoiIiwibGF0aXR1ZGUiOiIiLCJsb25naXR1ZGUiOiIiLCJkZXZpY2VfdHlwZSI6IiIsImRldmljZV90b2tlbiI6IiIsImJ1c2luZXNzX3R5cGUiOiIiLCJsaW5rIjoiIiwidmVyaWZpY2F0aW9uX3Rva2VuIjoiIiwiZW1haWxfY29uZmlybWVkIjowLCJlbWFpbF92ZXJpZmllZCI6MCwidmVyaWZpY2F0aW9uVHlwZSI6ImVtYWlsLXZlcmlmaWNhdGlvbiIsInVzZXJfdHlwZV9pZCI6M30sImlhdCI6MTU1MzUxMTU4OSwiZXhwIjoxNTU0MTE2Mzg5fQ.8GK2WMbGSRvO-PDqO-KHQV_UaopM8E9fPwUMt-JRH7U',NULL,'','',NULL,NULL,'Jawahar Lal Nehru Marg, D-Block, Malviya Nagar, Jaipur, Rajasthan 302017, India','F',1,'2019-03-25 10:59:48','2019-03-25 10:59:48'),(218,'Tushar',NULL,NULL,'1990-12-11',227,NULL,NULL,NULL,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJkYXRhIjp7ImlkIjpudWxsLCJlbWFpbCI6ImNvZmZlZUB5b3BtYWlsLmNvbSIsInBhc3N3b3JkIjoiQ29mZmVlQDE5OTIiLCJuYW1lIjoiVHVzaGFyIiwiam9iX3RpdGxlIjoiTWFuYWdlciIsImJ1c2luZXNzX25hbWUiOiJDb2ZmZSBTaG9wIiwidGVsZXBob25lX251bWJlciI6Ijk3ODIzNTczNDMiLCJjaXR5IjoiSmFpcHVyIiwibGF0aXR1ZGUiOm51bGwsImxvbmdpdHVkZSI6bnVsbCwiZGV2aWNlX3R5cGUiOiIiLCJkZXZpY2VfdG9rZW4iOiIiLCJidXNpbmVzc190eXBlIjoiIiwibGluayI6IiIsInZlcmlmaWNhdGlvbl90b2tlbiI6IiIsImVtYWlsX2NvbmZpcm1lZCI6MCwiZW1haWxfdmVyaWZpZWQiOjAsInZlcmlmaWNhdGlvblR5cGUiOiJlbWFpbC12ZXJpZmljYXRpb24iLCJ1c2VyX3R5cGVfaWQiOjJ9LCJpYXQiOjE1NTM1MTMzMDYsImV4cCI6MTU1NDExODEwNn0.wXc_34PUMNbsnh3J9ppP_g07uynFnM5BYFqh2PmyFOY',NULL,'','',0.00000000,0.00000000,NULL,'M',0,'2019-03-25 11:28:26','2019-03-25 11:28:26'),(219,'Tushar',NULL,NULL,'1990-12-11',228,NULL,NULL,NULL,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJkYXRhIjp7ImlkIjpudWxsLCJlbWFpbCI6ImFyb3JhQHlvcG1haWwuY29tIiwicGFzc3dvcmQiOiJBcm9yYUAxOTkyIiwibmFtZSI6IlR1c2hhciIsImpvYl90aXRsZSI6IlNlcnZpY2UgTWFuYWdlciIsImJ1c2luZXNzX25hbWUiOiJDb2ZmZWUgUG9pbnQiLCJ0ZWxlcGhvbmVfbnVtYmVyIjoiOTc4MjM1NzM0MyIsImNpdHkiOiJHYW5nYW5hZ2FyIiwibGF0aXR1ZGUiOm51bGwsImxvbmdpdHVkZSI6bnVsbCwiZGV2aWNlX3R5cGUiOiIiLCJkZXZpY2VfdG9rZW4iOiIiLCJidXNpbmVzc190eXBlIjoiIiwibGluayI6IiIsInZlcmlmaWNhdGlvbl90b2tlbiI6IiIsImVtYWlsX2NvbmZpcm1lZCI6MCwiZW1haWxfdmVyaWZpZWQiOjAsInZlcmlmaWNhdGlvblR5cGUiOiJlbWFpbC12ZXJpZmljYXRpb24iLCJ1c2VyX3R5cGVfaWQiOjJ9LCJpYXQiOjE1NTM1NzkzMDQsImV4cCI6MTU1NDE4NDEwNH0.D2wkfdqeg9KHQ_UxsfPbMPI1fjT46nEOYERURGjkeQs',NULL,'','',0.00000000,0.00000000,NULL,'M',0,'2019-03-26 05:48:24','2019-03-26 05:48:24'),(220,'Murli',NULL,NULL,NULL,229,NULL,NULL,NULL,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJkYXRhIjp7ImlkIjpudWxsLCJlbWFpbCI6Im11cmxpQHlvcG1haWwuY29tIiwicGFzc3dvcmQiOiJNdXJsaUAxOTkyIiwibmFtZSI6Ik11cmxpIiwiam9iX3RpdGxlIjoiTWFuYWdlciIsImJ1c2luZXNzX25hbWUiOiJDb2ZmZWUgU2hvcCIsInRlbGVwaG9uZV9udW1iZXIiOiI3ODQ1MTI0NTc4IiwiY2l0eSI6IkphaXB1ciIsImxhdGl0dWRlIjpudWxsLCJsb25naXR1ZGUiOm51bGwsImRldmljZV90eXBlIjoiIiwiZGV2aWNlX3Rva2VuIjoiIiwiYnVzaW5lc3NfdHlwZSI6IiIsImxpbmsiOiIiLCJ2ZXJpZmljYXRpb25fdG9rZW4iOiIiLCJlbWFpbF9jb25maXJtZWQiOjAsImVtYWlsX3ZlcmlmaWVkIjowLCJ2ZXJpZmljYXRpb25UeXBlIjoiZW1haWwtdmVyaWZpY2F0aW9uIiwidXNlcl90eXBlX2lkIjoyfSwiaWF0IjoxNTUzNjcwNTE0LCJleHAiOjE1NTQyNzUzMTR9.M6hSo1_dg0tpy910J-HUDJ59_y5LNFjnvnYVoyFtq1E','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJkYXRhIjp7ImVtYWlsIjoibXVybGlAeW9wbWFpbC5jb20iLCJlbWFpbF9jb25maXJtZWQiOjEsImFjY291bnRfZGVsZXRlZCI6MCwic3RhdHVzIjoxLCJhZG1pbl9kZWxldGVkIjowLCJ1c2VyX3R5cGVfaWQiOjIsIm5hbWUiOiJNdXJsaSIsInZlcmlmaWNhdGlvblR5cGUiOiJmb3Jnb3QtcGFzc3dvcmQifSwiaWF0IjoxNTU0Mjc2NDM1LCJleHAiOjE1NTQyODAwMzV9.wGJaxPa46egvO6p4Oz_xxYdQRSXvLhkvldxCKkl-KCk','','',0.00000000,0.00000000,NULL,NULL,0,'2019-03-27 07:08:34','2019-03-27 07:08:34'),(221,'new','','','0000-00-00',230,NULL,NULL,NULL,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJkYXRhIjp7ImlkIjpudWxsLCJlbWFpbCI6Im5ld0BtYWlsaW5hdG9yLmNvbSIsInBhc3N3b3JkIjoiVGVzdEAxMjMiLCJuYW1lIjoibmV3Iiwiam9iX3RpdGxlIjoiIiwiYnVzaW5lc3NfbmFtZSI6IiIsInRlbGVwaG9uZV9udW1iZXIiOiIiLCJjaXR5IjoiIiwibGF0aXR1ZGUiOjAsImxvbmdpdHVkZSI6MCwiZGV2aWNlX3R5cGUiOiJhbmRyb2lkIiwiZGV2aWNlX3Rva2VuIjoiMTIzIiwiYnVzaW5lc3NfdHlwZSI6IiIsImxpbmsiOiIiLCJ2ZXJpZmljYXRpb25fdG9rZW4iOiIiLCJlbWFpbF9jb25maXJtZWQiOjAsImVtYWlsX3ZlcmlmaWVkIjowLCJ2ZXJpZmljYXRpb25UeXBlIjoiZW1haWwtdmVyaWZpY2F0aW9uIiwidXNlcl90eXBlX2lkIjozfSwiaWF0IjoxNTUzNjkwNzkwLCJleHAiOjE1NTQyOTU1OTB9.t1q2dC4n_RODpPOluWdexVv8xjE2iUWMbWxML4fSDcc',NULL,'android','123',NULL,NULL,'','null',1,'2019-03-27 12:46:30','2019-03-27 12:46:30'),(222,'Jonathan Stark','','','0000-00-00',231,NULL,NULL,NULL,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJkYXRhIjp7ImlkIjpudWxsLCJlbWFpbCI6ImphbnNlbjYwMUBtYWlsaW5hdG9yLmNvbSIsInBhc3N3b3JkIjoiUGFzc3dvcmRAMTIzNCIsIm5hbWUiOiJKb25hdGhhbiBTdGFyayIsImpvYl90aXRsZSI6IiIsImJ1c2luZXNzX25hbWUiOiIiLCJ0ZWxlcGhvbmVfbnVtYmVyIjoiIiwiY2l0eSI6IiIsImxhdGl0dWRlIjoiIiwibG9uZ2l0dWRlIjoiIiwiZGV2aWNlX3R5cGUiOiIiLCJkZXZpY2VfdG9rZW4iOiIiLCJidXNpbmVzc190eXBlIjoiIiwibGluayI6IiIsInZlcmlmaWNhdGlvbl90b2tlbiI6IiIsImVtYWlsX2NvbmZpcm1lZCI6MCwiZW1haWxfdmVyaWZpZWQiOjAsInZlcmlmaWNhdGlvblR5cGUiOiJlbWFpbC12ZXJpZmljYXRpb24iLCJ1c2VyX3R5cGVfaWQiOjN9LCJpYXQiOjE1NTM3NTA3MzksImV4cCI6MTU1NDM1NTUzOX0.OliiPgs8vXBmDfGFaetQhmGZpRCe7YnXb1a4xbRuHIg','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJkYXRhIjp7ImVtYWlsIjoiamFuc2VuNjAxQG1haWxpbmF0b3IuY29tIiwiZW1haWxfY29uZmlybWVkIjoxLCJhY2NvdW50X2RlbGV0ZWQiOjAsInN0YXR1cyI6MSwiYWRtaW5fZGVsZXRlZCI6MCwidXNlcl90eXBlX2lkIjozLCJuYW1lIjoiSm9uYXRoYW4gU3RhcmsiLCJ2ZXJpZmljYXRpb25UeXBlIjoiZm9yZ290LXBhc3N3b3JkIn0sImlhdCI6MTU1Mzc1NTEwOSwiZXhwIjoxNTUzNzU4NzA5fQ.ZsviOijTxNYfseoznimbju0VlPGgM9e4PnpoAMwiats','','',NULL,NULL,'','M',1,'2019-03-28 05:25:39','2019-03-28 05:25:39'),(223,'Jonathan Stark','','','0000-00-00',232,NULL,NULL,NULL,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJkYXRhIjp7ImlkIjpudWxsLCJlbWFpbCI6ImphbnNlbjYwMkBtYWlsaW5hdG9yLmNvbSIsInBhc3N3b3JkIjoiUGFzc3dvcmRAMTIzNCIsIm5hbWUiOiJKb25hdGhhbiBTdGFyayIsImpvYl90aXRsZSI6IiIsImJ1c2luZXNzX25hbWUiOiIiLCJ0ZWxlcGhvbmVfbnVtYmVyIjoiIiwiY2l0eSI6IiIsImxhdGl0dWRlIjoiIiwibG9uZ2l0dWRlIjoiIiwiZGV2aWNlX3R5cGUiOiIiLCJkZXZpY2VfdG9rZW4iOiIiLCJidXNpbmVzc190eXBlIjoiIiwibGluayI6IiIsInZlcmlmaWNhdGlvbl90b2tlbiI6IiIsImVtYWlsX2NvbmZpcm1lZCI6MCwiZW1haWxfdmVyaWZpZWQiOjAsInZlcmlmaWNhdGlvblR5cGUiOiJlbWFpbC12ZXJpZmljYXRpb24iLCJ1c2VyX3R5cGVfaWQiOjN9LCJpYXQiOjE1NTM3NTU0MzQsImV4cCI6MTU1NDM2MDIzNH0.1jrCNle4HU8o-1wh4eOzuIgvKJZ9OMi4ecGRI45UeLs','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJkYXRhIjp7ImVtYWlsIjoiamFuc2VuNjAyQG1haWxpbmF0b3IuY29tIiwiZW1haWxfY29uZmlybWVkIjoxLCJhY2NvdW50X2RlbGV0ZWQiOjAsInN0YXR1cyI6MSwiYWRtaW5fZGVsZXRlZCI6MCwidXNlcl90eXBlX2lkIjozLCJuYW1lIjoiSm9uYXRoYW4gU3RhcmsiLCJ2ZXJpZmljYXRpb25UeXBlIjoiZm9yZ290LXBhc3N3b3JkIn0sImlhdCI6MTU1Mzc1NTQ3NiwiZXhwIjoxNTUzNzU5MDc2fQ.okIfJShN8m1Ahx7Zb8V3ZvIIduaCUUN8TQIbk7w-FNY','','',NULL,NULL,'','M',1,'2019-03-28 06:43:54','2019-03-28 06:43:54'),(224,'Tushar',NULL,NULL,NULL,233,NULL,NULL,NULL,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJkYXRhIjp7ImlkIjpudWxsLCJlbWFpbCI6InR1c2hhcjc3QHlvcG1haWwuY29tIiwicGFzc3dvcmQiOiJUdXNoYXJAMTk5MiIsIm5hbWUiOiJUdXNoYXIiLCJqb2JfdGl0bGUiOiIiLCJidXNpbmVzc19uYW1lIjoiIiwidGVsZXBob25lX251bWJlciI6IiIsImNpdHkiOiIiLCJsYXRpdHVkZSI6IjAuMCIsImxvbmdpdHVkZSI6IjAuMCIsImRldmljZV90eXBlIjoiaU9TIiwiZGV2aWNlX3Rva2VuIjoiMTIzNDU2IiwiYnVzaW5lc3NfdHlwZSI6IiIsImxpbmsiOiIiLCJ2ZXJpZmljYXRpb25fdG9rZW4iOiIiLCJlbWFpbF9jb25maXJtZWQiOjAsImVtYWlsX3ZlcmlmaWVkIjowLCJ2ZXJpZmljYXRpb25UeXBlIjoiZW1haWwtdmVyaWZpY2F0aW9uIiwidXNlcl90eXBlX2lkIjozfSwiaWF0IjoxNTUzODUwODA3LCJleHAiOjE1NTQ0NTU2MDd9.coeQisLZlAVBbS3KrShVrv1t-gnWdMxoHixj10jSlY8',NULL,'iOS','123456',0.00000000,0.00000000,NULL,NULL,0,'2019-03-29 09:13:27','2019-03-29 09:13:27'),(225,'PeterVa Kumar Rodicdi','media/customer/avtar/1555400279659.jpg','088686966860','2003-03-02',234,'2970053439675136','https://graph.facebook.com/2970053439675136/picture?type=large','facebook','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJkYXRhIjp7ImlkIjpudWxsLCJlbWFpbCI6InBldGVyLnJvZGljQGdtYWlsLmNvbSIsInBhc3N3b3JkIjoieWFsZ29fc3VwZXJfc2VjcmV0QDM0NUtMUCIsIm5hbWUiOiJQZXRlclZhIEt1bWFyIFJvZGljZGkiLCJqb2JfdGl0bGUiOiIiLCJidXNpbmVzc19uYW1lIjoiIiwidGVsZXBob25lX251bWJlciI6IiIsImNpdHkiOiIiLCJsYXRpdHVkZSI6bnVsbCwibG9uZ2l0dWRlIjpudWxsLCJkZXZpY2VfdHlwZSI6ImlPUyIsImRldmljZV90b2tlbiI6IjEyMzQ1NiIsImJ1c2luZXNzX3R5cGUiOiIiLCJsaW5rIjoiIiwidmVyaWZpY2F0aW9uX3Rva2VuIjoiIiwiZW1haWxfY29uZmlybWVkIjoxLCJlbWFpbF92ZXJpZmllZCI6MSwidmVyaWZpY2F0aW9uVHlwZSI6ImVtYWlsLXZlcmlmaWNhdGlvbiIsInVzZXJfdHlwZV9pZCI6M30sImlhdCI6MTU1Mzg1MTAzNSwiZXhwIjoxNTU0NDU1ODM1fQ.fbegKxI25FWiGWiC2UhOY_nGW4etYxC-nVqdBb3I1YA',NULL,'iOS','123456',26.85341180,75.80511420,'Jawahar Lal Nehru Marg, D-Block, Malviya Nagar, Jaipur, Rajasthan 302017, India','M',1,'2019-03-29 09:17:15','2019-03-29 09:17:15'),(226,'Sansa Stark',NULL,NULL,NULL,235,NULL,NULL,NULL,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJkYXRhIjp7ImlkIjpudWxsLCJlbWFpbCI6InNhbWFudGhhOTAxQG1haWxpbmF0b3IuY29tIiwicGFzc3dvcmQiOiJQYXNzd29yZEAxMjMiLCJuYW1lIjoiU2Fuc2EgU3RhcmsiLCJqb2JfdGl0bGUiOiJQbGF5ZXIiLCJidXNpbmVzc19uYW1lIjoiUGxheXdvb2QiLCJ0ZWxlcGhvbmVfbnVtYmVyIjoiMTIzNDU2IiwiY2l0eSI6Ik5vcnRoIiwibGF0aXR1ZGUiOm51bGwsImxvbmdpdHVkZSI6bnVsbCwiZGV2aWNlX3R5cGUiOiIiLCJkZXZpY2VfdG9rZW4iOiIiLCJidXNpbmVzc190eXBlIjoiIiwibGluayI6IiIsInZlcmlmaWNhdGlvbl90b2tlbiI6IiIsImVtYWlsX2NvbmZpcm1lZCI6MCwiZW1haWxfdmVyaWZpZWQiOjAsInZlcmlmaWNhdGlvblR5cGUiOiJlbWFpbC12ZXJpZmljYXRpb24iLCJ1c2VyX3R5cGVfaWQiOjJ9LCJpYXQiOjE1NTQxOTU4ODgsImV4cCI6MTU1NDgwMDY4OH0.gDypBmQc4CSVi3nYKXmfVADD04HzJdHADW6QKyBQhGE',NULL,'','',0.00000000,0.00000000,NULL,NULL,0,'2019-04-02 09:04:48','2019-04-02 09:04:48'),(227,'Tushar',NULL,NULL,NULL,236,NULL,NULL,NULL,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJkYXRhIjp7ImlkIjpudWxsLCJlbWFpbCI6InR1c2hhcjE5OTJAeW9wbWFpbC5jb20iLCJwYXNzd29yZCI6IlR1c2hhckAxOTkyIiwibmFtZSI6IlR1c2hhciIsImpvYl90aXRsZSI6Ik1hbmFnZXIiLCJidXNpbmVzc19uYW1lIjoiQ29mZmVlIHNob3AiLCJ0ZWxlcGhvbmVfbnVtYmVyIjoiOTc4MjM1NzM0MyIsImNpdHkiOiJnYW5nYW5hZ2FyIiwibGF0aXR1ZGUiOm51bGwsImxvbmdpdHVkZSI6bnVsbCwiZGV2aWNlX3R5cGUiOiIiLCJkZXZpY2VfdG9rZW4iOiIiLCJidXNpbmVzc190eXBlIjoiIiwibGluayI6IiIsInZlcmlmaWNhdGlvbl90b2tlbiI6IiIsImVtYWlsX2NvbmZpcm1lZCI6MCwiZW1haWxfdmVyaWZpZWQiOjAsInZlcmlmaWNhdGlvblR5cGUiOiJlbWFpbC12ZXJpZmljYXRpb24iLCJ1c2VyX3R5cGVfaWQiOjJ9LCJpYXQiOjE1NTQyODA0MjAsImV4cCI6MTU1NDg4NTIyMH0.fVHHXPv2O62d-KV6E-UQJp920XrE_LN0nvIpseje-KM',NULL,'','',0.00000000,0.00000000,NULL,NULL,0,'2019-04-03 08:33:40','2019-04-03 08:33:40'),(228,'Tushar',NULL,NULL,NULL,237,NULL,NULL,NULL,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJkYXRhIjp7ImlkIjpudWxsLCJlbWFpbCI6InR1c2hhcjExQHlvcG1haWwuY29tIiwicGFzc3dvcmQiOiJUdXNoYXJAMTk5MiIsIm5hbWUiOiJUdXNoYXIiLCJqb2JfdGl0bGUiOiJNYW5hZ2VyIiwiYnVzaW5lc3NfbmFtZSI6IkNvZmZlZSBTaG9wIiwidGVsZXBob25lX251bWJlciI6IjY1NDQ2NTQ2NDYiLCJjaXR5IjoiamFpcHVyIiwibGF0aXR1ZGUiOm51bGwsImxvbmdpdHVkZSI6bnVsbCwiZGV2aWNlX3R5cGUiOiIiLCJkZXZpY2VfdG9rZW4iOiIiLCJidXNpbmVzc190eXBlIjoiIiwibGluayI6IiIsInZlcmlmaWNhdGlvbl90b2tlbiI6IiIsImVtYWlsX2NvbmZpcm1lZCI6MCwiZW1haWxfdmVyaWZpZWQiOjAsInZlcmlmaWNhdGlvblR5cGUiOiJlbWFpbC12ZXJpZmljYXRpb24iLCJ1c2VyX3R5cGVfaWQiOjJ9LCJpYXQiOjE1NTQyODUwNzUsImV4cCI6MTU1NDg4OTg3NX0.9JhUZnip8TCILZf_vpaRhnaOmWlkMvEhIUzZIrBoD8A',NULL,'','',0.00000000,0.00000000,NULL,NULL,0,'2019-04-03 09:51:15','2019-04-03 09:51:15'),(229,'meeta mehat',NULL,NULL,NULL,238,NULL,NULL,NULL,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJkYXRhIjp7ImlkIjpudWxsLCJlbWFpbCI6Im1lZXRhMUBtYWlsaW5hdG9yLmNvbSIsInBhc3N3b3JkIjoiVGVzdEAxMjM0IiwibmFtZSI6Im1lZXRhIG1laGF0Iiwiam9iX3RpdGxlIjoicXVhbGl0eSBhbmFseXN0IiwiYnVzaW5lc3NfbmFtZSI6IlRlc3RpbmciLCJ0ZWxlcGhvbmVfbnVtYmVyIjoiNTQ1NCIsImNpdHkiOiJqYWlwdXIiLCJsYXRpdHVkZSI6bnVsbCwibG9uZ2l0dWRlIjpudWxsLCJkZXZpY2VfdHlwZSI6IiIsImRldmljZV90b2tlbiI6IiIsImJ1c2luZXNzX3R5cGUiOiIiLCJsaW5rIjoiIiwidmVyaWZpY2F0aW9uX3Rva2VuIjoiIiwiZW1haWxfY29uZmlybWVkIjowLCJlbWFpbF92ZXJpZmllZCI6MCwidmVyaWZpY2F0aW9uVHlwZSI6ImVtYWlsLXZlcmlmaWNhdGlvbiIsInVzZXJfdHlwZV9pZCI6Mn0sImlhdCI6MTU1NDM2MTUzMiwiZXhwIjoxNTU0OTY2MzMyfQ.LllldyFwQ2bTBkiZvpYtLhugGNHrWf0nXwSBU9NRIDI','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJkYXRhIjp7ImVtYWlsIjoibWVldGExQG1haWxpbmF0b3IuY29tIiwiZW1haWxfY29uZmlybWVkIjoxLCJhY2NvdW50X2RlbGV0ZWQiOjAsInN0YXR1cyI6MSwiYWRtaW5fZGVsZXRlZCI6MCwidXNlcl90eXBlX2lkIjoyLCJuYW1lIjoibWVldGEgbWVoYXQiLCJ2ZXJpZmljYXRpb25UeXBlIjoiZm9yZ290LXBhc3N3b3JkIn0sImlhdCI6MTU1NDM2OTI3MSwiZXhwIjoxNTU0MzcyODcxfQ.9coW7NsVCtO_zZ6QRf3yYGO3u9bMAehCWjebXWBAbko','','',0.00000000,0.00000000,NULL,NULL,0,'2019-04-04 07:05:32','2019-04-04 07:05:32'),(230,'meeta@',NULL,NULL,NULL,240,NULL,NULL,NULL,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJkYXRhIjp7ImlkIjpudWxsLCJlbWFpbCI6Im0xQG1haWxpbmF0b3IuY29tIiwicGFzc3dvcmQiOiJUZXN0QDEyMzQiLCJuYW1lIjoibWVldGFAIiwiam9iX3RpdGxlIjoiTG9yZW0gSXBzdW0gaXMgc2ltcGx5IGR1bW15IHRleHQgb2YgdGhlIHByaW50aW5nIGFuZCB0eXBlc2V0dGluZyBpbmR1c3RyeS4gTG9yZW0gSXBzdW0gaGFzIGJlZW4gdGhlIGluZHVzdHJ5J3Mgc3RhbmRhcmQgZHVtbXkgdGV4dCBldmVyIHNpbmNlIHRoZSAxNTAwcywgd2hlbiBhbiB1bmtub3duIHByaW50ZXIgdG9vayBhIGdhbGxleSBvZiB0eXBlIGFuZCBzY3JhbWJsZWQgaXQgdG8gbWFrZSBhIHR5cGUgc3BlY2ltZW4gYm9vay4gSXQgaGFzIHN1cnZpdmVkIG5vdCBvbmx5IGZpdmUgY2VudHVyaWVzLCBidXQgYWxzbyB0aGUgbGVhcCBpbnRvIGVsZWN0cm9uaWMgdHlwZXNldHRpbmcsIHJlbWFpbmluZyBlc3NlbnRpYWxseSB1bmNoYW5nZWQuIEl0IHdhcyBwb3B1bGFyaXNlZCBpbiB0aGUgMTk2MHMgd2l0aCB0aGUgcmVsZWFzZSBvZiBMZXRyYXNldCBzaGVldHMgY29udGFpbmluZyBMb3JlbSBJcHN1bSBwYXNzYWdlcywgYW5kIG1vcmUgcmVjZW50bHkgd2l0aCBkZXNrdG9wIHB1Ymxpc2hpbmcgc29mdHdhcmUgbGlrZSBBbGR1cyBQYWdlTWFrZXIgaW5jbHVkaW5nIHZlcnNpb25zIG9mIExvcmVtIElwc3VtLiIsImJ1c2luZXNzX25hbWUiOiJzaHNoc2hzaGpkIiwidGVsZXBob25lX251bWJlciI6IjEyMzQiLCJjaXR5IjoiamFpcHVyIiwibGF0aXR1ZGUiOm51bGwsImxvbmdpdHVkZSI6bnVsbCwiZGV2aWNlX3R5cGUiOiIiLCJkZXZpY2VfdG9rZW4iOiIiLCJidXNpbmVzc190eXBlIjoiIiwibGluayI6IiIsInZlcmlmaWNhdGlvbl90b2tlbiI6IiIsImVtYWlsX2NvbmZpcm1lZCI6MCwiZW1haWxfdmVyaWZpZWQiOjAsInZlcmlmaWNhdGlvblR5cGUiOiJlbWFpbC12ZXJpZmljYXRpb24iLCJ1c2VyX3R5cGVfaWQiOjJ9LCJpYXQiOjE1NTQzNzE0MTksImV4cCI6MTU1NDk3NjIxOX0.g6ZiIAMr3Txv5g-oxRseOvfmRX_wk9lVY27j6dCHJS0',NULL,'','',0.00000000,0.00000000,NULL,NULL,0,'2019-04-04 09:50:19','2019-04-04 09:50:19'),(231,'meeta@',NULL,NULL,NULL,241,NULL,NULL,NULL,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJkYXRhIjp7ImlkIjpudWxsLCJlbWFpbCI6Im0yQG1haWxpbmF0b3IuY29tIiwicGFzc3dvcmQiOiJUZXN0QDEyMzQiLCJuYW1lIjoibWVldGFAIiwiam9iX3RpdGxlIjoiZiIsImJ1c2luZXNzX25hbWUiOiJMb3JlbSBJcHN1bSBpcyBzaW1wbHkgZHVtbXkgdGV4dCBvZiB0aGUgcHJpbnRpbmcgYW5kIHR5cGVzZXR0aW5nIGluZHVzdHJ5LiBMb3JlbSBJcHN1bSBoYXMgYmVlbiB0aGUgaW5kdXN0cnkncyBzdGFuZGFyZCBkdW1teSB0ZXh0IGV2ZXIgc2luY2UgdGhlIDE1MDBzLCB3aGVuIGFuIHVua25vd24gcHJpbnRlciB0b29rIGEgZ2FsbGV5IG9mIHR5cGUgYW5kIHNjcmFtYmxlZCBpdCB0byBtYWtlIGEgdHlwZSBzcGVjaW1lbiBib29rLiBJdCBoYXMgc3Vydml2ZWQgbm90IG9ubHkgZml2ZSBjZW50dXJpZXMsIGJ1dCBhbHNvIHRoZSBsZWFwIGludG8gZWxlY3Ryb25pYyB0eXBlc2V0dGluZywgcmVtYWluaW5nIGVzc2VudGlhbGx5IHVuY2hhbmdlZC4gSXQgd2FzIHBvcHVsYXJpc2VkIGluIHRoZSAxOTYwcyB3aXRoIHRoZSByZWxlYXNlIG9mIExldHJhc2V0IHNoZWV0cyBjb250YWluaW5nIExvcmVtIElwc3VtIHBhc3NhZ2VzLCBhbmQgbW9yZSByZWNlbnRseSB3aXRoIGRlc2t0b3AgcHVibGlzaGluZyBzb2Z0d2FyZSBsaWtlIEFsZHVzIFBhZ2VNYWtlciBpbmNsdWRpbmcgdmVyc2lvbnMgb2YgTG9yZW0gSXBzdW0uIiwidGVsZXBob25lX251bWJlciI6IjEyMzQiLCJjaXR5IjoiamFpcHVyIiwibGF0aXR1ZGUiOm51bGwsImxvbmdpdHVkZSI6bnVsbCwiZGV2aWNlX3R5cGUiOiIiLCJkZXZpY2VfdG9rZW4iOiIiLCJidXNpbmVzc190eXBlIjoiIiwibGluayI6IiIsInZlcmlmaWNhdGlvbl90b2tlbiI6IiIsImVtYWlsX2NvbmZpcm1lZCI6MCwiZW1haWxfdmVyaWZpZWQiOjAsInZlcmlmaWNhdGlvblR5cGUiOiJlbWFpbC12ZXJpZmljYXRpb24iLCJ1c2VyX3R5cGVfaWQiOjJ9LCJpYXQiOjE1NTQzNzE0NDgsImV4cCI6MTU1NDk3NjI0OH0.fa-TKLena27O2oHMwXsCwOC3y6usrBFvtLS_ba7H_BA',NULL,'','',0.00000000,0.00000000,NULL,NULL,0,'2019-04-04 09:50:48','2019-04-04 09:50:48'),(232,'meeta@',NULL,NULL,NULL,242,NULL,NULL,NULL,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJkYXRhIjp7ImlkIjpudWxsLCJlbWFpbCI6Im0zQG1haWxpbmF0b3IuY29tIiwicGFzc3dvcmQiOiJUZXN0QDEyMzQiLCJuYW1lIjoibWVldGFAIiwiam9iX3RpdGxlIjoiZiIsImJ1c2luZXNzX25hbWUiOiJ1c2VyIiwidGVsZXBob25lX251bWJlciI6IjEyMzQiLCJjaXR5IjoiamFpcHVyIiwibGF0aXR1ZGUiOm51bGwsImxvbmdpdHVkZSI6bnVsbCwiZGV2aWNlX3R5cGUiOiIiLCJkZXZpY2VfdG9rZW4iOiIiLCJidXNpbmVzc190eXBlIjoiIiwibGluayI6IiIsInZlcmlmaWNhdGlvbl90b2tlbiI6IiIsImVtYWlsX2NvbmZpcm1lZCI6MCwiZW1haWxfdmVyaWZpZWQiOjAsInZlcmlmaWNhdGlvblR5cGUiOiJlbWFpbC12ZXJpZmljYXRpb24iLCJ1c2VyX3R5cGVfaWQiOjJ9LCJpYXQiOjE1NTQzNzE0ODAsImV4cCI6MTU1NDk3NjI4MH0.is1PtzDKVM97V50hHFWhcJ6Eh7f7ki6icemSPh-xZc4',NULL,'','',0.00000000,0.00000000,NULL,NULL,0,'2019-04-04 09:51:20','2019-04-04 09:51:20'),(233,'meeta',NULL,NULL,NULL,243,NULL,NULL,NULL,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJkYXRhIjp7ImlkIjpudWxsLCJlbWFpbCI6Im02QG1haWxpbmF0b3IuY29tIiwicGFzc3dvcmQiOiJUZXN0QDEyMzQiLCJuYW1lIjoibWVldGEiLCJqb2JfdGl0bGUiOiJtZWV0YUAxMjM0IiwiYnVzaW5lc3NfbmFtZSI6IkxvcmVtIElwc3VtIGlzIHNpbXBseSBkdW1teSB0ZXh0IG9mIHRoZSBwcmludGluZyBhbmQgdHlwZXNldHRpbmcgaW5kdXN0cnkuIExvcmVtIElwc3VtIGhhcyBiZWVuIHRoZSBpbmR1c3RyeSdzIHN0YW5kYXJkIGR1bW15IHRleHQgZXZlciBzaW5jZSB0aGUgMTUwMHMsIHdoZW4gYW4gdW5rbm93biBwcmludGVyIHRvb2sgYSBnYWxsZXkgb2YgdHlwZSBhbmQgc2NyYW1ibGVkIGl0IHRvIG1ha2UgYSB0eXBlIHNwZWNpbWVuIGJvb2suIEl0IGhhcyBzdXJ2aXZlZCBub3Qgb25seSBmaXZlIGNlbnR1cmllcywgYnV0IGFsc28gdGhlIGxlYXAgaW50byBlbGVjdHJvbmljIHR5cGVzZXR0aW5nLCByZW1haW5pbmcgZXNzZW50aWFsbHkgdW5jaGFuZ2VkLiBJdCB3YXMgcG9wdWxhcmlzZWQgaW4gdGhlIDE5NjBzIHdpdGggdGhlIHJlbGVhc2Ugb2YgTGV0cmFzZXQgc2hlZXRzIGNvbnRhaW5pbmcgTG9yZW0gSXBzdW0gcGFzc2FnZXMsIGFuZCBtb3JlIHJlY2VudGx5IHdpdGggZGVza3RvcCBwdWJsaXNoaW5nIHNvZnR3YXJlIGxpa2UgQWxkdXMgUGFnZU1ha2VyIGluY2x1ZGluZyB2ZXJzaW9ucyBvZiBMb3JlbSBJcHN1bS4iLCJ0ZWxlcGhvbmVfbnVtYmVyIjoiMjU0IiwiY2l0eSI6ImphaXB1ciIsImxhdGl0dWRlIjpudWxsLCJsb25naXR1ZGUiOm51bGwsImRldmljZV90eXBlIjoiIiwiZGV2aWNlX3Rva2VuIjoiIiwiYnVzaW5lc3NfdHlwZSI6IiIsImxpbmsiOiIiLCJ2ZXJpZmljYXRpb25fdG9rZW4iOiIiLCJlbWFpbF9jb25maXJtZWQiOjAsImVtYWlsX3ZlcmlmaWVkIjowLCJ2ZXJpZmljYXRpb25UeXBlIjoiZW1haWwtdmVyaWZpY2F0aW9uIiwidXNlcl90eXBlX2lkIjoyfSwiaWF0IjoxNTU0MzcxNjcwLCJleHAiOjE1NTQ5NzY0NzB9.ZeBv2CE2QzR1WgRBx_Jzwzug5VKHUjW_eb0mIdXtsSE',NULL,'','',0.00000000,0.00000000,NULL,NULL,0,'2019-04-04 09:54:30','2019-04-04 09:54:30'),(234,'sakshi',NULL,NULL,NULL,244,NULL,NULL,NULL,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJkYXRhIjp7ImlkIjpudWxsLCJlbWFpbCI6InNha3NoaUBtYWlsaW5hdG9yLmNvbSIsInBhc3N3b3JkIjoiVGVzdEAxMjM0IiwibmFtZSI6InNha3NoaSIsImpvYl90aXRsZSI6InNha3NoaSIsImJ1c2luZXNzX25hbWUiOiJzYWtzaGkiLCJ0ZWxlcGhvbmVfbnVtYmVyIjoiNDg0NTQiLCJjaXR5IjoiamFpcHVyIiwibGF0aXR1ZGUiOm51bGwsImxvbmdpdHVkZSI6bnVsbCwiZGV2aWNlX3R5cGUiOiIiLCJkZXZpY2VfdG9rZW4iOiIiLCJidXNpbmVzc190eXBlIjoiIiwibGluayI6IiIsInZlcmlmaWNhdGlvbl90b2tlbiI6IiIsImVtYWlsX2NvbmZpcm1lZCI6MCwiZW1haWxfdmVyaWZpZWQiOjAsInZlcmlmaWNhdGlvblR5cGUiOiJlbWFpbC12ZXJpZmljYXRpb24iLCJ1c2VyX3R5cGVfaWQiOjJ9LCJpYXQiOjE1NTQzNzI5NjUsImV4cCI6MTU1NDk3Nzc2NX0.HYzYvZDWI0kQD_Q7tr7O3lZLona96_pMHtYQSjccP7A',NULL,'','',0.00000000,0.00000000,NULL,NULL,0,'2019-04-04 10:16:05','2019-04-04 10:16:05'),(235,'john',NULL,NULL,NULL,245,NULL,NULL,NULL,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJkYXRhIjp7ImlkIjpudWxsLCJlbWFpbCI6ImpvaG5AeW9wbWFpbC5jb20iLCJwYXNzd29yZCI6IkpvaG5AMTk5MiIsIm5hbWUiOiJqb2huIiwiam9iX3RpdGxlIjoiTWFuYWdlciIsImJ1c2luZXNzX25hbWUiOiJCdXJnZXIgU2hvcCIsInRlbGVwaG9uZV9udW1iZXIiOiI5NzgyMzU3MzQzIiwiY2l0eSI6IkphaXB1ciIsImxhdGl0dWRlIjpudWxsLCJsb25naXR1ZGUiOm51bGwsImRldmljZV90eXBlIjoiIiwiZGV2aWNlX3Rva2VuIjoiIiwiYnVzaW5lc3NfdHlwZSI6IiIsImxpbmsiOiIiLCJ2ZXJpZmljYXRpb25fdG9rZW4iOiIiLCJlbWFpbF9jb25maXJtZWQiOjAsImVtYWlsX3ZlcmlmaWVkIjowLCJ2ZXJpZmljYXRpb25UeXBlIjoiZW1haWwtdmVyaWZpY2F0aW9uIiwidXNlcl90eXBlX2lkIjoyfSwiaWF0IjoxNTU0NzEyNjk3LCJleHAiOjE1NTUzMTc0OTd9.7cJOl0FNa8ip8_RpTad9YP8WgrF8LUz1OeTvXkV2QIg',NULL,'','',0.00000000,0.00000000,NULL,NULL,0,'2019-04-08 08:38:17','2019-04-08 08:38:17'),(236,'Asif Malik',NULL,NULL,NULL,246,NULL,NULL,NULL,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJkYXRhIjp7ImlkIjpudWxsLCJlbWFpbCI6ImFzaWZAeWFsZ28uY29tIiwicGFzc3dvcmQiOiJTYXZlbWUyMDE2ISIsIm5hbWUiOiJBc2lmIE1hbGlrIiwiam9iX3RpdGxlIjoiIiwiYnVzaW5lc3NfbmFtZSI6IiIsInRlbGVwaG9uZV9udW1iZXIiOiIiLCJjaXR5IjoiIiwibGF0aXR1ZGUiOiIwLjAiLCJsb25naXR1ZGUiOiIwLjAiLCJkZXZpY2VfdHlwZSI6ImlPUyIsImRldmljZV90b2tlbiI6IjEyMzQ1NiIsImJ1c2luZXNzX3R5cGUiOiIiLCJsaW5rIjoiIiwidmVyaWZpY2F0aW9uX3Rva2VuIjoiIiwiZW1haWxfY29uZmlybWVkIjowLCJlbWFpbF92ZXJpZmllZCI6MCwidmVyaWZpY2F0aW9uVHlwZSI6ImVtYWlsLXZlcmlmaWNhdGlvbiIsInVzZXJfdHlwZV9pZCI6M30sImlhdCI6MTU1NDgxMjYzMiwiZXhwIjoxNTU1NDE3NDMyfQ.QGhkmGxuRFNM3TEX_V9OwjEoNkNGmifFWyxNReQo2K4',NULL,'iOS','123456',0.00000000,0.00000000,NULL,NULL,0,'2019-04-09 12:23:52','2019-04-09 12:23:52'),(237,'David',NULL,NULL,NULL,247,NULL,NULL,NULL,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJkYXRhIjp7ImlkIjpudWxsLCJlbWFpbCI6ImRhdmlkQHlhbGdvLmNvbSIsInBhc3N3b3JkIjoiOTExR3QxJDEiLCJuYW1lIjoiRGF2aWQiLCJqb2JfdGl0bGUiOiIiLCJidXNpbmVzc19uYW1lIjoiIiwidGVsZXBob25lX251bWJlciI6IiIsImNpdHkiOiIiLCJsYXRpdHVkZSI6IjAuMCIsImxvbmdpdHVkZSI6IjAuMCIsImRldmljZV90eXBlIjoiaU9TIiwiZGV2aWNlX3Rva2VuIjoiMTIzNDU2IiwiYnVzaW5lc3NfdHlwZSI6IiIsImxpbmsiOiIiLCJ2ZXJpZmljYXRpb25fdG9rZW4iOiIiLCJlbWFpbF9jb25maXJtZWQiOjAsImVtYWlsX3ZlcmlmaWVkIjowLCJ2ZXJpZmljYXRpb25UeXBlIjoiZW1haWwtdmVyaWZpY2F0aW9uIiwidXNlcl90eXBlX2lkIjozfSwiaWF0IjoxNTU0ODE1ODAzLCJleHAiOjE1NTU0MjA2MDN9.xhEn4Sb9TkIQZEfWTTtYYcHFQMh42bCceSX7LygO-mE',NULL,'iOS','123456',0.00000000,0.00000000,NULL,NULL,0,'2019-04-09 13:16:43','2019-04-09 13:16:43'),(238,'Asif Malik',NULL,NULL,NULL,248,NULL,NULL,NULL,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJkYXRhIjp7ImlkIjpudWxsLCJlbWFpbCI6Im1hZmlhc2lsa0BnbWFpbC5jb20iLCJwYXNzd29yZCI6IkF5c2hhNzg2ISIsIm5hbWUiOiJBc2lmIE1hbGlrIiwiam9iX3RpdGxlIjoiZGlyZWN0b3IiLCJidXNpbmVzc19uYW1lIjoiQmVybmll4oCZcyIsInRlbGVwaG9uZV9udW1iZXIiOiIwNzgzNDUzMTY4MyIsImNpdHkiOiJsZWVkcyIsImxhdGl0dWRlIjpudWxsLCJsb25naXR1ZGUiOm51bGwsImRldmljZV90eXBlIjoiIiwiZGV2aWNlX3Rva2VuIjoiIiwiYnVzaW5lc3NfdHlwZSI6IiIsImxpbmsiOiIiLCJ2ZXJpZmljYXRpb25fdG9rZW4iOiIiLCJlbWFpbF9jb25maXJtZWQiOjAsImVtYWlsX3ZlcmlmaWVkIjowLCJ2ZXJpZmljYXRpb25UeXBlIjoiZW1haWwtdmVyaWZpY2F0aW9uIiwidXNlcl90eXBlX2lkIjoyfSwiaWF0IjoxNTU0OTEzMTkyLCJleHAiOjE1NTU1MTc5OTJ9.J4mf7fhkbncGOfWPe2nn09flFVIRB2igr5xbbN9B9XU',NULL,'','',0.00000000,0.00000000,NULL,NULL,0,'2019-04-10 16:19:52','2019-04-10 16:19:52'),(239,'Lana del ray',NULL,NULL,NULL,249,NULL,NULL,NULL,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJkYXRhIjp7ImlkIjpudWxsLCJlbWFpbCI6ImxhbmFkZWxyYXkyQG1haWxpbmF0b3IuY29tIiwicGFzc3dvcmQiOiJQYXNzd29yZEAxMjM0IiwibmFtZSI6IkxhbmEgZGVsIHJheSIsImpvYl90aXRsZSI6IiIsImJ1c2luZXNzX25hbWUiOiIiLCJ0ZWxlcGhvbmVfbnVtYmVyIjoiIiwiY2l0eSI6IiIsImxhdGl0dWRlIjoiIiwibG9uZ2l0dWRlIjoiIiwiZGV2aWNlX3R5cGUiOiIiLCJkZXZpY2VfdG9rZW4iOiIiLCJidXNpbmVzc190eXBlIjoiIiwibGluayI6IiIsInZlcmlmaWNhdGlvbl90b2tlbiI6IiIsImVtYWlsX2NvbmZpcm1lZCI6MCwiZW1haWxfdmVyaWZpZWQiOjAsInZlcmlmaWNhdGlvblR5cGUiOiJlbWFpbC12ZXJpZmljYXRpb24iLCJ1c2VyX3R5cGVfaWQiOjN9LCJpYXQiOjE1NTUzMjY0MzksImV4cCI6MTU1NTkzMTIzOX0.vdf8pmBE-0itkz0px2VOlYAI935WJ1LcoDkMOn4xvxk',NULL,'','',0.00000000,0.00000000,NULL,NULL,0,'2019-04-15 11:07:19','2019-04-15 11:07:19'),(240,'Lana del ray',NULL,NULL,NULL,250,NULL,NULL,NULL,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJkYXRhIjp7ImlkIjpudWxsLCJlbWFpbCI6ImxhbmFkZWxyYXk2QG1haWxpbmF0b3IuY29tIiwicGFzc3dvcmQiOiJQYXNzd29yZEAxMjM0IiwibmFtZSI6IkxhbmEgZGVsIHJheSIsImpvYl90aXRsZSI6IiIsImJ1c2luZXNzX25hbWUiOiIiLCJ0ZWxlcGhvbmVfbnVtYmVyIjoiIiwiY2l0eSI6IiIsImxhdGl0dWRlIjoiIiwibG9uZ2l0dWRlIjoiIiwiZGV2aWNlX3R5cGUiOiIiLCJkZXZpY2VfdG9rZW4iOiIiLCJidXNpbmVzc190eXBlIjoiIiwibGluayI6IiIsInZlcmlmaWNhdGlvbl90b2tlbiI6IiIsImVtYWlsX2NvbmZpcm1lZCI6MCwiZW1haWxfdmVyaWZpZWQiOjAsInZlcmlmaWNhdGlvblR5cGUiOiJlbWFpbC12ZXJpZmljYXRpb24iLCJ1c2VyX3R5cGVfaWQiOjN9LCJpYXQiOjE1NTUzMjY2NzAsImV4cCI6MTU1NTkzMTQ3MH0.aOpC49U5qdi4zvuZflYanIKthMJMoF75cAjZVpVkOdI',NULL,'','',0.00000000,0.00000000,NULL,NULL,0,'2019-04-15 11:11:09','2019-04-15 11:11:09'),(241,'Abhinav',NULL,NULL,NULL,251,NULL,NULL,NULL,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJkYXRhIjp7ImlkIjpudWxsLCJlbWFpbCI6ImFiaGluYXZAbWFpbGluYXRvci5jb20iLCJwYXNzd29yZCI6IlRlc3RAMTIzIiwibmFtZSI6IkFiaGluYXYiLCJqb2JfdGl0bGUiOiJtYW5hZ2VyIiwiYnVzaW5lc3NfbmFtZSI6InJldHJvIiwidGVsZXBob25lX251bWJlciI6IjEyMzQ1Njc4OTAiLCJjaXR5IjoiSmFpcHVyICIsImxhdGl0dWRlIjpudWxsLCJsb25naXR1ZGUiOm51bGwsImRldmljZV90eXBlIjoiIiwiZGV2aWNlX3Rva2VuIjoiIiwiYnVzaW5lc3NfdHlwZSI6IiIsImxpbmsiOiIiLCJ2ZXJpZmljYXRpb25fdG9rZW4iOiIiLCJlbWFpbF9jb25maXJtZWQiOjAsImVtYWlsX3ZlcmlmaWVkIjowLCJ2ZXJpZmljYXRpb25UeXBlIjoiZW1haWwtdmVyaWZpY2F0aW9uIiwidXNlcl90eXBlX2lkIjoyfSwiaWF0IjoxNTU1NDA0NjYyLCJleHAiOjE1NTYwMDk0NjJ9.naFHFZYGyF7cTTW8GgJ2uruNIP7nyCKGFYe-MBthL3U',NULL,'','',0.00000000,0.00000000,NULL,NULL,0,'2019-04-16 08:51:02','2019-04-16 08:51:02'),(242,'Sansa Stark',NULL,NULL,NULL,252,NULL,NULL,NULL,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJkYXRhIjp7ImlkIjpudWxsLCJlbWFpbCI6InNhbWFudGhhMTAzQG1haWxpbmF0b3IuY29tIiwicGFzc3dvcmQiOiJQYXNzd29yZEAxMjMiLCJuYW1lIjoiU2Fuc2EgU3RhcmsiLCJqb2JfdGl0bGUiOiJQbGF5ZXIiLCJidXNpbmVzc19uYW1lIjoiUGxheXdvb2QiLCJ0ZWxlcGhvbmVfbnVtYmVyIjoiMTIzNDU2IiwiY2l0eSI6Ik5vcnRoIiwibGF0aXR1ZGUiOm51bGwsImxvbmdpdHVkZSI6bnVsbCwiZGV2aWNlX3R5cGUiOiIiLCJkZXZpY2VfdG9rZW4iOiIiLCJidXNpbmVzc190eXBlIjoiIiwibGluayI6IiIsInZlcmlmaWNhdGlvbl90b2tlbiI6IiIsImVtYWlsX2NvbmZpcm1lZCI6MCwiZW1haWxfdmVyaWZpZWQiOjAsInZlcmlmaWNhdGlvblR5cGUiOiJlbWFpbC12ZXJpZmljYXRpb24iLCJ1c2VyX3R5cGVfaWQiOjJ9LCJpYXQiOjE1NTU0MTg0OTYsImV4cCI6MTU1NjAyMzI5Nn0.hAfWblBRnnnf2B8CzhSph27Xub3VE6KFbRJWSqLbnzQ',NULL,'','',0.00000000,0.00000000,NULL,NULL,0,'2019-04-16 12:41:36','2019-04-16 12:41:36'),(243,'meeta mehta',NULL,NULL,NULL,253,NULL,NULL,NULL,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJkYXRhIjp7ImlkIjpudWxsLCJlbWFpbCI6Im1lZXRhbWVodGFAbWFpbGluYXRvci5jb20iLCJwYXNzd29yZCI6IlRlc3RAMTIzIiwibmFtZSI6Im1lZXRhIG1laHRhIiwiam9iX3RpdGxlIjoibWFuYWdlciIsImJ1c2luZXNzX25hbWUiOiJjb2ZmZXIgY2FmZSIsInRlbGVwaG9uZV9udW1iZXIiOiIxMjMiLCJjaXR5IjoiamFpcHVyIiwibGF0aXR1ZGUiOm51bGwsImxvbmdpdHVkZSI6bnVsbCwiZGV2aWNlX3R5cGUiOiIiLCJkZXZpY2VfdG9rZW4iOiIiLCJidXNpbmVzc190eXBlIjoiIiwibGluayI6IiIsInZlcmlmaWNhdGlvbl90b2tlbiI6IiIsImVtYWlsX2NvbmZpcm1lZCI6MCwiZW1haWxfdmVyaWZpZWQiOjAsInZlcmlmaWNhdGlvblR5cGUiOiJlbWFpbC12ZXJpZmljYXRpb24iLCJ1c2VyX3R5cGVfaWQiOjJ9LCJpYXQiOjE1NTU0OTUxNjEsImV4cCI6MTU1NjA5OTk2MX0.TjbSR10z6WbDl2E9_zDOZk1DHjrEhxJnE85nLwJkx80',NULL,'','',0.00000000,0.00000000,NULL,NULL,0,'2019-04-17 09:59:21','2019-04-17 09:59:21');
/*!40000 ALTER TABLE `user_profile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_types`
--

DROP TABLE IF EXISTS `user_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `status` tinyint(4) DEFAULT '1',
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`,`type`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_types`
--

LOCK TABLES `user_types` WRITE;
/*!40000 ALTER TABLE `user_types` DISABLE KEYS */;
INSERT INTO `user_types` VALUES (1,'ADMIN',1,'2019-03-06 10:36:46','2019-03-06 10:36:46'),(2,'BUSINESS_USER',1,'2019-03-06 10:36:46','2019-03-06 10:36:46'),(3,'CUSTOMER',1,'2019-03-06 10:36:46','2019-03-06 10:36:46');
/*!40000 ALTER TABLE `user_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(2000) DEFAULT NULL,
  `user_type_id` int(11) NOT NULL,
  `email_confirmed` tinyint(4) DEFAULT '0',
  `admin_deleted` tinyint(4) DEFAULT '0',
  `last_login_time` datetime DEFAULT NULL,
  `last_logout_time` datetime DEFAULT NULL,
  `status` tinyint(4) DEFAULT '1',
  `created` datetime DEFAULT CURRENT_TIMESTAMP,
  `modified` datetime DEFAULT CURRENT_TIMESTAMP,
  `account_deleted` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_user_type` (`user_type_id`),
  CONSTRAINT `fk_user_type` FOREIGN KEY (`user_type_id`) REFERENCES `user_types` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=254 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (215,'jansen611@mailinator.com','1154e4485abba57f484c30a2ea543144178ff6a03da4503678a04ff8e808445709476e2e058af1c35afb1842eff5b7182d5d18fc3b98f185c47472520169af71',3,1,0,NULL,NULL,1,'2019-03-19 12:06:02','2019-03-19 12:06:02',0),(216,'meeta.mehta@dotsquares.com','865a36cc06ee30e5699cd7759a68e9e882c6e2b9698bf27ca50c7792c8466bbcf6d35bec3cae6619c544e416b4e1aea38acf773cbd41c83d69f5e1a912045b5c',3,0,0,NULL,NULL,1,'2019-03-19 12:08:58','2019-03-19 12:08:58',0),(217,'mehta.meeta85@gmail.com','865a36cc06ee30e5699cd7759a68e9e882c6e2b9698bf27ca50c7792c8466bbcf6d35bec3cae6619c544e416b4e1aea38acf773cbd41c83d69f5e1a912045b5c',3,1,0,NULL,NULL,1,'2019-03-19 12:10:38','2019-03-19 12:10:38',0),(218,'meeta@mailinator.com','d085e818760759e304c2454a6632ab30f95a3d76b32543dc0f3700cd9733ec3ff819e35ff557c459940f1644f97d51a54b16ec43283dbb7b7796630045f9c97d',3,1,0,NULL,NULL,1,'2019-03-19 12:11:49','2019-03-19 12:11:49',0),(219,'jansen6@mailinator.com','e8be9807c3ec0bd1ce2a58e9cddd4a89966820aedc509830b62f05a226dd29a3764e4962acf28b4b87377b347b9395e1dd5bc87fed1e44f17315b89d7501836c',3,1,0,NULL,NULL,1,'2019-03-19 13:02:36','2019-03-19 13:02:36',0),(220,'yalgo@mailinator.com','b42458de550ef94801e7df33778c436d93bb78d3962f1020f3659db75b72cb8e3a4bb75f972c500d5a3626f74f6b69436d515b55a0344c4b29f28ad0cba56c3b',3,1,0,NULL,NULL,0,'2019-03-19 13:22:10','2019-03-19 13:22:10',0),(221,'samantha100@mailinator.com','e8be9807c3ec0bd1ce2a58e9cddd4a89966820aedc509830b62f05a226dd29a3764e4962acf28b4b87377b347b9395e1dd5bc87fed1e44f17315b89d7501836c',2,1,0,NULL,NULL,1,'2019-03-19 13:26:19','2019-03-19 13:26:19',0),(222,'nipun@yopmail.com','31b6db2fee6ac3cab55b874088813e5f69f46fc6426d147ffc5117668cf74e7172ba49deb8902cfc6a4c26cda9c729f31a84d3a399965172bca41666d9a10b22',3,1,0,NULL,NULL,1,'2019-03-20 05:03:12','2019-03-20 05:03:12',0),(223,'samantha101@mailinator.com','e8be9807c3ec0bd1ce2a58e9cddd4a89966820aedc509830b62f05a226dd29a3764e4962acf28b4b87377b347b9395e1dd5bc87fed1e44f17315b89d7501836c',2,1,0,NULL,NULL,1,'2019-03-22 06:19:13','2019-03-22 06:19:13',0),(224,'david_cusworth@mailinator.com','1154e4485abba57f484c30a2ea543144178ff6a03da4503678a04ff8e808445709476e2e058af1c35afb1842eff5b7182d5d18fc3b98f185c47472520169af71',1,1,0,NULL,NULL,1,'2019-03-22 08:14:27','2019-03-22 08:14:27',0),(225,'test@mailinator.com','3c7959e8355f19cb6c7a023e46099e5ea9ef23cc4c75675d153b366289fa1d1df18134229825b75064c6a4e86d97e3fa6ebaaed2c1da8c93500024c3c3f4ffd4',3,1,0,NULL,NULL,0,'2019-03-25 04:55:50','2019-03-25 04:55:50',0),(226,'jansen60@mailinator.com','1154e4485abba57f484c30a2ea543144178ff6a03da4503678a04ff8e808445709476e2e058af1c35afb1842eff5b7182d5d18fc3b98f185c47472520169af71',3,1,0,NULL,NULL,0,'2019-03-25 10:59:48','2019-03-25 10:59:48',0),(227,'coffee@yopmail.com','08cc4580dc3a941862d739bbd0854531594b1ff90111207a90621778a4b271792b7bc5616b09e3776699329bb5150f9deb812473db143ba5c3de4f23086f071c',2,1,0,NULL,NULL,1,'2019-03-25 11:28:26','2019-03-25 11:28:26',0),(228,'arora@yopmail.com','6cb18fb5b870c8cb4966dcc71390021c6c8683d4a299578773d89650ed7be7a71218137e17637592d3174e1a190038dbaeb66dcee38b126f96b0d6d14d96638d',2,0,0,NULL,NULL,1,'2019-03-26 05:48:24','2019-03-26 05:48:24',0),(229,'murli@yopmail.com','d0e9c67853f07b1c428f2bd98aa602353d059cd7cba5ef5e6cad2d7cf4a6b16af3ac8dfd14e5b7437055f05e74ad26e2effb76a4a1352bec9d2252e96daecf9d',2,1,0,NULL,NULL,1,'2019-03-27 07:08:34','2019-03-27 07:08:34',0),(230,'new@mailinator.com','3c7959e8355f19cb6c7a023e46099e5ea9ef23cc4c75675d153b366289fa1d1df18134229825b75064c6a4e86d97e3fa6ebaaed2c1da8c93500024c3c3f4ffd4',3,0,0,NULL,NULL,1,'2019-03-27 12:46:30','2019-03-27 12:46:30',0),(231,'jansen601@mailinator.com','1154e4485abba57f484c30a2ea543144178ff6a03da4503678a04ff8e808445709476e2e058af1c35afb1842eff5b7182d5d18fc3b98f185c47472520169af71',3,1,0,NULL,NULL,1,'2019-03-28 05:25:39','2019-03-28 05:25:39',0),(232,'jansen602@mailinator.com','e8be9807c3ec0bd1ce2a58e9cddd4a89966820aedc509830b62f05a226dd29a3764e4962acf28b4b87377b347b9395e1dd5bc87fed1e44f17315b89d7501836c',3,1,0,NULL,NULL,1,'2019-03-28 06:43:54','2019-03-28 06:43:54',0),(233,'tushar77@yopmail.com','83b0509e878e3c8adf8e2c7f010bc3cbed7b7f3d8cc86593e911cb8aefad4cb766225e58f0bac3f6cfaaa2994ec39e84028b2380dbe506263306c4d869c38c5c',3,1,0,NULL,NULL,1,'2019-03-29 09:13:27','2019-03-29 09:13:27',0),(234,'peter.rodic@gmail.com','865a36cc06ee30e5699cd7759a68e9e882c6e2b9698bf27ca50c7792c8466bbcf6d35bec3cae6619c544e416b4e1aea38acf773cbd41c83d69f5e1a912045b5c',3,1,0,NULL,NULL,1,'2019-03-29 09:17:15','2019-03-29 09:17:15',0),(235,'samantha901@mailinator.com','e8be9807c3ec0bd1ce2a58e9cddd4a89966820aedc509830b62f05a226dd29a3764e4962acf28b4b87377b347b9395e1dd5bc87fed1e44f17315b89d7501836c',2,0,0,NULL,NULL,1,'2019-04-02 09:04:48','2019-04-02 09:04:48',0),(236,'tushar1992@yopmail.com','83b0509e878e3c8adf8e2c7f010bc3cbed7b7f3d8cc86593e911cb8aefad4cb766225e58f0bac3f6cfaaa2994ec39e84028b2380dbe506263306c4d869c38c5c',2,1,0,NULL,NULL,1,'2019-04-03 08:33:40','2019-04-03 08:33:40',0),(237,'tushar11@yopmail.com','83b0509e878e3c8adf8e2c7f010bc3cbed7b7f3d8cc86593e911cb8aefad4cb766225e58f0bac3f6cfaaa2994ec39e84028b2380dbe506263306c4d869c38c5c',2,1,0,NULL,NULL,1,'2019-04-03 09:51:15','2019-04-03 09:51:15',0),(238,'meeta1@mailinator.com','b42458de550ef94801e7df33778c436d93bb78d3962f1020f3659db75b72cb8e3a4bb75f972c500d5a3626f74f6b69436d515b55a0344c4b29f28ad0cba56c3b',2,1,0,NULL,NULL,1,'2019-04-04 07:05:32','2019-04-04 07:05:32',0),(239,'m@mailinator.com','b42458de550ef94801e7df33778c436d93bb78d3962f1020f3659db75b72cb8e3a4bb75f972c500d5a3626f74f6b69436d515b55a0344c4b29f28ad0cba56c3b',2,0,0,NULL,NULL,1,'2019-04-04 09:49:30','2019-04-04 09:49:30',0),(240,'m1@mailinator.com','b42458de550ef94801e7df33778c436d93bb78d3962f1020f3659db75b72cb8e3a4bb75f972c500d5a3626f74f6b69436d515b55a0344c4b29f28ad0cba56c3b',2,0,0,NULL,NULL,1,'2019-04-04 09:50:19','2019-04-04 09:50:19',0),(241,'m2@mailinator.com','b42458de550ef94801e7df33778c436d93bb78d3962f1020f3659db75b72cb8e3a4bb75f972c500d5a3626f74f6b69436d515b55a0344c4b29f28ad0cba56c3b',2,0,0,NULL,NULL,1,'2019-04-04 09:50:48','2019-04-04 09:50:48',0),(242,'m3@mailinator.com','b42458de550ef94801e7df33778c436d93bb78d3962f1020f3659db75b72cb8e3a4bb75f972c500d5a3626f74f6b69436d515b55a0344c4b29f28ad0cba56c3b',2,1,0,NULL,NULL,1,'2019-04-04 09:51:20','2019-04-04 09:51:20',0),(243,'m6@mailinator.com','b42458de550ef94801e7df33778c436d93bb78d3962f1020f3659db75b72cb8e3a4bb75f972c500d5a3626f74f6b69436d515b55a0344c4b29f28ad0cba56c3b',2,0,0,NULL,NULL,1,'2019-04-04 09:54:30','2019-04-04 09:54:30',0),(244,'sakshi@mailinator.com','b42458de550ef94801e7df33778c436d93bb78d3962f1020f3659db75b72cb8e3a4bb75f972c500d5a3626f74f6b69436d515b55a0344c4b29f28ad0cba56c3b',2,1,0,NULL,NULL,1,'2019-04-04 10:16:05','2019-04-04 10:16:05',0),(245,'john@yopmail.com','36caaf24079c252cee0b9647362766cee4ce4a6b5dda5f3e86ce585d69555c5fc992ddd313d8c13f510f07417a315b734111c8c67890fdf0fd1bbc3f5d1d5157',2,1,0,NULL,NULL,1,'2019-04-08 08:38:17','2019-04-08 08:38:17',0),(246,'asif@yalgo.com','92a3094ba39a8b444d571d4cee80e897eb7b95c3ec11f5d6595f8fa326c1a0c959438f39c3b026493a4390f5fe7463563e6b0b703cb99ff27de7f68e610f54e8',3,1,0,NULL,NULL,1,'2019-04-09 12:23:52','2019-04-09 12:23:52',0),(247,'david@yalgo.com','b342383c8c8d4a9571601158c4ae308e091aa12a24e568aa21bfa4f3db8cb0ed63ee4d50259a7fa2be5a8deef3f4dec4dd87f683746c5d8734b818131a778668',3,1,0,NULL,NULL,1,'2019-04-09 13:16:43','2019-04-09 13:16:43',0),(248,'mafiasilk@gmail.com','33f718bfd5519b373d5dce5de8f27b78e2b14dd1710d1256e86c4b97ef7e98ab1f42f88f017628bef3d68032f1be7b2e604e0a133fbdd99616f06302501e370b',2,1,0,NULL,NULL,1,'2019-04-10 16:19:52','2019-04-10 16:19:52',0),(249,'lanadelray2@mailinator.com','1154e4485abba57f484c30a2ea543144178ff6a03da4503678a04ff8e808445709476e2e058af1c35afb1842eff5b7182d5d18fc3b98f185c47472520169af71',3,0,0,NULL,NULL,1,'2019-04-15 11:07:19','2019-04-15 11:07:19',0),(250,'lanadelray6@mailinator.com','1154e4485abba57f484c30a2ea543144178ff6a03da4503678a04ff8e808445709476e2e058af1c35afb1842eff5b7182d5d18fc3b98f185c47472520169af71',3,0,0,NULL,NULL,1,'2019-04-15 11:11:09','2019-04-15 11:11:09',0),(251,'abhinav@mailinator.com','3c7959e8355f19cb6c7a023e46099e5ea9ef23cc4c75675d153b366289fa1d1df18134229825b75064c6a4e86d97e3fa6ebaaed2c1da8c93500024c3c3f4ffd4',2,1,0,NULL,NULL,1,'2019-04-16 08:51:02','2019-04-16 08:51:02',0),(252,'samantha103@mailinator.com','e8be9807c3ec0bd1ce2a58e9cddd4a89966820aedc509830b62f05a226dd29a3764e4962acf28b4b87377b347b9395e1dd5bc87fed1e44f17315b89d7501836c',2,1,0,NULL,NULL,1,'2019-04-16 12:41:36','2019-04-16 12:41:36',0),(253,'meetamehta@mailinator.com','3c7959e8355f19cb6c7a023e46099e5ea9ef23cc4c75675d153b366289fa1d1df18134229825b75064c6a4e86d97e3fa6ebaaed2c1da8c93500024c3c3f4ffd4',2,1,0,NULL,NULL,1,'2019-04-17 09:59:21','2019-04-17 09:59:21',0);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users_offer_metadata`
--

DROP TABLE IF EXISTS `users_offer_metadata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users_offer_metadata` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `total_offer_scanned` bigint(20) DEFAULT '0',
  `total_earned_loyalty_points` bigint(20) DEFAULT '0',
  `user_id` bigint(20) DEFAULT NULL,
  `business_location_id` bigint(20) DEFAULT NULL,
  `status` tinyint(4) DEFAULT '1',
  `created` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `fk_user_id` (`user_id`),
  CONSTRAINT `fk_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_offer_metadata`
--

LOCK TABLES `users_offer_metadata` WRITE;
/*!40000 ALTER TABLE `users_offer_metadata` DISABLE KEYS */;
/*!40000 ALTER TABLE `users_offer_metadata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'yalgo_dev'
--
/*!50003 DROP PROCEDURE IF EXISTS `AddBusinessRating` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`yalgo_dev`@`%` PROCEDURE `AddBusinessRating`(
in user_id BIGINT,
in business_location_id BIGINT,
in business_location_address_id BIGINT,
in rating BIGINT,
in review VARCHAR(255)
)
BEGIN

DECLARE l_count int;


set @user_id= user_id;
set @business_location_id= business_location_id;
set @business_location_address_id= business_location_address_id;
set @rating = rating; 
set @review = review; 

INSERT into business_rating_reviews (user_id, business_location_id, business_location_address_id, rating, review) VALUES (@user_id, @business_location_id, @business_location_address_id, @rating, @review);

UPDATE business_location_addresses set rating = (select avg(rating) from business_rating_reviews where business_location_address_id = @business_location_address_id group by user_id order by created desc) where id = @business_location_address_id;
/*SELECT count(*)
  INTO l_count
  FROM business_rating_reviews br
  WHERE br.user_id = @user_id and br.business_location_id = @business_location_id and br.business_location_address_id = @business_location_address_id LIMIT 1;


   IF l_count = 0 THEN
    INSERT into business_rating_reviews (user_id, business_location_id, business_location_address_id, rating, review) VALUES (@user_id, @business_location_id, @business_location_address_id, @rating, @review);

  ELSE
    UPDATE business_rating_reviews  SET rating = @rating WHERE user_id = @user_id and  business_location_id = @business_location_id and business_location_address_id = @business_location_address_id;
	
  END IF;
*/


END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AdminBusinessList` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`yalgo_dev`@`%` PROCEDURE `AdminBusinessList`(
in page_size int, 
in page_no int, 
in sort_column VARCHAR(100),  
in sort_dir VARCHAR(255),
in search_term VARCHAR(255)
)
BEGIN

		SET @page_size = IFNULL(page_size, 10);
		SET @page_no = IFNULL(page_no, 1);
		SET @start_page =  (page_size * (page_no-1));
		-- strings can be null, empty string '', or a value
		SET @sort_column = IF (NULLIF(sort_column, ' ') IS NULL, 'business_name', sort_column);
		SET @sort_dir = IF (NULLIF(sort_dir, ' ') IS NULL, 'ASC', sort_dir);

		-- Making Where 
		set @where = " where ";
		IF search_term != "" then 
			set @where = concat(@where, "(bl.business_name LIKE '%", search_term, "%'  OR u.email LIKE  '%",search_term, "%') AND ");

		END IF;

		SET @where = concat(@where, "u.user_type_id = 2");

	--

		
		
		SET @sort_and_limit = concat(" ORDER BY ",@sort_column, " ",  @sort_dir, " LIMIT ", @page_size, " OFFSET ",@start_page);	

		-- Making QUERIES
		SET @user_count_query = "SELECT count(1) AS count";
		SET @user_list_query = "select bl.id,bl.business_name, bl.setup_complete,bl.contact_number, bl.created, bl.status,bl.is_approved, bc.category_name, bc.id as category_id, bl.user_id, u.email, u.email_confirmed ";
		set @from_query = " FROM users u JOIN business_locations bl on u.id = bl.user_id JOIN business_categories bc on bc.id = bl.business_category_id";
		set @user_count_query = concat(@user_count_query, @from_query, @where);
		set @user_list_query = concat(@user_list_query, @from_query, @where, @sort_and_limit);
		

		-- select @user_list_query;

            /*** GET Users Count************/

		PREPARE statement from @user_count_query;
		EXECUTE statement;
		DEALLOCATE PREPARE statement;


		/*** GET  User List ************/
		PREPARE statement from @user_list_query;
		EXECUTE statement;
		DEALLOCATE PREPARE statement;


		


END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AdminCategoryList` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`yalgo_dev`@`%` PROCEDURE `AdminCategoryList`(
in page_size int, 
in page_no int, 
in sort_column VARCHAR(100),  
in sort_dir VARCHAR(255),
in search_term VARCHAR(255)
)
BEGIN

		SET @page_size = IFNULL(page_size, 10);
		SET @page_no = IFNULL(page_no, 1);
		SET @start_page =  (page_size * (page_no-1));
		-- strings can be null, empty string '', or a value
		SET @sort_column = IF (NULLIF(sort_column, ' ') IS NULL, 'category_name', sort_column);
		SET @sort_dir = IF (NULLIF(sort_dir, ' ') IS NULL, 'ASC', sort_dir);

		-- Making Where 
		set @where = "";
		IF search_term != "" then 
			set @where = " where ";
			set @where = concat(@where, "(c.category_name LIKE '%", search_term, "%'  OR c.category_description LIKE  '%",search_term, "%') ");

		END IF;

		

	--

		
		
		SET @sort_and_limit = concat(" ORDER BY ",@sort_column, " ",  @sort_dir, " LIMIT ", @page_size, " OFFSET ",@start_page);	

		-- Making QUERIES
		SET @cat_count_query = "SELECT count(1) AS count from business_categories c ";
		SET @cat_list_query = "select c.id, c.category_name,c.created, c.status from business_categories c ";
		set @cat_count_query = concat(@cat_count_query, @where);
		set @cat_list_query = concat(@cat_list_query, @where, @sort_and_limit);
		

		  

            /*** GET Users Count************/

		PREPARE statement from @cat_count_query;
		EXECUTE statement;
		DEALLOCATE PREPARE statement;


		/*** GET  User List ************/
		PREPARE statement from @cat_list_query;
		EXECUTE statement;
		DEALLOCATE PREPARE statement;


		


END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AdminUserList` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`yalgo_dev`@`%` PROCEDURE `AdminUserList`(
in page_size int, 
in page_no int, 
in sort_column VARCHAR(100),  
in sort_dir VARCHAR(255),
in search_term VARCHAR(255)
)
BEGIN

		SET @page_size = IFNULL(page_size, 10);
		SET @page_no = IFNULL(page_no, 1);
		SET @start_page =  (page_size * (page_no-1));
		-- strings can be null, empty string '', or a value
		SET @sort_column = IF (NULLIF(sort_column, ' ') IS NULL, 'name', sort_column);
		SET @sort_dir = IF (NULLIF(sort_dir, ' ') IS NULL, 'ASC', sort_dir);

		-- Making Where 
		set @where = " where ";
		IF search_term != "" then 
			set @where = concat(@where, "(up.name LIKE '%", search_term, "%'  OR u.email LIKE  '%",search_term, "%') AND ");

		END IF;

		SET @where = concat(@where, "u.user_type_id = 3");

	--

		
		
		SET @sort_and_limit = concat(" ORDER BY ",@sort_column, " ",  @sort_dir, " LIMIT ", @page_size, " OFFSET ",@start_page);	

		-- Making QUERIES
		SET @user_count_query = "SELECT count(1) AS count";
		SET @user_list_query = "select u.id, u.email, up.name, up.mobile_number, up.gender, u.created, u.status ";
		set @from_query = " FROM users u JOIN user_profile up on u.id = up.user_id";
		set @user_count_query = concat(@user_count_query, @from_query, @where);
		set @user_list_query = concat(@user_list_query, @from_query, @where, @sort_and_limit);
		

		-- select @user_list_query;

            /*** GET Users Count************/

		PREPARE statement from @user_count_query;
		EXECUTE statement;
		DEALLOCATE PREPARE statement;


		/*** GET  User List ************/
		PREPARE statement from @user_list_query;
		EXECUTE statement;
		DEALLOCATE PREPARE statement;


		


END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `BusinessDetail` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`yalgo_dev`@`%` PROCEDURE `BusinessDetail`(
in lati Decimal(10,8), in longi Decimal(10,8),
in business_location_id BIGINT
)
BEGIN
set @lati = lati;
set @longi = longi;
set @business_location_id = business_location_id;
set @query = "SELECT (3959 * acos (cos (radians(?)) * cos(radians(bla.latitude)) * cos(radians(bla.longitude) - radians(?)) + sin (radians(?)) * sin(radians(bla.latitude)))) AS business_distance , bla.latitude AS business_latitude, bla.longitude AS business_longitude, bla.address AS business_address, bla.id as business_location_address_id, bl.id AS business_location_id, bl.business_name, bl.business_image, bl.logo, bla.rating, bl.telephone_number, bl.weekday_open_time, bl.weekday_close_time, bl.saturday_open_time, bl.saturday_close_time, bl.sunday_open_time, bl.sunday_close_time, bla.latitude AS business_latitude, bla.longitude AS business_longitude, 0 AS loyalty_points, bc.category_name, bc.category_icon, bc.category_hex_code, u.email FROM business_locations bl JOIN business_categories bc ON bc.id = bl.business_category_id JOIN business_location_addresses bla ON bl.id = bla.business_location_id JOIN users u ON bl.user_id = u.id WHERE bl.status =1 AND bla.id = ? AND bl.is_approved = 1; ";


		PREPARE statement from @query;
		EXECUTE statement using @lati, @longi, @lati, @business_location_id;
		DEALLOCATE PREPARE statement;


END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `BusinessOfferList` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`yalgo_dev`@`%` PROCEDURE `BusinessOfferList`(
 in user_id BIGINT,
in search_type varchar(10),
in search_term varchar(255)
)
BEGIN

	set @user_id = user_id;
	set @search_type = search_type;
	set @search_cond = "";

IF search_type = "valid" THEN
	-- set @cond = " AND NOW() between ibo.start_date and ibo.end_date";
	set @cond = " AND NOW() < ibo.end_date";
ELSE
	set @cond = " AND NOW() > ibo.end_date";
END IF;

IF search_term != "" then 
	set @search_cond = concat(@search_cond, " AND (bo.title LIKE '%", search_term, "%'  OR bo.description LIKE  '%",search_term, "%') ");
END IF;

set @query = concat("SELECT
	bo.title,
	bo.qr_code,
	bo.start_date,
	bo.end_date,
	boi.image,
	bla.rating,
	bl.business_name,
	bl.logo,
	bl.business_image,
	bla.address,
    bla.id,
    bla.address,
    sub_table.business_offer_id,   
	sub_table.business_location_address_id,   
	sub_table.business_location_id,
	sub_table.user_id,
    sub_table.created   
FROM
    (SELECT
            bogd.business_location_id,
			bogd.business_location_address_id,
            bogd.business_offer_id,
			bogd.user_id,
            bogd.created,
            @rn:=CASE
                WHEN @var_customer_id = business_location_address_id THEN @rn + 1
                ELSE 1
            END AS rn,
            @var_customer_id:=business_location_address_id
    FROM
        (SELECT @var_customer_id:=NULL, @rn:=NULL) vars, business_offer_geo_data bogd JOIN business_offers ibo on ibo.id =  bogd.business_offer_id 
        WHERE
        business_location_address_id IN (SELECT id FROM business_location_addresses) ",@cond,"
		-- group by business_location_address_id, business_location_id
    ORDER BY business_location_address_id , created DESC) as sub_table
    INNER JOIN business_location_addresses bla 
        on bla.id=sub_table.business_location_address_id
	JOIN business_offers bo ON bo.id = sub_table.business_offer_id
	JOIN business_offer_images boi ON bo.id = boi.business_offer_id
	JOIN business_locations bl ON bl.user_id = bla.user_id

WHERE
    rn <= 3 AND sub_table.user_id = ",@user_id,@search_cond,"
ORDER BY sub_table.created DESC");


-- select @query;

		PREPARE statement from @query;
		EXECUTE statement;
		DEALLOCATE PREPARE statement;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Business_Activate_OR_REPLACE_PROGRAMM` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`yalgo_dev`@`%` PROCEDURE `Business_Activate_OR_REPLACE_PROGRAMM`(
in id BIGINT, 
in replacer_id BIGINT, 
in user_id BIGINT)
Business_Activate_OR_REPLACE_PROGRAMM_LABEL:BEGIN

set @id = id;
set @replacer_id = replacer_id;
set @user_id = user_id;
set @current_actives = 0;

select count(*) current_actives into @current_actives from  business_loyalty_programms where is_active = 1 and user_id = @user_id;

  IF (@replacer_id = 0 AND @current_actives > 2) THEN
    select "ACTIVE_REPACE_ERROR" as error;
	LEAVE Business_Activate_OR_REPLACE_PROGRAMM_LABEL;
  END IF;

IF @replacer_id = 0 then

set @query = "update business_loyalty_programms set is_active = 1 where user_id = ? and id = ?;";
PREPARE statement from @query;
EXECUTE statement using  @user_id, @id;
DEALLOCATE PREPARE statement;


ELSE
set @query = "update business_loyalty_programms set is_active = 0 where user_id = ? and id = ?;";
PREPARE statement from @query;
EXECUTE statement using  @user_id, @id;
DEALLOCATE PREPARE statement;


set @query = "update business_loyalty_programms set is_active = 1 where user_id = ? and id = ?;";
PREPARE statement from @query;
EXECUTE statement using  @user_id, @replacer_id;


DEALLOCATE PREPARE statement;

END IF;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Business_LoyaltyProgrammList` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`yalgo_dev`@`%` PROCEDURE `Business_LoyaltyProgrammList`(IN user_id BIGINT, IN is_active INT, IN page_size int, IN page_no int)
BEGIN

SET @user_id = user_id;

SET @page_size = IFNULL(page_size, 10);
SET @page_no = IFNULL(page_no, 1);
SET @start_page = (page_size * (page_no-1));
SET @is_active = is_active;

set @query = concat("SELECT blp.*
FROM business_loyalty_programms blp
WHERE blp.user_id= ?
  AND blp.is_active = ?
ORDER BY blp.created DESC LIMIT ? OFFSET ?;") ;



		PREPARE statement from @query;
		EXECUTE statement using @user_id, @is_active, @page_size, @start_page;
		DEALLOCATE PREPARE statement;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Business_offerDetailForEdit` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`yalgo_dev`@`%` PROCEDURE `Business_offerDetailForEdit`(
in business_offer_id BIGINT,
in user_id BIGINT
)
BEGIN

set @business_offer_id = business_offer_id;
set @user_id = user_id;

SELECT bo.id,
       bo.title,
       bo.description,
       bo.start_date,
       bo.end_date,
	   bo.redeem_start_time,
	   bo.redeem_close_time,
	   bo.scan_per_user_limit,			
	   bo.term_conditions,		
       bo.is_published,
		bo.notify_yalgo_users,
		bo.notify_yalgo_customers,
		bogd.radius,
       bogd.business_location_address_id,
       bla.address,
		bla.latitude,
		bla.longitude,
		bl.logo,
		bl.business_image,
       boi.image AS business_offer_images

FROM business_offers bo
JOIN business_offer_images boi ON bo.id = boi.business_offer_id
JOIN business_offer_geo_data bogd ON bo.id = bogd.business_offer_id
JOIN business_location_addresses bla ON bla.id = bogd.business_location_address_id
JOIN business_locations bl ON bl.id = bla.business_location_id
WHERE bo.id = @business_offer_id AND bo.user_id = @user_id;


END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Business_OfferDetailList` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`yalgo_dev`@`%` PROCEDURE `Business_OfferDetailList`(
 in user_id BIGINT,
in business_location_address_id BIGINT,
in search_type varchar(10),
in search_term varchar(255),
in page_size int, 
in page_no int
)
BEGIN

	set @user_id = user_id;
	set @business_location_address_id = business_location_address_id;
	set @search_type = search_type;
	set @search_cond = "";
	SET @page_size = IFNULL(page_size, 10);
	SET @page_no = IFNULL(page_no, 1);
	SET @start_page =  (page_size * (page_no-1));

IF search_type = "valid" THEN
	-- set @cond = " AND NOW() between bo.start_date and bo.end_date";
	set @cond = " AND NOW() < ibo.end_date";
ELSE
	set @cond = " AND NOW() > bo.end_date";
END IF;

IF search_term != "" then 
	set @cond = concat(@cond, " AND (bo.title LIKE '%", search_term, "%'  OR bo.description LIKE  '%",search_term, "%') ");
END IF;

set @query = concat("SELECT
	bo.id business_offer_id,
	bo.title,
	bo.qr_code,
	bo.start_date,
	bo.end_date,
	boi.image,
	bla.rating,
	bl.business_name,
	bl.logo,
	bl.business_image,
	bla.address,
    bla.id,
    bla.address,
	bla.id business_location_address_id,   
	bla.business_location_id,
	bo.user_id,
    bo.created   
FROM
    business_offers bo
	JOIN business_offer_geo_data bogd on bogd.business_offer_id=bo.id
    JOIN business_location_addresses bla on bla.id=bogd.business_location_address_id
	JOIN business_offer_images boi ON bo.id = boi.business_offer_id
	JOIN business_locations bl ON bl.user_id = bla.user_id

WHERE
    bogd.business_location_address_id = ? AND bo.user_id = ?",@search_cond,"
ORDER BY bo.created DESC LIMIT ? OFFSET ?;");


-- select @query;

		PREPARE statement from @query;
		EXECUTE statement using @business_location_address_id, @user_id, @page_size, @start_page;
		DEALLOCATE PREPARE statement;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Customer_AddOfferPoints` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`yalgo_dev`@`%` PROCEDURE `Customer_AddOfferPoints`(
in qr_code varchar(2000),
in user_id BIGINT,
in lati Decimal(10,8), in longi Decimal(10,8)
)
Customer_AddOfferPointsLabel:BEGIN

DECLARE l_count int;
DECLARE l_scan_per_user_limit int;
DECLARE current_points int;

set @qr_code = qr_code;
set @user_id= user_id;
set @business_offer_id= 0;
set @business_location_id= 0;
set @business_location_address_id= 0;

set @lati = lati;
set @longi = longi;
set @distance = 0;
set @radius = 0;
 

SELECT
	bo.id,
	bla.id AS business_location_address_id,
	bl.id AS business_location_id,
  (3959 * ACOS(COS(RADIANS(@lati)) * COS(RADIANS(bla.latitude)) * COS(RADIANS(bla.longitude) - RADIANS(@longi)) + SIN(RADIANS(@lati)) * SIN(RADIANS(bla.latitude)))) AS offer_distance,
  bogd.radius
  
   into @business_offer_id, @business_location_address_id, @business_location_id, @distance, @radius
FROM business_offers bo
JOIN business_locations bl
  ON bo.user_id = bl.user_id
JOIN business_categories bc
  ON bc.id = bl.business_category_id
JOIN business_offer_geo_data bogd
  ON bo.id = bogd.business_offer_id
JOIN business_location_addresses bla
  ON bogd.business_location_address_id = bla.id

WHERE bo.status = 1
AND bl.status = 1
AND bl.is_approved = 1
AND bo.qr_code = @qr_code
-- AND HOUR(date) BETWEEN 6 AND 10
AND NOW() BETWEEN bo.start_date AND bo.end_date
GROUP BY bogd.business_offer_id, bogd.business_location_id, bogd.business_location_address_id
HAVING offer_distance > 0
ORDER BY offer_distance ASC , bogd.radius ASC limit 1;

IF (@distance > @radius) THEN
	select 'Location you are scanning from is far away from business range' as error;
	leave Customer_AddOfferPointsLabel;
END IF;



IF (@business_offer_id = 0 OR @business_location_id = 0 OR @business_location_address_id = 0) THEN
	select 'Invalid offer' as error;
	leave Customer_AddOfferPointsLabel;
END IF;

-- select @business_offer_id, @business_location_id, @business_location_address_id;


SELECT count(*), COALESCE(uolp.points,0), bo.scan_per_user_limit
  INTO l_count, current_points, l_scan_per_user_limit
  FROM user_offer_loyalty_points uolp JOIN business_offers bo on bo.id = uolp.business_offer_id
  WHERE uolp.user_id = @user_id and uolp.business_offer_id = @business_offer_id and uolp.business_location_id = @business_location_id and uolp.business_location_address_id = @business_location_address_id LIMIT 1;


 IF current_points  < l_scan_per_user_limit THEN
	
	  IF l_count = 0 THEN
    INSERT into user_offer_loyalty_points (user_id, business_offer_id, business_location_id, business_location_address_id, points) VALUES (@user_id, @business_offer_id, @business_location_id, @business_location_address_id, 1);
select 1 as points, @business_offer_id as business_offer_id, @business_location_id as business_location_id, @business_location_address_id  as business_location_address_id ;
INSERT into user_offer_loyalty_point_history (user_id, business_offer_id, business_location_id, business_location_address_id, point) VALUES (@user_id, @business_offer_id, @business_location_id, @business_location_address_id, 1);
  ELSE
    UPDATE user_offer_loyalty_points  SET points = current_points + 1 WHERE user_id = @user_id and business_offer_id = @business_offer_id and business_location_id = @business_location_id and business_location_address_id = @business_location_address_id;
	select current_points + 1 as points, @business_offer_id as business_offer_id, @business_location_id as business_location_id, @business_location_address_id  as business_location_address_id ;
INSERT into user_offer_loyalty_point_history (user_id, business_offer_id, business_location_id, business_location_address_id, point) VALUES (@user_id, @business_offer_id, @business_location_id, @business_location_address_id, 1);


  END IF;

	ELSE
	select "Scan limit has been reached" as error;
 END IF;



END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `FavouriteOfferLocationList` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`yalgo_dev`@`%` PROCEDURE `FavouriteOfferLocationList`(
 in user_id BIGINT,
in search_type varchar(10),
in search_term varchar(255)
)
BEGIN

set @user_id = user_id;
set @search_type = search_type;
set @search_cond = "";

IF search_type = "valid" THEN
	set @cond = " AND NOW() between ibo.start_date and ibo.end_date";
ELSE
	set @cond = " AND NOW() > ibo.end_date";
END IF;

IF search_term != "" then 
	set @search_cond = concat(@search_cond, " AND (bo.title LIKE '%", search_term, "%'  OR bo.description LIKE  '%",search_term, "%') ");
END IF;


set @query = concat("SELECT
	bo.title,
	bo.start_date,
	bo.end_date,
	boi.image,
	bla.rating,
	bl.business_name,
	bl.logo,
	bl.business_image,
	bla.address,
    bla.id,
    bla.address,
    sub_table.business_offer_id,   
	sub_table.business_location_address_id,   
	sub_table.business_location_id,
	sub_table.user_id,
    sub_table.created   
FROM
    (SELECT
            ufo.business_location_address_id,
            ufo.business_offer_id,
			ufo.business_location_id,
			ufo.user_id,
            ufo.created,
            @rn:=CASE
                WHEN @var_customer_id = business_location_address_id THEN @rn + 1
                ELSE 1
            END AS rn,
            @var_customer_id:=business_location_address_id
    FROM
        (SELECT @var_customer_id:=NULL, @rn:=NULL) vars, user_favourite_offers ufo JOIN business_offers ibo on ibo.id =  ufo.business_offer_id 
        WHERE
        business_location_address_id IN (SELECT id FROM business_location_addresses) ",@cond,"
		-- group by business_location_address_id, business_location_id
    ORDER BY business_location_address_id , created DESC) as sub_table
    INNER JOIN business_location_addresses bla 
        on bla.id=sub_table.business_location_address_id
	JOIN business_offers bo ON bo.id = sub_table.business_offer_id
	JOIN business_offer_images boi ON bo.id = boi.business_offer_id
	JOIN business_locations bl ON bl.user_id = bla.user_id

WHERE
    rn <= 3 AND sub_table.user_id = ",@user_id,@search_cond,"
ORDER BY sub_table.created DESC");


-- select @query;

		PREPARE statement from @query;
		EXECUTE statement;
		DEALLOCATE PREPARE statement;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetBusinessRecommendationList` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`yalgo_dev`@`%` PROCEDURE `GetBusinessRecommendationList`(
in page_size int, 
in page_no int, 
in sort_column VARCHAR(100),  
in sort_dir VARCHAR(255),
in search_term VARCHAR(255)
)
BEGIN
SET @page_size = IFNULL(page_size, 10);
		SET @page_no = IFNULL(page_no, 1);
		SET @start_page =  (page_size * (page_no-1));
		-- strings can be null, empty string '', or a value
		SET @sort_column = IF (NULLIF(sort_column, ' ') IS NULL, 'title', sort_column);
		SET @sort_dir = IF (NULLIF(sort_dir, ' ') IS NULL, 'ASC', sort_dir);

		-- Making Where 
		set @where = "";
		IF search_term != "" then 
			set @where = " where ";
			set @where = concat(@where, "(I.business_name LIKE '%", search_term, "%'  OR I.business_address LIKE  '%",search_term, "%' OR U.name LIKE  '%",search_term, "%' 
            OR I.business_contact LIKE  '%",search_term, "%' OR I.business_telephone_number LIKE  '%",search_term, "%') ");

		END IF;

		

	--

		
		
		SET @sort_and_limit = concat(" ORDER BY ",@sort_column, " ",  @sort_dir, " LIMIT ", @page_size, " OFFSET ",@start_page);	

		-- Making QUERIES
		SET @cat_count_query = "SELECT count(1) AS count from business_recommendations I INNER JOIN user_profile U ON U.user_id=I.user_id";
		SET @cat_list_query = "select I.id,U.name,I.business_contact, I.business_name,I.business_address,I.business_contact,
        I.business_telephone_number,I.created,I.business_association,I.is_business_aware,I.status 
        from business_recommendations I INNER JOIN user_profile U ON U.user_id=I.user_id";
		set @cat_count_query = concat(@cat_count_query, @where);
		set @cat_list_query = concat(@cat_list_query, @where, @sort_and_limit);
		

		  

            /*** GET Users Count************/

		PREPARE statement from @cat_count_query;
		EXECUTE statement;
		DEALLOCATE PREPARE statement;


		/*** GET  User List ************/
		PREPARE statement from @cat_list_query;
		EXECUTE statement;
		DEALLOCATE PREPARE statement;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetContactIquiryList` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`yalgo_dev`@`%` PROCEDURE `GetContactIquiryList`(
in page_size int, 
in page_no int, 
in sort_column VARCHAR(100),  
in sort_dir VARCHAR(255),
in search_term VARCHAR(255)
)
BEGIN
SET @page_size = IFNULL(page_size, 10);
		SET @page_no = IFNULL(page_no, 1);
		SET @start_page =  (page_size * (page_no-1));
		-- strings can be null, empty string '', or a value
		SET @sort_column = IF (NULLIF(sort_column, ' ') IS NULL, 'title', sort_column);
		SET @sort_dir = IF (NULLIF(sort_dir, ' ') IS NULL, 'ASC', sort_dir);

		-- Making Where 
		set @where = "";
		IF search_term != "" then 
			set @where = " where ";
			set @where = concat(@where, "(I.title LIKE '%", search_term, "%'  OR I.message LIKE  '%",search_term, "%'OR U.name LIKE  '%",search_term, "%') ");

		END IF;

		

	--

		
		
		SET @sort_and_limit = concat(" ORDER BY ",@sort_column, " ",  @sort_dir, " LIMIT ", @page_size, " OFFSET ",@start_page);	

		-- Making QUERIES
		SET @cat_count_query = "SELECT count(1) AS count from inquiries I INNER JOIN user_profile U ON U.user_id=I.user_id";
		SET @cat_list_query = "select I.id,U.name, I.title,LEFT(I.message,50) AS message,I.read_status,I.is_replied,I.created,I.status from 
        inquiries I INNER JOIN user_profile U ON U.user_id=I.user_id";
		set @cat_count_query = concat(@cat_count_query, @where);
		set @cat_list_query = concat(@cat_list_query, @where, @sort_and_limit);
		

		  

            /*** GET Users Count************/

		PREPARE statement from @cat_count_query;
		EXECUTE statement;
		DEALLOCATE PREPARE statement;


		/*** GET  User List ************/
		PREPARE statement from @cat_list_query;
		EXECUTE statement;
		DEALLOCATE PREPARE statement;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetStaticPageList` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`yalgo_dev`@`%` PROCEDURE `GetStaticPageList`(
in page_size int, 
in page_no int, 
in sort_column VARCHAR(100),  
in sort_dir VARCHAR(255),
in search_term VARCHAR(255))
BEGIN
SET @page_size = IFNULL(page_size, 10);
		SET @page_no = IFNULL(page_no, 1);
		SET @start_page =  (page_size * (page_no-1));
		-- strings can be null, empty string '', or a value
		SET @sort_column = IF (NULLIF(sort_column, ' ') IS NULL, 'page_title', sort_column);
		SET @sort_dir = IF (NULLIF(sort_dir, ' ') IS NULL, 'ASC', sort_dir);

		-- Making Where 
		set @where = "";
		IF search_term != "" then 
			set @where = " where ";
			set @where = concat(@where, "(p.page_title LIKE '%", search_term, "%' OR p.page_description LIKE  '%",search_term, "%') ");

		END IF;

		

	--

		
		
		SET @sort_and_limit = concat(" ORDER BY ",@sort_column, " ",  @sort_dir, " LIMIT ", @page_size, " OFFSET ",@start_page);	

		-- Making QUERIES
		SET @cat_count_query = "SELECT count(1) AS count from static_pages p ";
		SET @cat_list_query = "select p.id, p.page_title,LEFT(p.page_description,50) AS page_description,p.created, p.status,p.slug from static_pages p ";
		set @cat_count_query = concat(@cat_count_query, @where);
		set @cat_list_query = concat(@cat_list_query, @where, @sort_and_limit);
		

		  

            /*** GET Users Count************/

		PREPARE statement from @cat_count_query;
		EXECUTE statement;
		DEALLOCATE PREPARE statement;


		/*** GET  User List ************/
		PREPARE statement from @cat_list_query;
		EXECUTE statement;
		DEALLOCATE PREPARE statement;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `MyLoyaltyPoints` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`yalgo_dev`@`%` PROCEDURE `MyLoyaltyPoints`(

in page_size int, 
in page_no int, 
in user_id BIGINT
)
BEGIN

SET @user_id = user_id;
SET @page_size = IFNULL(page_size, 10);
SET @page_no = IFNULL(page_no, 1);
SET @start_page =  (page_size * (page_no-1));

set @query = "SELECT
uolp.id,	
uolp.business_location_id,
uolp.business_location_address_id,
bl.business_name,
	bl.business_image,
	bl.logo,
   uolp.points,
   (SELECT target_points FROM business_loyalty_programms  WHERE uolp.points <= target_points ORDER BY target_points LIMIT 1) as target_points
FROM
   yalgo_dev.user_offer_loyalty_poitns uolp
JOIN business_locations bl on bl.id = uolp.business_location_id
where uolp.user_id = ? order by uolp.created desc LIMIT ? OFFSET ?;"; 



		PREPARE statement from @query;
		EXECUTE statement using @user_id, @page_size, @start_page;
		DEALLOCATE PREPARE statement;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `NearByOffers` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`yalgo_dev`@`%` PROCEDURE `NearByOffers`(
in lati Decimal(10,8), in longi Decimal(10,8),
in radius INT,
in rating varchar(10),
in category_id varchar(1000)
)
BEGIN
set @lati = lati;
set @longi = longi;
set @radius = radius;

-- filters 
IF (rating != "")  THEN
set @rating = rating;
ELSE
set @rating = NULL;
END IF;

IF (category_id != "")  THEN
set @category_id = category_id;
ELSE
set @category_id = NULL;
END IF;
-- filters ends


SELECT
  bo.id,
  bo.title,
  (3959 * ACOS(COS(RADIANS(@lati)) * COS(RADIANS(bla.latitude)) * COS(RADIANS(bla.longitude) - RADIANS(@longi)) + SIN(RADIANS(@lati)) * SIN(RADIANS(bla.latitude)))) AS offer_distance,
  bla.latitude AS offer_latitude,
  bla.longitude AS offer_longitude,
  bla.address AS offer_address,
  bla.id AS business_location_address_id,
  bo.description,
  boi.image AS offer_image,
  bl.id AS business_location_id,
  bl.business_name,
  bl.business_image,
  bl.logo,
  bla.rating,
  bla.latitude AS business_latitude,
  bla.longitude AS business_longitude,
  0 AS loyalty_points,
  bc.category_name,
  bc.category_icon,
  bc.category_hex_code
FROM business_offers bo
JOIN business_offer_images boi
  ON bo.id = boi.business_offer_id
JOIN business_locations bl
  ON bo.user_id = bl.user_id
JOIN business_categories bc
  ON bc.id = bl.business_category_id
JOIN business_offer_geo_data bogd
  ON bo.id = bogd.business_offer_id
JOIN business_location_addresses bla
  ON bogd.business_location_address_id = bla.id

WHERE bo.status = 1
AND bl.status = 1
AND bl.is_approved = 1
AND NOW() BETWEEN bo.start_date AND bo.end_date
AND bla.rating = COALESCE(@rating, bla.rating)
AND FIND_IN_SET(bc.id,COALESCE(@category_id, bc.id))
GROUP BY bogd.business_offer_id, bogd.business_location_id, bogd.business_location_address_id
HAVING offer_distance <= @radius
ORDER BY offer_distance ASC;



END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `OfferDetail` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`yalgo_dev`@`%` PROCEDURE `OfferDetail`(
in lati Decimal(10,8), in longi Decimal(10,8),
in offer_id BIGINT, 
in business_location_id BIGINT,
in business_location_address_id BIGINT,
in user_id BIGINT
)
BEGIN
set @lati = lati;
set @longi = longi;
set @offer_id = offer_id;
set @business_location_id = business_location_id;
set @business_location_address_id = business_location_address_id;
set @user_id = user_id;
set @query = "SELECT bo.id,
       (3959 * acos (cos (radians(?)) * cos(radians(bla.latitude)) * cos(radians(bla.longitude) - radians(?)) + sin (radians(?)) * sin(radians(bla.latitude)))) AS offer_distance,
       bo.title,
       bo.description,
       bo.term_conditions,
       bo.start_date,
       bo.end_date,
		bo.redeem_start_time,
		bo.redeem_close_time,		
       bo.is_published,
       bla.latitude AS offer_latitude,
       bla.longitude AS offer_longitude,
       bla.address AS offer_address,
       bla.id AS business_location_address_id,
       bo.description,
       boi.image AS offer_image,
       bl.id AS business_location_id,
       bl.business_name,
       bl.business_image,
		bl.business_info,
       bl.logo,
       bla.rating,
       bl.telephone_number,
       bl.weekday_open_time,
       bl.weekday_close_time,
       bl.saturday_open_time,
       bl.saturday_close_time,
       bl.sunday_open_time,
       bl.sunday_close_time,
       bla.latitude AS business_latitude,
       bla.longitude AS business_longitude,
	bla.address,	
       0 AS loyalty_points,
       bc.category_name,
       bc.category_icon,
       bc.category_hex_code,
	   COALESCE(ufo.status,0) is_favourite,	
       u.email
FROM business_offers bo
JOIN business_offer_images boi ON bo.id = boi.business_offer_id
JOIN business_locations bl ON bo.user_id = bl.user_id
JOIN business_categories bc ON bc.id = bl.business_category_id
JOIN business_location_addresses bla ON bl.id = bla.business_location_id
JOIN users u ON bl.user_id = u.id
LEFT JOIN user_favourite_offers ufo ON ufo.business_offer_id = bo.id AND ufo.user_id = ?
WHERE bo.status=1
  AND bl.status =1
  AND bla.id = ?
  AND bo.id = ?
  AND bl.is_approved = 1
  AND NOW() BETWEEN bo.start_date AND bo.end_date;";


		PREPARE statement from @query;
		EXECUTE statement using @lati, @longi, @lati,@user_id,  @business_location_address_id, @offer_id ;
		DEALLOCATE PREPARE statement;

INSERT INTO `business_offer_views`
(`business_offer_id`, `business_location_id`, `business_location_address_id`, `user_id`)
VALUES( @offer_id, @business_location_id, @business_location_address_id, @user_id)
ON DUPLICATE KEY UPDATE
`status` = 1;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `OfferHistoryLocationList` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`yalgo_dev`@`%` PROCEDURE `OfferHistoryLocationList`(
 in user_id BIGINT,
in search_type varchar(10),
in search_term varchar(255)
)
BEGIN

set @user_id = user_id;
set @search_type = search_type;
set @search_cond = "";

IF search_type = "valid" THEN
	set @cond = " AND NOW() between ibo.start_date and ibo.end_date";
ELSE
	set @cond = " AND NOW() > ibo.end_date";
END IF;

IF search_term != "" then 
	set @search_cond = concat(@search_cond, " AND (bo.title LIKE '%", search_term, "%'  OR bo.description LIKE  '%",search_term, "%') ");
END IF;

set @query = concat("SELECT
	bo.title,
	bo.start_date,
	bo.end_date,
	boi.image,
	bla.rating,
	bl.business_name,
	bl.logo,
	bl.business_image,
	bla.address,
    bla.id,
    bla.address,
    sub_table.business_offer_id,   
	sub_table.business_location_address_id,   
	sub_table.business_location_id,
	sub_table.user_id,
    sub_table.created   
FROM
    (SELECT
            uolp.business_location_address_id,
            uolp.business_offer_id,
			uolp.business_location_id,
			uolp.user_id,
            uolp.created,
            @rn:=CASE
                WHEN @var_customer_id = business_location_address_id THEN @rn + 1
                ELSE 1
            END AS rn,
            @var_customer_id:=business_location_address_id
    FROM
        (SELECT @var_customer_id:=NULL, @rn:=NULL) vars, user_offer_loyalty_poitns uolp JOIN business_offers ibo on ibo.id =  uolp.business_offer_id 
        WHERE
        business_location_address_id IN (SELECT id FROM business_location_addresses) ",@cond,"
		-- group by business_location_address_id, business_location_id
    ORDER BY business_location_address_id , created DESC) as sub_table
    INNER JOIN business_location_addresses bla 
        on bla.id=sub_table.business_location_address_id
	JOIN business_offers bo ON bo.id = sub_table.business_offer_id
	JOIN business_offer_images boi ON bo.id = boi.business_offer_id
	JOIN business_locations bl ON bl.user_id = bla.user_id

WHERE
    rn <= 3 AND sub_table.user_id = ",@user_id, @search_cond, "
ORDER BY sub_table.created DESC");


-- select @query;

		PREPARE statement from @query;
		EXECUTE statement;
		DEALLOCATE PREPARE statement;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `OfferStatics` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`yalgo_dev`@`%` PROCEDURE `OfferStatics`(
in business_offer_id BIGINT
)
BEGIN

set @business_offer_id = business_offer_id;

-- weekly scans

SELECT DAYOFWEEK(created) field, count(*) as value, business_location_id, created
          FROM user_offer_loyalty_point_history
          WHERE created > DATE_SUB(NOW(), INTERVAL 1 WEEK)  AND business_offer_id = @business_offer_id
		  group by 	field;
-- weekly views
SELECT DAYOFWEEK(created) field, count(*) as value, business_location_id, created
          FROM business_offer_views
          WHERE created > DATE_SUB(NOW(), INTERVAL 1 WEEK)  AND business_offer_id = @business_offer_id
		  group by 	field;

-- monthly scans
SELECT Date(created) as dm, DATE(created) field, count(*) as value, business_location_id, created
          FROM user_offer_loyalty_point_history
          WHERE created > DATE_SUB(NOW(), INTERVAL 1 MONTH)  AND business_offer_id = @business_offer_id
		  group by 	field;

-- monthly views
SELECT DATE(created) field, count(*) as value, business_location_id, created
          FROM business_offer_views
          WHERE created > DATE_SUB(NOW(), INTERVAL 1 MONTH)  AND business_offer_id = @business_offer_id
		  group by 	field;

-- Daily scans

  
SELECT CONCAT(HOUR(created), ':00-', HOUR(created)+1, ':00') field, count(*) as value, business_location_id, created
          FROM user_offer_loyalty_point_history
          WHERE created > DATE_SUB(NOW(), INTERVAL 1 DAY)  AND business_offer_id = @business_offer_id
		  group by 	HOUR(created);

-- Daily views

SELECT CONCAT(HOUR(created), ':00-', HOUR(created)+1, ':00') field, count(*) as value, business_location_id, created
          FROM business_offer_views
          WHERE created > DATE_SUB(NOW(), INTERVAL 1 DAY)   AND business_offer_id = @business_offer_id
		  group by 	HOUR(created);

-- gender for offer

SELECT up.gender,
       count(*) AS value,
       business_location_id,
       up.created
FROM user_offer_loyalty_points
JOIN user_profile up ON up.user_id = user_offer_loyalty_points.user_id
WHERE business_offer_id = @business_offer_id
  AND (up.gender = 'M'
       OR up.gender = 'F')
GROUP BY up.gender;

-- average dob

SELECT AVG(YEAR(NOW())-YEAR(up.dob)) average_age
FROM user_offer_loyalty_points
JOIN user_profile up ON up.user_id = user_offer_loyalty_points.user_id
WHERE business_offer_id = @business_offer_id
  AND (up.gender = 'M'
       OR up.gender = 'F');

-- new and returning customers

SELECT COALESCE(
                  (SELECT count(*)
                   FROM user_offer_loyalty_points
                   WHERE business_offer_id = @business_offer_id
                     AND points = 1
                   GROUP BY business_offer_id), 0) as new,
                                                   COALESCE(
                                                              (SELECT count(*)
                                                               FROM user_offer_loyalty_points
                                                               WHERE business_offer_id = @business_offer_id
                                                                 AND points > 1
                                                               GROUP BY business_offer_id), 0) as returning
FROM user_offer_loyalty_points
WHERE business_offer_id = @business_offer_id
GROUP BY business_offer_id ;


-- Max scan time
SELECT CONCAT(HOUR(created), ':00-', HOUR(created)+1, ':00') field, count(*) as value, business_location_id, created
          FROM user_offer_loyalty_point_history
          WHERE business_offer_id = @business_offer_id
		  group by 	HOUR(created);

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ReviewList` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`yalgo_dev`@`%` PROCEDURE `ReviewList`(
in page_size int, 
in page_no int, 
in sort_column VARCHAR(100),  
in sort_dir VARCHAR(255),
in business_location_id BIGINT,
in business_location_address_id BIGINT
)
BEGIN
		set @business_location_id = business_location_id;
		set @business_location_address_id = business_location_address_id;
		SET @page_size = IFNULL(page_size, 10);
		SET @page_no = IFNULL(page_no, 1);
		SET @start_page =  (page_size * (page_no-1));
		-- strings can be null, empty string '', or a value
		SET @sort_column = IF (NULLIF(sort_column, ' ') IS NULL, 'created', sort_column);
		SET @sort_dir = IF (NULLIF(sort_dir, ' ') IS NULL, 'DESC', sort_dir);

		-- Making Where 
		set @where = concat(" where brr.business_location_id = ", @business_location_id, " AND brr.business_location_address_id = ", @business_location_address_id, " GROUP BY brr.user_id");

	
		

	--

		
		
		SET @sort_and_limit = concat(" ORDER BY ",@sort_column, " ",  @sort_dir, " LIMIT ", @page_size, " OFFSET ",@start_page);	

		-- Making QUERIES
		SET @cat_count_query = "SELECT count(distinct(brr.user_id)) AS count from business_rating_reviews brr ";
		SET @cat_list_query = "select brr.user_id, COALESCE(brr.review, '') as review, brr.rating,brr.created, brr.status from business_rating_reviews brr ";
		set @cat_count_query = concat(@cat_count_query, @where);
		set @cat_list_query = concat(@cat_list_query, @where, @sort_and_limit);
		

		  

            /*** GET Reviews Count************/

		PREPARE statement from @cat_count_query;
		EXECUTE statement;
		DEALLOCATE PREPARE statement;


		/*** GET  Review List ************/
		PREPARE statement from @cat_list_query;
		EXECUTE statement;
		DEALLOCATE PREPARE statement;


		


END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SaveStaticPage` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`yalgo_dev`@`%` PROCEDURE `SaveStaticPage`(
IN in_page_title VARCHAR(255),
IN in_page_description TEXT,
IN in_slug VARCHAR(255),
IN in_status TINYINT
)
BEGIN

DECLARE last_inserted_id INT DEFAULT 0;

SET @page_title = in_page_title;
SET @page_description = in_page_description;
SET @slug = in_slug;
SET @status = in_status;


IF EXISTS (Select id from static_pages where slug=@slug) THEN
   UPDATE static_pages SET page_title=@page_title,page_description=@page_description,
   status=@status WHERE slug=@slug;
   
ELSE

    INSERT INTO static_pages (page_title,page_description,slug,status) VALUES  
    (@page_title,@page_description,@slug,@status);
    
    SET last_inserted_id = LAST_INSERT_ID();
    
    SET @slug = concat(@slug,'-',last_inserted_id);
    
    UPDATE static_pages SET slug=@slug WHERE id=last_inserted_id;
    
END IF;
   
   SELECT id,page_title,page_description,slug,status,created FROM static_pages WHERE slug=@slug;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SignUp` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`yalgo_dev`@`%` PROCEDURE `SignUp`(
in _email VARCHAR(255), 
in _password VARCHAR(2000),  
in _user_type_id INT,
in _name VARCHAR(255),
in _job_title VARCHAR(255),
in _business_name VARCHAR(255),
in _telephone_number VARCHAR(255),
in _city VARCHAR(255),
in _latitude FLOAT,
in _longitude FLOAT,
in _device_type VARCHAR(255),
in _device_token VARCHAR(1000),
in _business_category_id int,
in _verification_token VARCHAR(2000),
in _email_confirmed tinyint
)
BEGIN

    IF  EXISTS(SELECT (1) FROM users WHERE email = _email ) THEN 
        SELECT concat('User already exist with ' , _email, ' email address') as error;
    ELSE
        /*** Save User ************/
		

		set @values = concat(" values ('", _email , "','" , _password, "'," , _user_type_id,  "," ,_email_confirmed, ")");
		set @query = concat('insert into users (email, password, user_type_id, email_confirmed )');
		set @query = concat(@query, @values);
		PREPARE statement from @query;
		EXECUTE statement;
		DEALLOCATE PREPARE statement;


		/*** Save Profile************/
		set @user_id = LAST_INSERT_ID();
		set @values = concat(" values ('", _name , "'," , @user_id, ",'" , _verification_token, "','", _device_type, "','", _device_token, "',", _latitude, ",", _longitude , ")");
		set @query = concat('insert into user_profile (name, user_id, verification_token, device_type, device_token, latitude, longitude)');
		set @query = concat(@query, @values);
		PREPARE statement from @query;
		EXECUTE statement;
		DEALLOCATE PREPARE statement;
		
		IF (_user_type_id = 3) THEN
		SELECT @user_id as id, _email as email, _user_type_id as user_type_id, _name as name, _latitude as latitude, _longitude as longitude, _device_type as device_type, _device_token as device_token;
		ELSE
		SELECT @user_id as id, _email as email, _user_type_id as user_type_id, _name as name, _job_title as job_title, _business_name as business_name, _telephone_number as telephone_number, _latitude as latitude, _longitude as longitude, _device_type as device_type, _device_token as device_token;
		END IF;
		/***********Set Up Business ************/
		 IF (_user_type_id = 2) THEN
			set @values = concat(" values ('", _business_name , "','" , _telephone_number, "','" , _city, "'," , @user_id, "," , _business_category_id,  ")");
			set @query = concat('insert into business_locations (business_name, telephone_number, city, user_id, business_category_id)');
			set @query = concat(@query, @values);
			PREPARE statement from @query;
			EXECUTE statement;
			DEALLOCATE PREPARE statement;
			set @business_location_id = LAST_INSERT_ID();
			set @values = concat(" values ('", _job_title, "',",  @business_location_id , "," , @user_id, ")");
			set @query = concat('insert into business_location_users (job_title, business_location_id, user_id)');
			set @query = concat(@query, @values);
			PREPARE statement from @query;
			EXECUTE statement;
			DEALLOCATE PREPARE statement;
		  END IF;

    END IF; 


END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `temp` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`yalgo_dev`@`%` PROCEDURE `temp`()
BEGIN

set time_zone = '+8:00';
SELECT * FROM yalgo_dev.temp;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ToggleStatus` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`yalgo_dev`@`%` PROCEDURE `ToggleStatus`(in tbl_name varchar(50), id BIGINT)
BEGIN
set @query = concat("UPDATE ",tbl_name," SET status = 1 - status where id =", id);

		PREPARE statement from @query;
		EXECUTE statement;
		DEALLOCATE PREPARE statement;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-04-17 20:55:01
