import { Handler, Context, Callback } from 'aws-lambda';
import { to, decodeToken } from './src/util/helper';
import * as dotenv from 'dotenv';
const jwt_decode = require('jwt-decode');
import * as _ from 'lodash';
import { AggregationManagement } from './src/handlers/AggregationManagement';



function renderResponse(err, res, callback) {
  let response = {};
  if (err) {
    response = {
      success: false,
      message: err.message,
      statusCode: err.statusCode || 500,
      data: {}
    };
  } else {

    response = {
      success: true,
      message: res.message,
      statusCode: res.statusCode || 200,
      data: res.data || {}
    };
  }
  return callback(null, {
    statusCode: 200,
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Credentials': false,
    },
    body: JSON.stringify(response)
  })
}

function parseBody(event: any) {

  dotenv.config();

  let data: any = {};
  if (event.body !== null && event.body !== undefined) {
    let body: any;
    try {
      body = JSON.parse(event.body)
    } catch (e) {
      body = event.body
    }
    data = body;
  }
  
  return data;

}

function getToken(event: any): any {
  let token:any = {};
  try {
    token = jwt_decode(event.headers.Authorization || event.headers.authorization)
  } catch (e) {
  }
  return token;
}


const GetProductsByBoxId: Handler = (event: any, context: Context, callback: Callback) => {
  (async () => {
    let [err, response] = await to(new AggregationManagement().GetProductsByBoxId(parseBody(event)));
    renderResponse(err, response, callback);
  })();
}


const GetProductsByPalletId: Handler = (event: any, context: Context, callback: Callback) => {
  (async () => {
    let [err, response] = await to(new AggregationManagement().GetProductsByPalletId(parseBody(event)));
    renderResponse(err, response, callback);
  })();
}

const SaveProducts: Handler = (event: any, context: Context, callback: Callback) => {
  (async () => {
    let [err, response] = await to(new AggregationManagement().SaveProducts(parseBody(event), getToken(event)));
    renderResponse(err, response, callback);
  })();
}

const SavePalletTransaction: Handler = (event: any, context: Context, callback: Callback) => {
  (async () => {
    let [err, response] = await to(new AggregationManagement().SavePalletTransaction(parseBody(event), getToken(event)));
    renderResponse(err, response, callback);
  })();
}

const GetMonitorData: Handler = (event: any, context: Context, callback: Callback) => {
  (async () => {

    let [err, response] = await to(new AggregationManagement().GetMonitorData(parseBody(event)));
    renderResponse(err, response, callback);
  })();
}

export { GetProductsByBoxId, GetProductsByPalletId, SaveProducts, SavePalletTransaction, GetMonitorData }
