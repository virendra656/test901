export function validateGTIN(code): boolean {
  //logic guide https://www.gs1.org/services/how-calculate-check-digit-manually

  console.log('gtin',code)
  try {
    let sequenceLength = 18;
    let sequence = [];
    var sum: number = 0;
    let checkDigit: any = null;
    //prepend 0 for global logic GTIN Length

    if (code.length < sequenceLength) {
      let padding = "";
      for (let i = 0; i < sequenceLength - code.length; i++) {
        padding += "0";
      }
      code = padding + code;
    }


    for (let i = 0; i < code.length - 1; i++) {
      let multiplier = i % 2 == 0 ? 3 : 1;
      let value = multiplier * parseInt(code[i]);
      sum += value
      sequence.push(value);
    }

    if (sum % 10 == 0 && sum > 0) {
      checkDigit = 0
    }

    else if (sum > 0) {
      checkDigit = (10 * (parseInt((sum / 10).toString()) + 1)) - sum;
    }
    console.log(checkDigit);
    console.log(code[code.length - 1]);
    return checkDigit == code[code.length - 1]
  } catch (e) {
    console.log(e);
    return false;
  }

}

export function oldreadBarCodeData(code) {

  let response = {
    product_code: '',
    serial_number: '',
    batch_id: '',
    expiry_date: ''
  };
  if (code !== '') {
    if (code.indexOf('01') !== -1 && code.indexOf('10') !== -1 && code.indexOf('17') !== -1 && code.indexOf('21') !== -1) {
      if (code.startsWith('(')) {
        const barCodeData: string[] = code.split('(').filter(function (v) { return v !== ''; });
        if (barCodeData.length === 4) {

          for (let i = 0; i < barCodeData.length; i++) {
            if (barCodeData[i].startsWith('01)')) {
              response.product_code = barCodeData[i].substring(3);
            } else if (barCodeData[i].startsWith('21)')) {
              response.serial_number = barCodeData[i].substring(3);
            } else if (barCodeData[i].startsWith('17)')) {
              response.expiry_date = barCodeData[i].substring(3);
            } else if (barCodeData[i].startsWith('10)')) {
              response.batch_id = barCodeData[i].substring(3);
            }
          }
        }

      } else if (code.length === 61) {

        response.product_code = code.substring(2, 16);
        response.expiry_date = code.substring(18, 24);
        response.batch_id = code.substring(26, 40);
        response.serial_number = code.substring(42, 62);


      }
      else if (code.length === 64) {

        response.product_code = code.substring(5, 19);
        response.expiry_date = code.substring(21, 27);
        response.batch_id = code.substring(29, 43);
        response.serial_number = code.substring(45, 65);


      }
      else if (code.length === 43) {

        response.product_code = code.substring(2, 16);
        response.expiry_date = code.substring(18, 24);
        response.batch_id = code.substring(26, 31);
        response.serial_number = code.substring(33, 43);


      }
      else if (code.length === 57) {
        code = code.substring(3);
        response.product_code = code.substring(2, 16);
        response.expiry_date = code.substring(18, 24);
        response.batch_id = code.substring(26, 32);
        response.serial_number = code.substring(34, 54);
      }

      else if (code.length === 54) {
        response.product_code = code.substring(2, 16);
        response.expiry_date = code.substring(18, 24);
        response.batch_id = code.substring(26, 32);
        response.serial_number = code.substring(34, 54);
      }

      else if (code.length === 55) {
        response.product_code = code.substring(5, 19);
        response.expiry_date = code.substring(21, 27);
        response.batch_id = code.substring(29, 39);
        response.serial_number = code.substring(41);
      }

      else if (code.length === 46) {
        code = code.substring(3);
        response.product_code = code.substring(2, 16);
        response.expiry_date = code.substring(18, 24);
        response.batch_id = code.substring(26, 31);
        response.serial_number = code.substring(33, 43);
      }
    } else {
      // let try PPN scheme 
      if (code.indexOf('9N') !== -1 && code.indexOf('1T') !== -1 && code.indexOf('D') !== -1 && code.indexOf('S') !== -1) {

        response.product_code = code.substring(code.indexOf('9N') + 2, code.indexOf('1T'));
        response.batch_id = code.substring(code.indexOf('1T') + 2, code.indexOf('D'));
        response.expiry_date = code.substring(code.indexOf('D') + 1, code.indexOf('S'));
        response.serial_number = code.substring(code.indexOf('S') + 1, code.length);

      }
    }
  }
  return response;
}

export function getSepratorIndex(code: any): any {

  let res = null;
  let spIndx = 0;
  for (let i = 0; i < code.length; i++) {

    if (code[i].charCodeAt() == 29 || code[i].charCodeAt() == 32) {
      spIndx = i;
    }
  }
  return spIndx;
}
export function readBarCodeData(code) {

  code = code.replace(/]d2/g, "");
  code = code.replace(/[^a-zA-Z0-9]/g, ' ')
  if (getSepratorIndex(code) == 0) {
    return oldreadBarCodeData(code);
  }
  code = code.trim();
  let response = {
    product_code: '',
    serial_number: '',
    batch_id: '',
    expiry_date: ''
  };
  var nhrn: '';
  if (code !== '') {
    while (code != "") {
      // let say this is starting with gtin (14) digit
      let flag = 1;
      // alert(code)
      if (!response.product_code && code.substring(0, 2) == "01") {
        response.product_code = code.substring(2, 16);
        code = code.substring(16);
      }

      // let say this is starting with exp (6) digit
      else if (!response.expiry_date && code.substring(0, 2) == "17") {
        response.expiry_date = code.substring(2, 8);
        code = code.substring(8);
      }

      // let say this is starting with 21 sn varlength
      else if (!response.serial_number && code.substring(0, 2) == "21") {
        let len = code.indexOf(" ") > -1 ? code.indexOf(" ") : code.length;
        response.serial_number = code.substring(2, (len));
        code = code.substring(len);
      }

      // let say this is starting with 21 batch varlength
      else if (!response.batch_id && code.substring(0, 2) == "10") {
        let len = code.indexOf(" ") > -1 ? code.indexOf(" ") : code.length;
        response.batch_id = code.substring(2, (len));
        code = code.substring(len);
      }

      // let say this is starting with 21 nhrn varlength
      else if (!nhrn && ["710", "711", "712", "713", "714"].indexOf(code.substring(0, 3)) > -1) {
        let len = code.indexOf(" ") > -1 ? code.indexOf(" ") : code.length;
        nhrn = code.substring(3, len);
        code = code.substring(len);
      }

      // deal with var length param
      else {
        code = code.substring(1);
      }

    }
    console.log("gtin", response.product_code)
    console.log("exp", response.expiry_date)
    console.log("sn", response.serial_number)
    console.log("bat", response.batch_id)
    console.log("nhrn", nhrn)
  }
  return response;

}


export function newGuid() {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
    var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
    return v.toString(16);
  });
}

export function to(promise) {
  return promise.then(data => {
    return [null, data];
  })
    .catch(err => [err]);
}

export function isValueExist(param): boolean {
  if (param) {
    if (param != undefined && param != null) {
      if (typeof param == "string") {
        if (param.length > 0) {
          return true;
        }
        else {
          return false;
        }
      }
      else if (param instanceof Array) {
        if (param.length > 0) {
          return true;
        }
        else {
          return false;
        }
      }
      else {
        return true;
      }
    }
    return false;
  }
  return false;
}

export function checkNested(obj: any, params: string) {
  let args = params.split(".");
  for (var i = 0; i < args.length; i++) {
    if (!obj || !obj.hasOwnProperty(args[i])) {
      return false;
    }
    obj = obj[args[i]];
  }
  return true;
}

export function chunk(arr, size) {
  return arr
    .reduce((acc, _, i) =>
      (i % size)
        ? acc
        : [...acc, arr.slice(i, i + size)]
      , [])
}


// Aggregation changes

var ALPHABET = '123456789ABCDEFGHKMNPRSTVWXYZ';
var ID_LENGTH = 12;
/*
var generate = function () {
  var rtn = '';
  for (var i = 0; i < ID_LENGTH; i++) {
    rtn += ALPHABET.charAt(Math.floor(Math.random() * ALPHABET.length));
  }
  return rtn;
}*/

export function checkAggregationCode(code) {
  let response = {
    Value: '',
    BarCodeType: ''
  };

  //]d20-B-Y3C1EAKD6VXS
  if (code && code.indexOf("B-") > -1) {
    code = code.substring(code.indexOf("B-"), code.length);
  }
  if (code && code.indexOf("P-") > -1) {
    code = code.substring(code.indexOf("P-"), code.length);
  }



  if (code.length === 14 && code.startsWith("B-")) {

    response.Value = code
    response.BarCodeType = 'Box'

  } else if (code.length === 17 && code.startsWith("(0)-B-")) {

    response.Value = code.ppp.replace("(0)", "")
    response.BarCodeType = 'Box'

  } else if (code.length === 14 && code.startsWith("P-")) {

    response.Value = code
    response.BarCodeType = 'Pallet'

  } else if (code.length === 17 && code.startsWith("(0)-P-")) {

    response.Value = code.ppp.replace("(0)", "")
    response.BarCodeType = 'Pallet'

  }
  else if (code.indexOf("bag") > -1) {

    response.Value = code;
    response.BarCodeType = 'Bag'

  }


  return response;
}

export function __readBarCodeData(code) {

  let response:any = {}
  if (code !== '') {
    if (code.indexOf('01') !== -1 && code.indexOf('10') !== -1 && code.indexOf('17') !== -1 && code.indexOf('21') !== -1) {
      if (code.startsWith('(')) {
        const barCodeData: string[] = code.split('(').filter(function (v) { return v !== ''; });
        if (barCodeData.length === 4) {

          for (let i = 0; i < barCodeData.length; i++) {
            if (barCodeData[i].startsWith('01)')) {
              response.GTIN = barCodeData[i].substring(3);
            } else if (barCodeData[i].startsWith('21)')) {
              response.SerialNumber = barCodeData[i].substring(3);
            } else if (barCodeData[i].startsWith('17)')) {
              response.ExpiryDate = barCodeData[i].substring(3);
            } else if (barCodeData[i].startsWith('10)')) {
              response.BatchNumber = barCodeData[i].substring(3);
            }
          }
        }

      } else if (code.length === 61) {

        response.GTIN = code.substring(2, 16);
        response.ExpiryDate = code.substring(18, 24);
        response.BatchNumber = code.substring(26, 40);
        response.SerialNumber = code.substring(42, 62);


      }
      else if (code.length === 64) {

        response.GTIN = code.substring(5, 19);
        response.ExpiryDate = code.substring(21, 27);
        response.BatchNumber = code.substring(29, 43);
        response.SerialNumber = code.substring(45, 65);

      }
      else if (code.length === 43) {

        response.GTIN = code.substring(2, 16);
        response.ExpiryDate = code.substring(18, 24);
        response.BatchNumber = code.substring(26, 31);
        response.SerialNumber = code.substring(33, 43);


      } else if (code.length === 46) {

        code = code.substring(3);
        response.GTIN = code.substring(2, 16);
        response.ExpiryDate = code.substring(18, 24);
        response.BatchNumber = code.substring(26, 31);
        response.SerialNumber = code.substring(33, 43);

      }
      else if (code.length === 54) {
        response.GTIN = code.substring(2, 16);
        response.ExpiryDate = code.substring(18, 24);
        response.BatchNumber = code.substring(26, 32);
        response.SerialNumber = code.substring(34, 54);
      }

      else if (code.length === 55) {
        response.GTIN = code.substring(5, 19);
        response.ExpiryDate = code.substring(21, 27);
        response.BatchNumber = code.substring(29, 39);
        response.SerialNumber = code.substring(41);
      }
      else if (code.length === 57) {

        code = code.substring(3);
        response.GTIN = code.substring(2, 16);
        response.ExpiryDate = code.substring(18, 24);
        response.BatchNumber = code.substring(26, 32);
        response.SerialNumber = code.substring(34, 54);

      }
    } else if (code.length === 14 && code.startsWith("B-")) {

      response.Value = code
      response.BarCodeType = 'Box'

    } else if (code.length === 17 && code.startsWith("(0)-B-")) {

      response.Value = code.ppp.replace("(0)", "")
      response.BarCodeType = 'Box'

    } else if (code.length === 14 && code.startsWith("P-")) {

      response.Value = code
      response.BarCodeType = 'Pallet'

    } else if (code.length === 17 && code.startsWith("(0)-P-")) {

      response.Value = code.ppp.replace("(0)", "")
      response.BarCodeType = 'Pallet'

    }
    // let try PPN scheme 
    else if (code.indexOf('9N') !== -1 && code.indexOf('1T') !== -1 && code.indexOf('D') !== -1 && code.indexOf('S') !== -1) {

      response.GTIN = code.substring(code.indexOf('9N') + 2, code.indexOf('1T'));
      response.BatchNumber = code.substring(code.indexOf('1T') + 2, code.indexOf('D'));
      response.ExpiryDate = code.substring(code.indexOf('D') + 1, code.indexOf('S'));
      response.SerialNumber = code.substring(code.indexOf('S') + 1, code.length);

    }
  }
  return response;
}
/*
export function generateUniqueId(previous) {
  //var previous = []

  var UNIQUE_RETRIES = 9999;
  previous = previous || [];
  var retries = 0;
  var id;

  // Try to generate a unique ID,
  // i.e. one that isn't in the previous.
  while (!id && retries < UNIQUE_RETRIES) {
    id = generate();
    if (previous.indexOf(id) !== -1) {
      id = null;
      retries++;
    }
  }
  return id;
}*/

export function generate(idLen) {
  var rtn = '';
  for (var i = 0; i < idLen; i++) {
    rtn += ALPHABET.charAt(Math.floor(Math.random() * ALPHABET.length));
  }
  return rtn;
}

export function generateUniqueId(previous, idLen) {
  //var previous = []

  var UNIQUE_RETRIES = 9999;
  previous = previous || [];
  var retries = 0;
  var id;

  // Try to generate a unique ID,
  // i.e. one that isn't in the previous.
  while (!id && retries < UNIQUE_RETRIES) {
    id = generate(idLen);
    if (previous.indexOf(id) !== -1) {
      id = null;
      retries++;
    }
  }
  return id;
}

export function keyPressValidation(event: any) {
  const pattern = /[0-9\ ]/;

  let inputChar = String.fromCharCode(event.charCode);
  if (event.keyCode != 8 && !pattern.test(inputChar)) {
    event.preventDefault();
  }
}

export function keyPress_decimal(event: any) {
  const pattern = /[0-9\+\-\ ]/;

  let inputChar = String.fromCharCode(event.charCode);
  if (event.keyCode != 8 && !pattern.test(inputChar)) {
    event.preventDefault();
  }
}

export function ExpiryDateFormat(dt) {

  let rtn = ''

  if (dt != '' && dt != undefined) {
    rtn = dt.substring(0, 2) + '-' + dt.substring(2, 4) + '-20' + dt.substring(4, 6)
  }
  return rtn
}

export function GetExpiryDateFormat(dt) {

  let year = dt.getFullYear().toString().substring(2, 4);
  let month = dt.getMonth() + 1;
  let date = dt.getDate();
  if (month.toString().length == 1) {
    month = "0" + month;
  }
  if (date.toString().length == 1) {
    date = "0" + date;
  }

  return '' + year + '' + month + '' + date;
}


export function ChangeExpiryDateFormat(expiry_date) {

  let year = new Date().getFullYear().toString().substring(0, 2) + expiry_date.substring(0, 2);
  let month = expiry_date.substring(2, 4);
  let date = expiry_date.substring(4, expiry_date.length);
  return new Date(year + '-' + month + '-' + date);
}

//Serialization Changes

export function getStageNumberToString(number) {
  switch (number) {
    case 1:
      return 'Select Product'
    case 2:
      return 'Licence Validation'
    case 3:
      return 'Product Decommission'
    case 4:
      return 'Serialisation Details'
    case 5:
      return 'Data Generation';
    case 6:
      return 'Product Verification Mode';
    case 7:
      return 'Product Verification'
    case 8:
      return 'Unused Label'
    case 9:
      return 'Create Pack'
    default:
      return 'Select Product'
  }
}

export function getStageStringToNumber(str) {
  switch (str) {
    case 'Select Product':
      return 1
    case 'Licence Validation':
      return 2
    case 'Product Decommission':
      return 3
    case 'Serialisation Details':
      return 4
    case 'Data Generation':
      return 5
      case 'Product Verification Mode':
        return 6    
    case 'Product Verification':
      return 7
    case 'Unused Label':
      return 8
    case 'Create Pack':
      return 9
    default:
      return 1
  }
}

export function GetFromatedDateFromCalendar(DT) {
  return DT.year + '-' + addZero(DT.month) + '-' + addZero(DT.day)

}

export function SetFromatedDateToCalendar(DT) {
  //DT = 2020-02-29
  return { date: { year: parseInt(DT.split('-')[0]), month: parseInt(DT.split('-')[1]), day: parseInt(DT.split('-')[2]) } }
}

export function GetExpiryDateFormatSerial(dt0) {
  var dt: any
  dt = new Date(dt0)
  let year = dt.getFullYear().toString().substring(2, 4);
  let month = dt.getMonth() + 1;
  let date = dt.getDate();
  if (month.toString().length == 1) {
    month = "0" + month;
  }
  if (date.toString().length == 1) {
    date = "0" + date;
  }

  return '' + year + '' + month + '' + date;
}


export function ChangeExpiryDateFormatSerial(expiry_date0) {
  var expiry_date: any
  expiry_date = new Date(expiry_date0)

  let year = new Date().getFullYear().toString().substring(0, 2) + expiry_date.substring(0, 2);
  let month = expiry_date.substring(2, 4);
  let date = expiry_date.substring(4, expiry_date.length);
  return new Date(year + '-' + month + '-' + date);
}

function addZero(val) {
  if (val > 9) {
    return val
  } else {
    return '0' + val
  }
}
export function CheckExpiryDate(expiry_date) {
 
  expiry_date=expiry_date.toString();
    if(expiry_date.length==6)
  {
  let cuuerntyear = new Date().getFullYear().toString().substring(2, 4);
  let year = expiry_date.substring(0, 2);
  let month = expiry_date.substring(2, 4);
  let date = expiry_date.substring(4, expiry_date.length); 
  if(year>cuuerntyear && (month>=1 && month<=12) && (date>=0 && date<=31) )
  {
    return true 
  }
  else
  {
    return false;
  }

  }
}
