import { Component, Input, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { UserService } from './services/user.service';
import { ToastrService } from 'ngx-toastr';
import { UserBO } from './models/UserBO';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  providers: [UserService]
})
export class AppComponent implements OnInit {

  @Input()
  public showMask: boolean;

  title = 'rabbit';
  user: UserBO = null;
  form: any = null;


  constructor(
    private userService: UserService,
    private toastr: ToastrService,
  ) { }

  ngOnInit() {
    this.user = new UserBO({});
    
  }

  register(form: any) {
    this.userService.register(this.user)
      .subscribe(
        result => {
          this.showMask = false;
          if (result['success']) {
            if (result['message']) {
              this.toastr.success(result['message']);
              setTimeout(() => {
                document.getElementById("openOTP").click();

              })
            }
            console.log(result['data']['data']['user']['verifyOTP']);
            this.form = form;

          } else {
            if (result['message']) {
              this.toastr.error(result['message']);
            }
          }
        },
        error => {
          this.showMask = false;
          this.toastr.error('Something went wrong !');

        }
      );
  }
  verifyAccount(form: any) {
    this.userService.verifyAccount({ verifyOTP: this.user.verifyOTP })
      .subscribe(
        result => {
          this.showMask = false;
          if (result['success']) {
            if (result['message']) {
              this.toastr.success(result['message']);
              setTimeout(() => {
                document.getElementById("dismissOTP").click();
              })
            }
            this.user = new UserBO({});
            setTimeout(() => {
              if (this.form) {
                this.form.resetForm();
                this.form = null;
              }
            }
            );
            document.getElementById("dismissOTP").click();
          } else {
            if (result['error']) {
              this.toastr.error(result['error']);
            }
          }
        },
        error => {
          this.showMask = false;
          this.toastr.error('Something went wrong !');

        }
      );
  }
}