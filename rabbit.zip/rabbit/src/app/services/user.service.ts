
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { HttpHeaders } from '@angular/common/http';
import * as _ from 'lodash';
import { HttpErrorHandler, HandleError } from '../util/HttpErrorHandler';
import { environment } from 'src/environments/environment';
import { Subject } from 'rxjs';


const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type': 'application/json',
    'Authorization': 'my-auth-token'
  })
};

const secret = "@AKIAJSN26KWXJ45CJJRFUA@";
@Injectable({
  providedIn: 'root'
})

export class UserService {

  private handleError: HandleError;


  constructor(private http: HttpClient, httpErrorHandler: HttpErrorHandler) {
    this.handleError = httpErrorHandler.createHandleError('PackService');
  }





  register(user: any) {
    return this.http.post("https://dummy-app-656.herokuapp.com/api/v1/customer/register", (user), httpOptions);
  }

  verifyAccount(user: any) {
    return this.http.post("https://dummy-app-656.herokuapp.com/api/v1/customer/verifyAccount", (user), httpOptions);
  }
  

  

  
}
