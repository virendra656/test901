export class UserBO {
   
    name:any = "";
    email:any = "";
    password:any = "";
    cpassword:any = "";
    mobile:any = "";
    phone_number:any = "";
    bank_name:any = "";
    accountNumber:any = "";
    ifsc:any = "";
    gst:any = "";
    firm_name:any = "";
    address:any = "";
    verifyOTP:any = "";
    latitude:any = 0.00;
    longitude:any = 0.00;
    businessType:any = 5;

    constructor(params) {
        Object.assign(this, params);
    }
}
